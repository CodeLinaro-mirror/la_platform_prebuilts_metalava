/*
 * Copyright 2010-2023 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.wasm.internal

/**
 * Annotated external classes correspond to JS primitive type.
 * @param type is a result of JS `typeof` operator applied to this type.
 */
@Target(AnnotationTarget.CLASS)
internal annotation class JsPrimitive(val type: String)