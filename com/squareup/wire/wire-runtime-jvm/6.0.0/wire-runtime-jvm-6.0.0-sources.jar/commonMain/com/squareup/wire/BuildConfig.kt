package com.squareup.wire

import kotlin.String

internal const val wireVersion: String = "6.0.0"
