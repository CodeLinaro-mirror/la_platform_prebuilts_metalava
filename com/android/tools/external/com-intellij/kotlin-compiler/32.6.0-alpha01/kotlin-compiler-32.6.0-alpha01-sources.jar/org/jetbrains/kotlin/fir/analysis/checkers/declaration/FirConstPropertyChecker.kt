/*
 * Copyright 2010-2021 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.fir.analysis.checkers.declaration

import org.jetbrains.kotlin.KtFakeSourceElementKind
import org.jetbrains.kotlin.descriptors.ClassKind
import org.jetbrains.kotlin.diagnostics.DiagnosticReporter
import org.jetbrains.kotlin.diagnostics.reportOn
import org.jetbrains.kotlin.fir.FirEvaluatorResult
import org.jetbrains.kotlin.fir.analysis.checkers.MppCheckerKind
import org.jetbrains.kotlin.fir.analysis.checkers.context.CheckerContext
import org.jetbrains.kotlin.fir.analysis.checkers.getModifier
import org.jetbrains.kotlin.fir.analysis.diagnostics.FirErrors
import org.jetbrains.kotlin.fir.declarations.FirProperty
import org.jetbrains.kotlin.fir.declarations.utils.evaluatedInitializer
import org.jetbrains.kotlin.fir.declarations.utils.hasExplicitBackingField
import org.jetbrains.kotlin.fir.declarations.utils.isCompanionBlockMember
import org.jetbrains.kotlin.fir.declarations.utils.isConst
import org.jetbrains.kotlin.fir.expressions.FirExpressionEvaluator
import org.jetbrains.kotlin.fir.expressions.PrivateConstantEvaluatorAPI
import org.jetbrains.kotlin.fir.expressions.canBeUsedForConstVal
import org.jetbrains.kotlin.fir.resolve.fullyExpandedType
import org.jetbrains.kotlin.fir.symbols.impl.FirRegularClassSymbol
import org.jetbrains.kotlin.fir.types.ConeErrorType
import org.jetbrains.kotlin.fir.types.coneType
import org.jetbrains.kotlin.lexer.KtTokens

object FirConstPropertyChecker : FirPropertyChecker(MppCheckerKind.Common) {
    context(context: CheckerContext, reporter: DiagnosticReporter)
    override fun check(declaration: FirProperty) {
        if (!declaration.isConst) return

        if (declaration.isVar) {
            val constModifier = declaration.getModifier(KtTokens.CONST_KEYWORD)
            constModifier?.let {
                reporter.reportOn(it.source, FirErrors.WRONG_MODIFIER_TARGET, it.token, "vars")
            }
        }

        val classKind = (context.containingDeclarations.lastOrNull() as? FirRegularClassSymbol)?.classKind
        if (classKind != ClassKind.OBJECT && context.containingDeclarations.size > 1 && !declaration.isCompanionBlockMember) {
            reporter.reportOn(declaration.source, FirErrors.CONST_VAL_NOT_TOP_LEVEL_OR_OBJECT)
            return
        }

        val source = declaration.getter?.source
        if (source != null && source.kind !is KtFakeSourceElementKind) {
            reporter.reportOn(source, FirErrors.CONST_VAL_WITH_GETTER)
            return
        }

        if (declaration.delegate != null) {
            reporter.reportOn(declaration.delegate?.source, FirErrors.CONST_VAL_WITH_DELEGATE)
            return
        }

        val initializer = declaration.initializer
        if (initializer == null) {
            val diagnostic = when {
                declaration.hasExplicitBackingField -> FirErrors.CONST_VAL_WITH_EBF
                else -> FirErrors.CONST_VAL_WITHOUT_INITIALIZER
            }
            reporter.reportOn(declaration.source, diagnostic)
            return
        }

        val type = declaration.returnTypeRef.coneType.fullyExpandedType()
        if ((type !is ConeErrorType) && !type.canBeUsedForConstVal()) {
            reporter.reportOn(declaration.source, FirErrors.TYPE_CANT_BE_USED_FOR_CONST_VAL, declaration.returnTypeRef.coneType)
            return
        }

        @OptIn(PrivateConstantEvaluatorAPI::class)
        val evaluationResult = FirExpressionEvaluator.evaluateExpression(initializer, context.session)
        val errorKind = when (evaluationResult) {
            is FirEvaluatorResult.Evaluated, is FirEvaluatorResult.ResolutionError -> return
            is FirEvaluatorResult.DivisionByZero -> {
                // Report an additional DIVISION_BY_ZERO warning
                reporter.reportOn(initializer.source, FirErrors.DIVISION_BY_ZERO)
                FirErrors.CONST_VAL_WITH_NON_CONST_INITIALIZER
            }
            FirEvaluatorResult.NotConstValInConstExpression -> FirErrors.NON_CONST_VAL_USED_IN_CONSTANT_EXPRESSION
            else -> FirErrors.CONST_VAL_WITH_NON_CONST_INITIALIZER
        }
        reporter.reportOn(initializer.source, errorKind)
    }
}
