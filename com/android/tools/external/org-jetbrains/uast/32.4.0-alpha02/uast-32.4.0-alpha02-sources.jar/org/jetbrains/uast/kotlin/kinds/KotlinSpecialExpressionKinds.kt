// Copyright 2000-2022 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

package org.jetbrains.uast.kotlin.kinds

import org.jetbrains.annotations.ApiStatus
import org.jetbrains.uast.UastSpecialExpressionKind

@ApiStatus.Internal
object KotlinSpecialExpressionKinds {
    @JvmField
    val WHEN: UastSpecialExpressionKind = UastSpecialExpressionKind("when")

    @JvmField
    val WHEN_ENTRY: UastSpecialExpressionKind = UastSpecialExpressionKind("when_entry")

    @JvmField
    val CLASS_BODY: UastSpecialExpressionKind = UastSpecialExpressionKind("class_body")

    @JvmField
    val ELVIS: UastSpecialExpressionKind = UastSpecialExpressionKind("elvis")

    @JvmField
    val SUPER_DELEGATION: UastSpecialExpressionKind = UastSpecialExpressionKind("super_delegation")
}
