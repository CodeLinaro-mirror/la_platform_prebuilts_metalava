/*
 * Copyright 2000-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.uast.java

import com.intellij.psi.PsiBinaryExpression
import org.jetbrains.annotations.ApiStatus
import org.jetbrains.uast.UBinaryExpression
import org.jetbrains.uast.UElement
import org.jetbrains.uast.UExpression
import org.jetbrains.uast.UIdentifier
import org.jetbrains.uast.UastBinaryOperator
import org.jetbrains.uast.UastLazyPart
import org.jetbrains.uast.getOrBuild

@ApiStatus.Internal
class JavaUBinaryExpression(
  override val sourcePsi: PsiBinaryExpression,
  givenParent: UElement?
) : JavaAbstractUExpression(givenParent), UBinaryExpression {

  private val leftOperandPart = UastLazyPart<UExpression>()
  private val rightOperandPart = UastLazyPart<UExpression>()
  private val operatorPart = UastLazyPart<UastBinaryOperator>()

  override val leftOperand: UExpression
    get() = leftOperandPart.getOrBuild { JavaConverter.convertOrEmpty(sourcePsi.lOperand, this) }

  override val rightOperand: UExpression
    get() = rightOperandPart.getOrBuild { JavaConverter.convertOrEmpty(sourcePsi.rOperand, this) }

  override val operator: UastBinaryOperator
    get() = operatorPart.getOrBuild { sourcePsi.operationTokenType.getOperatorType() }

  override val operatorIdentifier: UIdentifier
    get() = UIdentifier(sourcePsi.operationSign, this)

  override fun resolveOperator(): Nothing? = null
}
