/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.lint.checks

import com.android.tools.lint.checks.ThreadConstraintDetector.ThreadConstraint
import com.android.tools.lint.checks.fx.AssumptionTableBuilder
import com.android.tools.lint.checks.fx.JoinEffectDetector
import com.android.tools.lint.checks.fx.get
import com.android.tools.lint.checks.fx.invoke
import com.android.tools.lint.checks.fx.result.AssumptionTable
import com.android.tools.lint.checks.fx.result.ClassId
import com.android.tools.lint.checks.fx.result.ConstraintFailure
import com.android.tools.lint.checks.fx.result.EffectAnnotation
import com.android.tools.lint.checks.fx.result.EffectAnnotation.Explicit
import com.android.tools.lint.checks.fx.result.Error
import com.android.tools.lint.checks.fx.result.MethodId
import com.android.tools.lint.checks.fx.result.Type
import com.android.tools.lint.checks.fx.result.Type.MethodRef.Companion.rawStatic
import com.android.tools.lint.checks.fx.result.Type.MethodRef.Companion.rawVirtual
import com.android.tools.lint.checks.fx.result.plus
import com.android.tools.lint.checks.fx.utils.Encoder
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.adapt
import com.android.tools.lint.checks.fx.utils.Lattice
import com.android.tools.lint.client.api.JavaEvaluator
import com.android.tools.lint.detector.api.Issue
import com.android.tools.lint.detector.api.JavaContext
import com.intellij.psi.PsiClass
import java.util.Date
import java.util.TimerTask
import java.util.function.Supplier
import kotlinx.collections.immutable.persistentMapOf
import org.jetbrains.kotlin.psi.KtProperty
import org.jetbrains.kotlin.psi.KtPropertyAccessor
import org.jetbrains.uast.UAnnotation
import org.jetbrains.uast.UBlockExpression
import org.jetbrains.uast.UCallExpression
import org.jetbrains.uast.UClassInitializer
import org.jetbrains.uast.UExpressionList
import org.jetbrains.uast.UIfExpression
import org.jetbrains.uast.UMethod
import org.jetbrains.uast.USwitchExpression
import org.jetbrains.uast.UVariable
import org.jetbrains.uast.getContainingUClass
import org.jetbrains.uast.util.isConstructorCall

/**
 * An abstract thread detector parameterized by:
 *
 * @param T an enumeration of thread categories of interest (e.g. "Ui", "Worker", "Binder", etc.). These are assumed incomplete, and
 *   *disjoint*.
 *
 * The (induced) thread requirement [lattice] is ordered "more permissive" ⊑ "less permissive", with [ThreadConstraintLattice.AnyThread]
 * being (⊥) (the most permissive), and [ThreadConstraintLattice.NoThread] (⊤) (the least).
 *
 * Note that [ThreadConstraintLattice.AnyThread] is strictly more permissive than the "meet" over all explicitly given categories [T]. For
 * example, for Android threads, [ThreadConstraintLattice.AnyThread] is not equivalent to `@Ui ⊓ @Worker ⊓ @Binder`, but conceptually
 * equivalent to `@Ui ⊓ @Worker ⊓ @Binder ⊓ Other`, where `Other` is an implicit, programmer-inaccessible thread category.
 *
 * The analysis is also parameterizable by [initialAssumptions], which can be provided either from the analysis result of a dependent
 * module, or assumed for primitives.
 */
abstract class ThreadConstraintDetector<T : Enum<T>>(
  protected val lattice: ThreadConstraintLattice<T>,
  initialAssumptions: AssumptionTable<ThreadConstraint<T>> = persistentMapOf(),
) : JoinEffectDetector<ThreadConstraint<T>>(lattice, initialAssumptions) {

  protected abstract val violationIssue: Issue
  abstract override val unsatisfiableConstraintIssue: Issue

  override val mainIssue
    get() = violationIssue

  override val effectEncoder
    get() = lattice.encoder

  override val errorExplanation: Error.Explanation<ThreadConstraint<T>> =
    object : Error.Explanation<ThreadConstraint<T>> {
      override fun explain(error: Error.ExceedingAnnotation<ThreadConstraint<T>>) =
        when {
          error.calleeLowerBound == lattice.NoThread ->
            "has an unsatisfiable thread requirement, but context is allowing ${error.callerAnnotation}"
          else -> "must be from ${error.calleeLowerBound}, but context is allowing ${error.callerAnnotation}"
        }

      override fun explain(error: Error.NontrivialStaticInitializer<ThreadConstraint<T>>) =
        when {
          error.calleeLowerBound == lattice.NoThread -> "with an unsatisfiable thread requirement"
          else -> "that must be from ${error.calleeLowerBound}"
        }

      override fun explain(error: Error.IntroducingTop<ThreadConstraint<T>>): String {
        val site = error.site
        val t1 = error.first
        val t2 = error.next
        return when (val parentSite = site.uastParent) {
          is UIfExpression ->
            when (site) {
              parentSite.condition -> "Condition must run from $t1, while branches must run from $t2"
              else -> "Branch must run from $t2, incompatible with the other that must run from $t1"
            }
          is UExpressionList,
          is UBlockExpression -> "Statement must run from $t2, incompatible with earlier code that must run from $t1"
          is USwitchExpression ->
            when (site) {
              parentSite.expression -> "Condition must run from $t1, while branches must run from $t2"
              else -> "Branch must run from $t2, incompatible with the another that must run from $t1"
            }
          is UVariable,
          is UClassInitializer -> "Initializer must run from $t2, incompatible with an earlier initializer that must run from $t1"
          is UMethod -> "Constructor body must run from $t2, incompatible with initializers that must run from $t1"
          else -> "Expression results in an unsatisfiable thread requirement ($t2, after inferred $t1)"
        }
      }

      override fun explain(error: Error.CallingTop<ThreadConstraint<T>>) = "Call results in an unsatisfiable thread requirement"

      override fun explain(error: Error.FailingConstraint<ThreadConstraint<T>>) = "Call fails thread requirements on arguments"

      override fun explain(failure: ConstraintFailure<ThreadConstraint<T>>, argument: String, call: String?): String {
        val (_, expectedUpper, inferredLower) = failure
        val requiring =
          when (inferredLower) {
            lattice.NoThread -> UNSATISFIABLE_REQUIREMENT
            else -> "is requiring $inferredLower"
          }
        return when (call) {
          null -> "$argument must run from $expectedUpper, but $requiring"
          else -> "$argument must allow calling $call from $expectedUpper, but that call $requiring"
        }
      }

      override fun explain(error: Error.ConflictingInference<ThreadConstraint<T>>): String {
        val baseAnn = error.conflictingBase.annotated
        val requirement =
          when (error.inferredLowerBound) {
            lattice.NoThread -> "Call $UNSATISFIABLE_REQUIREMENT"
            else -> "Call must be from ${error.inferredLowerBound}"
          }

        val conflict =
          when (val origin = error.conflictingBase.origin) {
            is UCallExpression -> {
              val callee =
                when {
                  origin.isConstructorCall() ->
                    (origin.classReference?.resolvedName ?: origin.resolve()?.containingClass?.name)?.let { "constructor `$it`" }
                  else -> (origin.methodName ?: origin.methodIdentifier?.name)?.let { "`$it`" }
                } ?: "the call"
              "the work passed to $callee is expected to run from $baseAnn"
            }
            else -> "${superMethodLabel(origin)} is allowing $baseAnn"
          }

        return "$requirement, but $conflict"
      }
    }

  // Keep matching baselines from before improvements addressing b/459895811
  override fun sameLegacyMessage(new: String, old: String): Boolean {
    // An unsatisfiable requirement used to be spelled as requiring `@NoThread`
    val reworded = old.replace(LEGACY_NO_THREAD_REQUIREMENT, UNSATISFIABLE_REQUIREMENT)
    if (reworded != old && sameMessage(mainIssue, new, reworded)) return true
    val newExpected = CALLBACK_BODY_MESSAGE.find(new)?.groupValues?.get(1) ?: return false
    return LEGACY_ARGUMENT_MESSAGE.findAll(old).any { sameThread(it.groupValues[1], newExpected) }
  }

  override fun resolveAnnotations(
    context: JavaContext,
    targetAnn: Explicit<ThreadConstraint<T>>,
    baseAnns: List<Explicit<ThreadConstraint<T>>>,
  ): Explicit<ThreadConstraint<T>> = targetAnn.also {
    val conflicts = baseAnns.filter { !(lattice.precede(targetAnn.annotated, it.annotated)) }
    if (conflicts.isNotEmpty()) {
      report(context, Error.ConflictingAnnotations(targetAnn, conflicts))
    }
  }

  override fun inheritAnnotations(
    evaluator: JavaEvaluator,
    baseAnns: List<Explicit<ThreadConstraint<T>>>,
  ): EffectAnnotation.Implicit<ThreadConstraint<T>> =
    when {
      baseAnns.isEmpty() -> EffectAnnotation.None
      else -> EffectAnnotation.Implicit(baseAnns)
    }

  override fun parseClassImmediateAnnotations(evaluator: JavaEvaluator, klass: PsiClass): ThreadConstraint<T>? =
    parseAnnotations(evaluator.getAnnotations(klass, false))

  override fun parseMethodImmediateAnnotations(evaluator: JavaEvaluator, method: UMethod): ThreadConstraint<T>? {
    fun fromMethod() = parseAnnotations(evaluator.getAnnotations(method.javaPsi, false))
    fun fromClass() = method.getContainingUClass()?.javaPsi?.let { parseClassImmediateAnnotations(evaluator, it) }
    fun fromClassOrDefault() =
      when {
        // Constructors don't inherit from class annotations.
        method.isConstructor -> null
        // Properties only inherit from class annotation if they're open.
        // Otherwise, trivial properties are `@AnyThread`, and user-written {g,s}etters are
        // inferred.
        method.sourcePsi is KtProperty -> if (method.isFinal) lattice.AnyThread else fromClass()
        method.sourcePsi is KtPropertyAccessor -> if (method.isFinal) null else fromClass()
        evaluator.isStatic(method.javaPsi) -> null
        else -> fromClass()
      }

    return fromMethod() ?: fromClassOrDefault()
  }

  override fun parseAnnotations(annotations: List<UAnnotation>): ThreadConstraint<T>? {
    // We interpret a list of multiple annotations as taking their meet,
    // but treat the no-annotation case specially as "infer this", instead of `⊤` (aka `NoThread`),
    // because nobody intends to mark code as `NoThread`
    val explicitlyAnnotatedEffects = annotations.mapNotNull(::parse)
    return when {
      explicitlyAnnotatedEffects.isEmpty() -> null
      else -> explicitlyAnnotatedEffects.reduce(lattice::meetOf)
    }
  }

  protected abstract fun parse(ann: UAnnotation): ThreadConstraint<T>?

  /** A bit-set representation of ([T] ⊕ `Other`), assuming the enum [T] has few enough variants. */
  data class ThreadConstraint<T : Enum<T>> internal constructor(private val tag: ThreadConstraintLattice<T>, internal val cases: ULong) {
    internal fun isMostPermissive() = cases == tag.fullCases

    internal fun isLeastPermissive() = cases == 0UL

    override fun toString() =
      when {
        isMostPermissive() -> "`@AnyThread`"
        isLeastPermissive() -> "`@NoThread`"
        else -> tag.threadTag.enumConstants.asSequence().filterIndexed { i, _ -> cases and (1UL shl i) != 0UL }.joinToString("|")
      }
  }

  /**
   * Given an enumeration of disjoint (but not necessarily exhaustive) thread tags, generate a lattice whose `⊥` is "most inclusive", and
   * `⊤` is "least inclusive".
   *
   * There's always an implicit "other" thread tag. So `⊥` is strictly more inclusive than the inclusion of all user-specified tags.
   */
  class ThreadConstraintLattice<T : Enum<T>>(val threadTag: Class<T>) : Lattice<ThreadConstraint<T>> {
    internal val numExplicitCases = threadTag.enumConstants.size
    internal val fullCases = (1UL shl (numExplicitCases + 1)) - 1UL

    init {
      require(numExplicitCases <= ULong.SIZE_BITS - 1) {
        "Max ${ULong.SIZE_BITS - 1} thread tags supported, but `${threadTag.simpleName}` has $numExplicitCases."
      }
    }

    // Caching common instances
    val AnyThread = ThreadConstraint(this, fullCases)
    val NoThread = ThreadConstraint(this, 0UL)
    private val cache = Array(numExplicitCases + 1) { ThreadConstraint(this, 1UL shl it) }

    fun of(vararg cases: T): ThreadConstraint<T> = of(cases.fold(0UL) { acc, case -> acc or (1UL shl case.ordinal) })

    /** Micro-optimized constructor, reusing common instances */
    private fun of(cases: ULong): ThreadConstraint<T> =
      when {
        cases == 0UL -> NoThread
        cases == fullCases -> AnyThread
        cases.countOneBits() == 1 -> cache[cases.countTrailingZeroBits()]
        else -> ThreadConstraint(this, cases)
      }

    override val bottom = AnyThread
    override val top = NoThread

    override fun precede(first: ThreadConstraint<T>, second: ThreadConstraint<T>) = (first.cases and second.cases) == second.cases

    override fun joinOf(first: ThreadConstraint<T>, second: ThreadConstraint<T>) =
      when {
        first == second -> first
        first.isMostPermissive() -> second
        second.isMostPermissive() -> first
        // Only last case needed. Above cases are micro-optimization re-using common instances
        else -> of(first.cases and second.cases)
      }

    override fun meetOf(first: ThreadConstraint<T>, second: ThreadConstraint<T>) =
      when {
        first == second -> first
        first.isLeastPermissive() -> second
        second.isLeastPermissive() -> first
        // Only last case needed. Above cases are micro-optimization re-using common instances
        else -> of(first.cases or second.cases)
      }

    val encoder: Encoder<ThreadConstraint<T>> =
      when {
        fullCases < Byte.MAX_VALUE.toULong() -> Encoder.byte.adapt({ it.cases.toByte() }, { of(it.toULong()) })
        else -> Encoder.int.adapt({ it.cases.toInt() }, { of(it.toULong()) })
      }

    companion object {
      inline fun <reified T : Enum<T>> of(): ThreadConstraintLattice<T> = ThreadConstraintLattice(T::class.java)
    }
  }

  companion object {
    private const val UNSATISFIABLE_REQUIREMENT = "has an unsatisfiable thread requirement"

    /** How [UNSATISFIABLE_REQUIREMENT] read before improvements to b/459895811 */
    private const val LEGACY_NO_THREAD_REQUIREMENT = "is requiring `@NoThread`"

    /** Whole-call report before improvements to b/459895811, naming a generated argument. Group 1 is the expected thread. */
    private val LEGACY_ARGUMENT_MESSAGE = Regex("""Argument at \S+ must (?:run|allow calling \S+) from (.+?), but """)

    private fun sameThread(t1: String, t2: String) = t1.replace("`", "") == t2.replace("`", "")

    /** Report on statement inside callback passed to an assumed callee. Group 1 is the expected thread. */
    private val CALLBACK_BODY_MESSAGE =
      Regex(
        """^Call (?:must be from .+?|has an unsatisfiable thread requirement), but the work passed to .+ is expected to run from (.+)$"""
      )

    /**
     * Adds assumptions on common concurrency utilities whose callbacks execute on some other thread.
     *
     * @param background denotes "some fresh or pooled background thread" (e.g. Android's `@WorkerThread`, Studio's `@Slow`)
     */
    fun <T : Enum<T>> AssumptionTableBuilder<ThreadConstraint<T>>.assumeCommonConcurrencySignatures(background: ThreadConstraint<T>) {
      val runnableId = ClassId.of<Runnable>()
      val longId = ClassId.of("long")
      val stringId = ClassId.of<String>()

      // `Thread`s constructed with a runnable execute it on a fresh (background) thread once started.
      run {
        val threadFqn = "java.lang.Thread"
        val thread = ClassId.of(threadFqn)

        rawStatic("Thread", threadFqn, runnableId) assumedAs
          forAll<Runnable> { runnable ->
            given(runnable) {
              range = thread()
              constraint += runnable[Runnable::run] to background
            }
          }
        rawStatic("Thread", threadFqn, runnableId, stringId) assumedAs
          forAll<Runnable> { runnable ->
            given(runnable, Type.String) {
              range = thread()
              constraint += runnable[Runnable::run] to background
            }
          }

        // `kotlin.concurrent.thread` likewise runs its block on a fresh thread.
        rawStatic(
          "thread",
          "kotlin.concurrent.ThreadsKt",
          ClassId.of("boolean"),
          ClassId.of("boolean"),
          ClassId.of<ClassLoader>(),
          stringId,
          ClassId.of("int"),
          ClassId.of("kotlin.jvm.functions.Function0"),
        ) assumedAs
          forAll(Function0::class(Type.Unit)) { block ->
            given(Type.Boolean, Type.Boolean, ClassLoader::class(), Type.String, Type.Int, block) {
              range = thread()
              constraint += block[MethodId.Invoke[0]] to background
            }
          }
      }

      // `CompletableFuture`'s no-executor `*Async` entry points run their callbacks on the common pool.
      run {
        val cfFqn = "java.util.concurrent.CompletableFuture"
        val cf = ClassId.of(cfFqn)

        rawStatic("runAsync", cfFqn, runnableId) assumedAs
          forAll<Runnable> { runnable ->
            given(runnable) {
              range = cf(Type.Unit)
              constraint += runnable[Runnable::run] to background
            }
          }
        rawStatic("supplyAsync", cfFqn, ClassId.of<Supplier<*>>()) assumedAs
          forAll { u ->
            forAll(Supplier::class(u)) { supplier ->
              given(supplier) {
                range = cf(u)
                constraint += supplier[Supplier<*>::get] to background
              }
            }
          }
      }

      // `Timer` executes its tasks on its own dedicated (background) thread.
      run {
        val timerFqn = "java.util.Timer"
        val timer = ClassId.of(timerFqn)
        val timerTaskId = ClassId.of<TimerTask>()
        val dateId = ClassId.of<Date>()

        rawVirtual("schedule", timerFqn, timerTaskId, longId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Type.Long) { constraint += task[TimerTask::run] to background } }
        rawVirtual("schedule", timerFqn, timerTaskId, dateId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Date::class()) { constraint += task[TimerTask::run] to background } }
        rawVirtual("schedule", timerFqn, timerTaskId, longId, longId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Type.Long, Type.Long) { constraint += task[TimerTask::run] to background } }
        rawVirtual("schedule", timerFqn, timerTaskId, dateId, longId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Date::class(), Type.Long) { constraint += task[TimerTask::run] to background } }
        rawVirtual("scheduleAtFixedRate", timerFqn, timerTaskId, longId, longId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Type.Long, Type.Long) { constraint += task[TimerTask::run] to background } }
        rawVirtual("scheduleAtFixedRate", timerFqn, timerTaskId, dateId, longId) assumedAs
          forAll<TimerTask> { task -> given(timer(), task, Date::class(), Type.Long) { constraint += task[TimerTask::run] to background } }
      }
    }
  }
}
