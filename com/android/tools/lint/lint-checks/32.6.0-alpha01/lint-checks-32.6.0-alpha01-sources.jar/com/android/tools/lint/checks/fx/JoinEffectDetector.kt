/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.lint.checks.fx

import com.android.tools.lint.checks.fx.analysis.Analysis
import com.android.tools.lint.checks.fx.analysis.Ans
import com.android.tools.lint.checks.fx.analysis.EffectResult
import com.android.tools.lint.checks.fx.analysis.LocalFun
import com.android.tools.lint.checks.fx.analysis.Module
import com.android.tools.lint.checks.fx.analysis.Module.AnnotationParser.Companion.nearestBaseAnns
import com.android.tools.lint.checks.fx.analysis.Module.AnnotationParser.Companion.nearestSuperclassAnns
import com.android.tools.lint.checks.fx.analysis.isKtProperty
import com.android.tools.lint.checks.fx.result.AssumptionTable
import com.android.tools.lint.checks.fx.result.ClassId
import com.android.tools.lint.checks.fx.result.Constraint
import com.android.tools.lint.checks.fx.result.ConstraintFailure
import com.android.tools.lint.checks.fx.result.Effect
import com.android.tools.lint.checks.fx.result.Error
import com.android.tools.lint.checks.fx.result.MethodBody
import com.android.tools.lint.checks.fx.result.MethodId
import com.android.tools.lint.checks.fx.result.Point
import com.android.tools.lint.checks.fx.result.Result
import com.android.tools.lint.checks.fx.result.ResultTable
import com.android.tools.lint.checks.fx.result.ResultTemplate
import com.android.tools.lint.checks.fx.result.Scope
import com.android.tools.lint.checks.fx.result.Type
import com.android.tools.lint.checks.fx.result.Type.MethodRef.Companion.static
import com.android.tools.lint.checks.fx.result.Type.MethodRef.Companion.virtual
import com.android.tools.lint.checks.fx.result.Type.Sym.Companion.chain
import com.android.tools.lint.checks.fx.result.emptySubst
import com.android.tools.lint.checks.fx.result.get
import com.android.tools.lint.checks.fx.utils.Encoder
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.adapt
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.case
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.interned
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.orNull
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.subType
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.withDefault
import com.android.tools.lint.checks.fx.utils.Encoder.Companion.zeroOrMore
import com.android.tools.lint.checks.fx.utils.Lattice
import com.android.tools.lint.checks.fx.utils.UnboundedSet
import com.android.tools.lint.checks.fx.utils.decodeFromDir
import com.android.tools.lint.checks.fx.utils.encodeToDir
import com.android.tools.lint.checks.fx.utils.leastFixPoint
import com.android.tools.lint.checks.fx.utils.unionedWith
import com.android.tools.lint.client.api.JavaEvaluator
import com.android.tools.lint.client.api.LintBaseline.Companion.stringsEquivalent
import com.android.tools.lint.client.api.LintClient
import com.android.tools.lint.client.api.UElementHandler
import com.android.tools.lint.detector.api.Context
import com.android.tools.lint.detector.api.Detector
import com.android.tools.lint.detector.api.Issue
import com.android.tools.lint.detector.api.JavaContext
import com.android.tools.lint.detector.api.Location
import com.android.tools.lint.detector.api.PartialResult
import com.android.tools.lint.detector.api.Project
import com.android.tools.lint.detector.api.SourceCodeScanner
import com.android.tools.lint.detector.api.UastLintUtils.Companion.tryResolveUDeclaration
import com.intellij.openapi.application.runReadAction
import com.intellij.psi.PsiClass
import com.intellij.psi.PsiClassInitializer
import com.intellij.psi.PsiField
import com.intellij.psi.PsiFile
import com.intellij.psi.PsiMethod
import com.intellij.psi.PsiModifier
import com.intellij.psi.PsiParameter
import com.intellij.psi.PsiTypeParameter
import java.io.Closeable
import java.io.File
import java.lang.Iterable as JIterable
import java.nio.file.Paths
import java.util.function.BiConsumer
import java.util.function.Consumer
import java.util.function.Function as JFunction
import java.util.function.Predicate
import java.util.stream.Stream
import kotlin.collections.forEach as ktForEach
import kotlin.io.path.exists
import kotlinx.collections.immutable.PersistentMap
import kotlinx.collections.immutable.PersistentSet
import kotlinx.collections.immutable.persistentMapOf
import kotlinx.collections.immutable.persistentSetOf
import kotlinx.collections.immutable.plus
import kotlinx.collections.immutable.toPersistentSet
import org.jetbrains.annotations.VisibleForTesting
import org.jetbrains.kotlin.psi.KtAnonymousInitializer
import org.jetbrains.kotlin.psi.KtClassOrObject
import org.jetbrains.kotlin.psi.KtDeclaration
import org.jetbrains.kotlin.psi.KtDeclarationWithBody
import org.jetbrains.kotlin.psi.KtNamedFunction
import org.jetbrains.kotlin.psi.KtObjectDeclaration
import org.jetbrains.kotlin.psi.KtProperty
import org.jetbrains.kotlin.psi.psiUtil.containingClassOrObject
import org.jetbrains.uast.UCallExpression
import org.jetbrains.uast.UClass
import org.jetbrains.uast.UElement
import org.jetbrains.uast.UExpression
import org.jetbrains.uast.ULambdaExpression
import org.jetbrains.uast.UMethod
import org.jetbrains.uast.UVariable
import org.jetbrains.uast.resolveToUElement
import org.jetbrains.uast.toUElement

/**
 * Generic detector for effect with only one way of combining by joining up a [Lattice] regardless of whether sequentially or from different
 * branches. As a consequence of assuming that the effects form a [Lattice], this detector is only applicable for effects where we don't
 * care about order and count. The analysis is also parameterizable by [initialAssumptions], which can be provided either from the analysis
 * result of a dependent module, or assumed for primitives.
 *
 * We probably won't let Lint developers directly implement this, but only define each of their [FX] as a [Lattice] (along with other
 * callbacks for introducing the concrete [FX]). Then all the [FX]s will be fused together as one [FX] to run in the same passes (a la
 * [UElementVisitor]).
 */
abstract class JoinEffectDetector<FX : Any>(private val effects: Lattice<FX>, initialAssumptions: AssumptionTable<FX>) :
  Detector(), SourceCodeScanner, Module.AnnotationParser<FX> {
  private var knownResults: LazyLoadedResultTable = LazyLoadedResultTable(initialAssumptions, hashMapOf())
  private val programBuilder = Module.Builder(this)

  private var isSummariesCacheValid = false
  private lateinit var summariesCache: Map<Type.MethodRef, Result<Type<FX>, EffectResult.Eval<FX>>>

  protected abstract val mainIssue: Issue

  protected abstract val staticInitializerIssue: Issue

  protected open val unsatisfiableConstraintIssue: Issue
    get() = mainIssue

  protected abstract val errorExplanation: Error.Explanation<FX>

  protected abstract val effectEncoder: Encoder<FX>

  /** Optional path to directory storing partial results */
  protected open val externalAssumptionsDir: String?
    get() = null

  final override fun beforeCheckEachProject(context: Context) {
    super.beforeCheckEachProject(context)
    externalAssumptionsDir?.let(::loadPartialResults)
    maybeLoadPartialResults(context)
  }

  final override fun getApplicableUastTypes() = listOf<Class<out UElement>>(UVariable::class.java, UClass::class.java)

  final override fun createUastHandler(context: JavaContext) =
    object : UElementHandler() {
      override fun visitClass(node: UClass) {
        if (node.javaPsi is PsiTypeParameter) return
        isSummariesCacheValid = false
        try {
          programBuilder.addClass(context, node)
        } catch (e: Throwable) {
          if (LintClient.isUnitTest) {
            throw e
          } else {
            context.log(e, "Error while indexing class ${node.qualifiedName}")
          }
        }
      }

      override fun visitVariable(node: UVariable) {
        val fn = node.sourcePsi as? KtNamedFunction ?: return
        val fnUast = node.uastInitializer as? ULambdaExpression ?: return
        try {
          programBuilder.addLocalFunction(LocalFun(fnUast, fn))
        } catch (e: Throwable) {
          if (LintClient.isUnitTest) {
            throw e
          } else {
            context.log(e, "Error while indexing local function ${fn.name} in file ${fn.containingFile.name}")
          }
        }
      }
    }

  final override fun afterCheckRootProject(context: Context) {
    super.afterCheckRootProject(context)

    if (!isSummariesCacheValid) {
      val program = programBuilder.build()
      // programBuilder.loTechDebug()
      summariesCache = runReadAction {
        val entries = buildList {
          for ((cId, cDefn) in program.classes) {
            for ((mId, _) in cDefn.methods) {
              add(Type.MethodRef(cId, mId))
            }
          }
        }

        val evaluator = context.client.getUastParser(context.project).evaluator
        val findPsiMethod = memoizeNullable<Type.MethodRef, PsiMethod> { evaluator.findPsiMethod(it) }
        val summaries =
          Analysis(
              program,
              effects,
              knownResults,
              externalAnnotationFinder(evaluator, findPsiMethod),
              inheritedMethodRefFinder(findPsiMethod),
            )
            .leastFixPoint(entries)

        buildMap {
          for ((k, v) in summaries) {
            // debugEntry(program, k, v)
            if (k is Type.MethodRef) @Suppress("UNCHECKED_CAST") put(k, v as Result<Type<FX>, EffectResult.Eval<FX>>)
          }
        }
      }

      maybeSavePartialResults(context, program)
      isSummariesCacheValid = true
    }

    // Warnings on calling `⊤` usually go away when other errors are resolved,
    // so we omit them unless they're the only problems to report
    val possibleRedundancies = mutableListOf<Error.CallingTop<FX>>()
    var anyReported = false
    for ((_, sum) in summariesCache) {
      for (error in dedupErrors(sum.effect.errors!!)) {
        when {
          error !is Error.CallingTop -> {
            anyReported = true
            possibleRedundancies.clear() // no longer need to track deferred ones
            report(context, error)
          }
          !anyReported -> possibleRedundancies.add(error)
          else -> {}
        }
      }
    }
    for (deferredError in possibleRedundancies) report(context, deferredError)
  }

  /**
   * Report error discovered by the detector. Each implementation of this detector relies on [errorExplanation] to explain [error], and may
   * not even consider it an error. For example, not all detectors consider [Error.IntroducingTop] a problem, where the inferred effect is
   * [Lattice.top].
   */
  protected fun report(context: Context, error: Error<FX>) =
    with(errorExplanation) {
      when (error) {
        is Error.ExceedingAnnotation -> {
          val site = error.site
          context.reportAt(mainIssue, site, "${callLabel(site).replaceFirstChar(Char::titlecase)} ${explain(error)}")
        }
        is Error.NontrivialStaticInitializer -> {
          val site = error.site
          context.reportAt(staticInitializerIssue, site, "${staticInitializationLabel(site)} has a ${callLabel(site)} ${explain(error)}")
        }
        is Error.IntroducingTop -> {
          val msg = explain(error) ?: return@with
          context.reportAt(unsatisfiableConstraintIssue, error.site, msg)
        }
        is Error.CallingTop -> {
          val msg = explain(error) ?: return@with
          context.reportAt(unsatisfiableConstraintIssue, error.source, msg)
        }
        is Error.FailingConstraint -> reportFailingConstraint(context, error)
        is Error.ConflictingAnnotations -> context.reportAt(mainIssue, error.self.origin, explain(error))
        is Error.ConflictingInference -> context.reportAt(mainIssue, error.site, explain(error))
      }
    }

  private fun Error.Explanation<FX>.reportFailingConstraint(context: Context, error: Error.FailingConstraint<FX>) {
    val call = error.site
    val constraints = error.constraints ?: return context.reportAt(mainIssue, call, explain(error))
    assert(constraints.isNotEmpty())
    val paramToArg =
      when (val method = (call as? UCallExpression)?.resolveToUElement()) {
        is UMethod -> {
          val params = method.uastParameters
          val receiver = call.receiver
          buildMap {
            if (receiver != null) put("this", receiver)
            for ((x, v) in params zip call.valueArguments) {
              put((x.javaPsi as PsiParameter).name, v)
            }
          }
        }
        else -> mapOf()
      }
    val concreteReasons = constraints.mapNotNull { failure ->
      when (val arg = paramToArg[failure.invocation.chain.first] ?: argumentOfAssumedDomain(call, failure.invocation)) {
        null -> null
        else -> arg to failure
      }
    }
    // Friendlier message for special case of invoking the argument itself
    fun calledChain(failure: ConstraintFailure<FX>): String? {
      val (_, chain) = failure.invocation.chain
      return when {
        chain.size == 1 && chain.first().name == "invoke" -> null
        else -> "`${chain.joinToString(".") { "${it.name}()" }}`"
      }
    }
    when {
      concreteReasons.isEmpty() -> {
        val message =
          constraints.joinToString(" ") { failure ->
            "${explain(failure, "Argument at `${failure.invocation.chain.first}`", calledChain(failure))}."
          }
        context.reportAt(mainIssue, call, message)
      }
      // If have concrete locations, report some, sloppily skipping some others (e.g. the
      // receiver) for now.
      else -> for ((arg, failure) in concreteReasons) context.reportAt(mainIssue, arg, explain(failure, "Argument", calledChain(failure)))
    }
  }

  private fun Context.reportAt(issue: Issue, site: UElement, message: String) = report(issue, locationOf(site), message)

  private fun Context.locationOf(site: UElement): Location {
    val parser = client.getUastParser(project)
    if (site.sourcePsi == null) {
      // Kotlin's synthesized constructor body has no source of its own; point at the declared body rather than the whole constructor
      ((site.uastParent as? UMethod)?.sourcePsi as? KtDeclarationWithBody)?.bodyExpression?.let {
        return parser.createLocation(it)
      }
    }
    return parser.createLocation(site)
  }

  final override fun sameMessage(issue: Issue, new: String, old: String): Boolean =
    issue.id == mainIssue.id && (stringsEquivalent(old, new) || sameArgumentMessage(new, old) || sameLegacyMessage(new, old))

  /** Whether [old], as worded before some improvement, still means [new] */
  protected open fun sameLegacyMessage(new: String, old: String): Boolean = false

  /**
   * The argument of [call] standing for the base of [invocation]'s receiver chain in the callee's assumed summary, if any. For example,
   * with `invoke` assumed as `(this, x₀) -> x₀.run()`, `argumentOfAssumedDomain(app.invoke(r), x₀.run())` = `r`
   */
  private fun argumentOfAssumedDomain(call: UExpression, invocation: Type.Sym<FX>): UExpression? {
    val callExpr = call as? UCallExpression ?: return null
    val callee = callExpr.resolve() ?: return null
    // The callee may inherit or override the assumed declaration
    val (calleeRef, assumption) =
      callee.selfAndOverriddenMethodRefs().firstNotNullOfOrNull { ref -> knownResults[ref]?.let { ref to it } } ?: return null
    tailrec fun rootOf(sym: Type.Sym<FX>): Type.Sym<FX> =
      when (sym) {
        is Type.Sym.Invoke -> rootOf(sym.receiver)
        else -> sym
      }
    // Like the analysis, resolve a symbol standing for a domain through one step of the template's substitution
    val root =
      when (val r = rootOf(invocation)) {
        is Type.Sym.Name -> (assumption.subst[r] as? Type.Sym) ?: r
        else -> r
      }
    val index = assumption.domains.indexOfFirst { it == root }
    if (index < 0) return null
    val receiverCount = if (calleeRef.method.isVirtual) 1 else 0
    return if (index < receiverCount) callExpr.receiver else callExpr.getArgumentForParameter(index - receiverCount)
  }

  private fun sameArgumentMessage(new: String, old: String): Boolean =
    old.split(LEGACY_ARGUMENT_SENTENCE_BOUNDARY).any { stringsEquivalent(it.replace(LEGACY_ARGUMENT_PARAM, "$1"), new) }

  private fun callLabel(site: UElement) =
    if ((site.tryResolveUDeclaration() as? UMethod)?.isKtProperty() == true) "property call" else "call"

  private fun staticInitializationLabel(site: UElement): String {
    for (psi in generateSequence(site.sourcePsi) { it.parent }.takeWhile { it !is PsiFile && it !is PsiClass && it !is KtClassOrObject }) {
      when (psi) {
        is PsiField,
        is PsiClassInitializer -> if (psi.hasModifierProperty(PsiModifier.STATIC)) return "Class initialization"
        is KtProperty,
        is KtAnonymousInitializer -> {
          if (psi is KtProperty && psi.isTopLevel) return "Top-level initialization"
          val container = (psi as KtDeclaration).containingClassOrObject
          if (container is KtObjectDeclaration && !container.isObjectLiteral()) {
            return if (container.isCompanion()) "`companion object` initialization" else "`object` initialization"
          }
        }
      }
    }
    return "Static initialization" // fallback, e.g. when the site has no source PSI
  }

  /** Best-effort lookup of the explicit effect annotation on a method not in the current scope or the assumption table */
  private fun externalAnnotationFinder(evaluator: JavaEvaluator, findPsiMethod: (Type.MethodRef) -> PsiMethod?): (Type.MethodRef) -> FX? {
    // Each class in a hierarchy is queried once, even as every method on every descendant walks through it
    val classAnn = memoizeNullable<PsiClass, FX> { parseClassImmediateAnnotations(evaluator, it) }
    fun find(ref: Type.MethodRef): FX? {
      val psiMethod = findPsiMethod(ref) ?: return null
      val uMethod = psiMethod.toUElement() as? UMethod ?: return null
      return parseMethodImmediateAnnotations(evaluator, uMethod)
        ?: nearestBaseAnns(evaluator, psiMethod.findSuperMethods()).map { it.annotated }.reduceOrNull(effects::meetOf)
        ?: nearestSuperclassAnns(evaluator, psiMethod, classAnn)
    }

    return memoizeNullable(::find)
  }

  /** Best-effort lookup of the declarations a method inherits or overrides, transitively */
  private fun inheritedMethodRefFinder(findPsiMethod: (Type.MethodRef) -> PsiMethod?): (Type.MethodRef) -> List<Type.MethodRef> {
    val cache = hashMapOf<Type.MethodRef, List<Type.MethodRef>>()
    return { ref ->
      when {
        !ref.method.isVirtual -> listOf() // Statics and constructors are always keyed by their declaring class
        else -> cache.getOrPut(ref) { findPsiMethod(ref)?.selfAndOverriddenMethodRefs()?.minus(ref) ?: listOf() }
      }
    }
  }

  /** The keys of [this] method and, transitively, of the declarations it overrides, each listed before the ones it overrides */
  private fun PsiMethod.selfAndOverriddenMethodRefs(): List<Type.MethodRef> {
    val visited = hashSetOf<Type.MethodRef>()
    val postOrder = mutableListOf<Type.MethodRef>()
    fun visit(method: PsiMethod) {
      val ref = method.containingClass?.let { Type.MethodRef(method) }
      if (ref != null && !visited.add(ref)) return
      for (base in method.findSuperMethods().asList().asReversed()) visit(base)
      if (ref != null) postOrder += ref
    }
    visit(this)
    return postOrder.asReversed()
  }

  private fun JavaEvaluator.findPsiMethod(ref: Type.MethodRef): PsiMethod? {
    val psiClass = ref.klass.fqn?.let(::findClass) ?: return null
    return psiClass.findMethodsByName(ref.method.name, true).find { MethodId(it) == ref.method }
      ?: psiClass.constructors.find { MethodId(it) == ref.method }
  }

  private fun <X, Y : Any> memoizeNullable(compute: (X) -> Y?): (X) -> Y? {
    val cache = hashMapOf<X, Y?>()
    return fun(key) =
      // TODO `getOrPutIfMissing` when available in 2.4
      when {
        key in cache -> cache[key]
        else -> compute(key).also { cache[key] = it }
      }
  }

  private fun maybeSavePartialResults(context: Context, program: Module<FX>) {
    if (context.isGlobalAnalysis()) return
    val dirPath = getPartialResultDir(context.project, createIfAbsent = true)?.absolutePath ?: return
    savePartialResults(dirPath, resultList(program, summariesCache))
  }

  @VisibleForTesting
  fun savePartialResults(dirPath: String, results: AssumptionTable<FX> = knownResults.loaded) {
    val entries = results.toList()
    val keys = entries.map { it.first }
    val vals = entries.map { it.second }
    return savePartialResults(dirPath, keys to vals)
  }

  private fun savePartialResults(dirPath: String, results: Pair<List<ClassId>, List<PersistentMap<MethodId, ResultTemplate<FX>>>>) =
    summaryEncoder.encodeToDir(results, dirPath, methodIdEncoder, Encoder.internedString)

  private fun maybeLoadPartialResults(context: Context) {
    if (context.isGlobalAnalysis()) return

    for (dependentProject in context.project.allLibraries) {
      val libDir = getPartialResultDir(dependentProject, createIfAbsent = false)?.absolutePath ?: continue
      loadPartialResults(libDir)
    }
  }

  private fun loadPartialResults(libDir: String) {
    val classIds = classIdListEncoder.decodeFromDir(libDir, methodIdEncoder, Encoder.internedString)
    for (c in classIds) knownResults.toBeLoaded[c] = libDir
  }

  override fun checkPartialResults(context: Context, partialResults: PartialResult) {}

  private fun getPartialResultDir(project: Project, createIfAbsent: Boolean): File? {
    val path =
      when {
        // Workaround for unit tests not having `partialResultsDir` set
        LintClient.isUnitTest -> Paths.get(project.dir.absolutePath, "build", mainIssue.id, project.name)
        else -> Paths.get(project.partialResultsDir!!.absolutePath, mainIssue.id, project.name)
      }
    return when {
      path.exists() -> path.toFile()
      createIfAbsent -> path.toFile().apply { mkdirs() }
      else -> null
    }
  }

  /**
   * During the fix-point computation, we might report redundant errors, the latter subsuming the former. While we could define a proper
   * `widen` operation on the error set representation, we can also just let the redundancy happen and eliminate it at the end.
   */
  private fun dedupErrors(errors: Set<Error<FX>>): Sequence<Error<FX>> = sequence {
    val introducingTop =
      DedupingAccumulator<Error.IntroducingTop<FX>, _, _>(
        ::joinFxPair,
        { (g, f, n) -> g to (f to n) },
        { g, (f, n) -> Error.IntroducingTop(g, f, n) },
      )
    val exceedingAnnotation =
      DedupingAccumulator<Error.ExceedingAnnotation<FX>, _, _>(
        effects::joinOf,
        { (er, ee, site) -> (site to er) to ee },
        { (site, er), ee -> Error.ExceedingAnnotation(er, ee, site) },
      )
    val nontrivialStaticInitializer =
      DedupingAccumulator<Error.NontrivialStaticInitializer<FX>, _, _>(
        effects::joinOf,
        { (ee, site) -> site to ee },
        { site, ee -> Error.NontrivialStaticInitializer(ee, site) },
      )
    val failingConstraint =
      DedupingAccumulator<Error.FailingConstraint<FX>, _, _>(
        UnboundedSet<ConstraintFailure<FX>>::unionedWith,
        { (c, site) -> site to c },
        { site, c -> Error.FailingConstraint(c?.let(::dedupConstraints), site) },
      )
    val conflictingInference =
      DedupingAccumulator<Error.ConflictingInference<FX>, _, _>(
        effects::joinOf,
        { (site, inf, base) -> (site to base) to inf },
        { (site, base), inf -> Error.ConflictingInference(site, inf, base) },
      )

    for (error in errors) {
      when (error) {
        is Error.IntroducingTop -> introducingTop.accum(error)
        is Error.ExceedingAnnotation -> exceedingAnnotation.accum(error)
        is Error.NontrivialStaticInitializer -> nontrivialStaticInitializer.accum(error)
        is Error.FailingConstraint -> failingConstraint.accum(error)
        is Error.ConflictingInference -> conflictingInference.accum(error)
        is Error.CallingTop,
        is Error.ConflictingAnnotations -> yield(error)
      }
    }

    yieldAll(introducingTop.extract())
    yieldAll(exceedingAnnotation.extract())
    yieldAll(nontrivialStaticInitializer.extract())
    yieldAll(failingConstraint.extract())
    yieldAll(conflictingInference.extract())
  }

  private fun dedupConstraints(constraints: PersistentSet<ConstraintFailure<FX>>): PersistentSet<ConstraintFailure<FX>> =
    with(
      DedupingAccumulator<ConstraintFailure<FX>, _, _>(
        ::joinFxPair,
        { (call, exp, inf) -> call to (exp to inf) },
        { call, (exp, inf) -> ConstraintFailure(call, exp, inf) },
      )
    ) {
      constraints.forEach(::accum)
      return extract().toPersistentSet()
    }

  private class DedupingAccumulator<T, K, V>(val join: (V, V) -> V, val encode: (T) -> Pair<K, V>, val decode: (K, V) -> T) {
    private val map = mutableMapOf<K, V>()

    fun accum(t: T) {
      val (k, v) = encode(t)
      map[k] =
        when (k) {
          in map -> join(map[k] as V, v)
          else -> v
        }
    }

    fun extract(): Sequence<T> = map.asSequence().map { (k, v) -> decode(k, v) }
  }

  private fun joinFxPair(fxPair0: Pair<FX, FX>, fxPair1: Pair<FX, FX>): Pair<FX, FX> =
    with(effects) { (fxPair0.first join fxPair1.first) to (fxPair0.second join fxPair1.second) }

  private val classSummaryEncoder: Encoder<PersistentMap<MethodId, ResultTemplate<FX>>> = Encoder {
    val resultEncoder =
      Encoder.product(
        ::ResultTemplate,
        Encoder.map(nameEncoder, Encoder.set(recNothingTypeEncoder) withDefault persistentSetOf()) withDefault persistentMapOf(),
        recNothingTypeEncoder.zeroOrMore() withDefault listOf(),
        recTypeEncoder withDefault Type.Unit,
        fxEncoder withDefault Effect(effects.bottom, persistentSetOf(), Constraint.MostPermissive),
        Encoder.map(nameEncoder, typeEncoder) withDefault emptySubst,
      )
    Encoder.map(methodIdEncoder, resultEncoder)
  }

  private val classIdEncoder: Encoder<ClassId> = Encoder { ClassId.encoder(effectEncoder.adapt({ it as FX }, { it }), methodIdEncoder) }

  private val classIdListEncoder = classIdEncoder.zeroOrMore()

  private val summaryEncoder = Encoder.product(::Pair, classIdListEncoder, classSummaryEncoder.zeroOrMore())

  private val methodIdEncoder: Encoder<MethodId> = Encoder {
    Encoder.product(
      ::MethodId,
      Encoder.boolean withDefault true,
      Encoder.internedString withDefault "invoke",
      classIdEncoder.orNull().zeroOrMore() withDefault listOf(),
    )
  }
    .interned()

  private val methodRefEncoder: Encoder<Type.MethodRef> = Encoder.product(Type<FX>::MethodRef, classIdEncoder, methodIdEncoder)

  private val recTypeEncoder = Encoder { typeEncoder }
  private val typeListEncoder = recTypeEncoder.zeroOrMore()
  private val recTypeSymEncoder = recTypeEncoder.subType<_, Type.Sym<FX>>()
  private val invokeEncoder = Encoder.product(Type.Sym<FX>::Invoke, recTypeSymEncoder, methodIdEncoder, typeListEncoder)
  private val recNothingTypeEncoder = recTypeEncoder.subType<_, Type<Nothing>>()
  private val scopeEncoder: Encoder<Scope> =
    Encoder.sum(
      case<_, MethodId>(methodIdEncoder),
      case<_, ClassId>(classIdEncoder),
      case<_, Scope.Generated>(Encoder.int.adapt(Scope.Generated::index, Scope::Generated)),
    )
  private val paramEncoder = Encoder.product(Type.Sym<Nothing>::Param, Encoder.internedString, scopeEncoder)
  private val recvEncoder = classIdEncoder.adapt(Type.Sym.This::site, Type.Sym<Nothing>::This)
  private val nameEncoder: Encoder<Type.Sym.Name> = Encoder.sum(case<_, _>(paramEncoder), case<_, _>(recvEncoder))

  private val typeEncoder: Encoder<Type<FX>> = Encoder {
    Encoder.sum(
      case<_, Type.Application<FX>>(Encoder.product(Type<FX>::Application, classIdEncoder, typeListEncoder withDefault listOf())),
      case<_, Type.Ellipsis<FX>>(recTypeEncoder.adapt(Type.Ellipsis<FX>::element, Type<FX>::Ellipsis)),
      case<_, Type.WildCard>(Encoder.const(Type.WildCard)),
      case<_, Type.Union<FX>>(Encoder.set(recTypeEncoder).adapt(Type.Union<FX>::cases, { Type.Union(it) as Type.Union })),
      case<_, Type.Lambda<FX>>(
        Encoder.product(Type<FX>::Lambda, typeListEncoder, Encoder.product(::Result, recTypeEncoder, fxEncoder), classIdEncoder.orNull())
      ),
      case<_, Type.MethodRef>(methodRefEncoder),
      case<_, Type.SpecializedMethodRef<FX>>(Encoder.product(Type<FX>::SpecializedMethodRef, recTypeEncoder, methodRefEncoder)),
      case<_, Type.Sym.Param>(paramEncoder),
      case<_, Type.Sym.This>(recvEncoder),
      case<_, Type.Sym.Invoke<FX>>(invokeEncoder),
    )
  }

  private val fxEncoder: Encoder<Effect<FX>> = Encoder {
    val constraintEncoder =
      Encoder.product(
        ::Constraint,
        Encoder.map(recTypeSymEncoder, effectEncoder).orNull() withDefault persistentMapOf(),
        Encoder.map(invokeEncoder, Encoder.set(recTypeSymEncoder).orNull() withDefault persistentSetOf()).orNull() withDefault
          persistentMapOf(),
      )

    Encoder.product(
      ::Effect,
      effectEncoder,
      Encoder.set(recTypeSymEncoder).orNull() withDefault persistentSetOf(),
      constraintEncoder withDefault Constraint.MostPermissive,
    )
  }

  private inner class LazyLoadedResultTable(var loaded: AssumptionTable<FX>, val toBeLoaded: MutableMap<ClassId, String>) :
    ResultTable<FX> {

    override fun get(ref: Type.MethodRef): ResultTemplate<FX>? {
      val cached = loaded[ref]
      if (cached != null) return cached
      loadFromDir(toBeLoaded[ref.klass] ?: return null)
      return loaded[ref]
    }

    private fun loadFromDir(dir: String) {
      val (classIds, classSummaries) = summaryEncoder.decodeFromDir(dir, methodIdEncoder, Encoder.internedString)
      require(classIds.size == classSummaries.size)
      for ((i, classId) in classIds.withIndex()) {
        loaded = loaded.put(classId, classSummaries[i])
        toBeLoaded.remove(classId)
      }
    }
  }

  companion object {
    private val LEGACY_ARGUMENT_PARAM = Regex("""(Argument) at `[^`]+` ?""")
    private val LEGACY_ARGUMENT_SENTENCE_BOUNDARY = Regex("""(?<=\.) (?=Argument at )""")

    /** Adds assumptions on common Java and Kotlin utils */
    fun <FX> AssumptionTableBuilder<FX>.assumeCommonJavaAndKotlinSignatures() {
      // Iterable
      run {
        virtual(JIterable<*>::forEach) assumedAs
          forAll { a ->
            forAll(Consumer::class(a)) { action ->
              given(Iterable::class(a), action) { symbolicInvocations += action[Consumer<*>::accept, a] }
            }
          }
        static(Iterable<*>::ktForEach) assumedAs
          forAll { a ->
            forAll(Function1::class(a, Type.Unit)) { action ->
              given(Iterable::class(a), action) { symbolicInvocations += action[MethodId.Invoke[1], a] }
            }
          }
        static(Iterable<*>::forEachIndexed) assumedAs
          forAll { a ->
            forAll(Function2::class(Type.Int, a, Type.Unit)) { action ->
              given(Iterable::class(a), action) { symbolicInvocations += action[MethodId.Invoke[2], Type.Int, a] }
            }
          }
        (static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::maxBy) +
          static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::maxByOrNull) +
          static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::minBy) +
          static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::minByOrNull)) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function1::class(t, r)) { selector ->
                given(Iterable::class(t), selector) {
                  range = r
                  symbolicInvocations += selector[MethodId.Invoke[1], t]
                  symbolicInvocations += r[Comparable<*>::compareTo, r]
                }
              }
            }
          }
        (static<_, Comparator<Any>, (Any) -> Any>(Iterable<Nothing>::maxOfWith) +
          static<_, Comparator<Any>, (Any) -> Any>(Iterable<Nothing>::maxOfWithOrNull) +
          static<_, Comparator<Any>, (Any) -> Any>(Iterable<Nothing>::minOfWith) +
          static<_, Comparator<Any>, (Any) -> Any>(Iterable<Nothing>::minOfWithOrNull)) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Comparator::class(r)) { comparator ->
                forAll(Function1::class(t, r)) { selector ->
                  given(Iterable::class(t), comparator, selector) {
                    range = r
                    symbolicInvocations += comparator[Comparator<*>::compare, r, r]
                    symbolicInvocations += selector[MethodId.Invoke[1], t]
                  }
                }
              }
            }
          }
        (static(Iterable<*>::maxWith) +
          static(Iterable<*>::maxWithOrNull) +
          static(Iterable<*>::minWith) +
          static(Iterable<*>::minWithOrNull)) assumedAs
          forAll { t ->
            forAll(Comparator::class(t)) { comparator ->
              given(Iterable::class(t), comparator) {
                range = t
                symbolicInvocations += comparator[Comparator<*>::compare, t, t]
              }
            }
          }
        (static(Iterable<*>::all) + static<_, _>(Iterable<*>::any) + static<_, _>(Iterable<*>::none)) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(Iterable::class(t), predicate) {
                range = Type.Boolean
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }
        static(Iterable<*>::onEach) assumedAs
          forAll { t ->
            forAll(Iterable::class(t)) { self ->
              forAll(Function1::class(t, Type.Unit)) { action ->
                given(self, action) {
                  range = self
                  symbolicInvocations += action[MethodId.Invoke[1], t]
                }
              }
            }
          }
        static(Iterable<*>::onEachIndexed) assumedAs
          forAll { t ->
            forAll(Iterable::class(t)) { self ->
              forAll(Function2::class(Type.Int, t, Type.Unit)) { action ->
                given(self, action) {
                  range = self
                  symbolicInvocations += action[MethodId.Invoke[2], Type.Int, t]
                }
              }
            }
          }
        (static(Iterable<*>::reduce) + static(Iterable<*>::reduceOrNull)) assumedAs
          forAll { s ->
            forAll(s) { t ->
              forAll(Function2::class(s, t, s)) { operation ->
                given(Iterable::class(t), operation) {
                  range = s
                  symbolicInvocations += operation[MethodId.Invoke[2], s, t]
                }
              }
            }
          }
        (static(Iterable<*>::reduceIndexed) + static(Iterable<*>::reduceIndexedOrNull)) assumedAs
          forAll { s ->
            forAll(s) { t ->
              forAll(Function3::class(Type.Int, s, t, s)) { operation ->
                given(Iterable::class(t), operation) {
                  range = s
                  symbolicInvocations += operation[MethodId.Invoke[3], Type.Int, s, t]
                }
              }
            }
          }

        static<_, (Any?) -> Any>(Iterable<*>::map) assumedAs
          forAll { x ->
            forAll { y ->
              forAll(Function1::class(x, y)) { transform ->
                given(Iterable::class(x), transform) {
                  range = List::class(y)
                  symbolicInvocations += transform[MethodId.Invoke[1], x]
                }
              }
            }
          }
        static(Iterable<*>::filter) assumedAs
          forAll { x ->
            forAll(Function1::class(x, Type.Boolean)) { predicate ->
              given(Iterable::class(x), predicate) {
                range = List::class(x)
                symbolicInvocations += predicate[MethodId.Invoke[1], x]
              }
            }
          }
        static<_, Nothing, _>(Iterable<*>::fold) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function2::class(r, t, r)) { operation ->
                given(Iterable::class(t), r, operation) {
                  range = r
                  symbolicInvocations += operation[MethodId.Invoke[2], r, t]
                }
              }
            }
          }

        static<_, (Any?) -> Iterable<Any>>(Iterable<*>::flatMap) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function1::class(t, Iterable::class(r))) { transform ->
                given(Iterable::class(t), transform) {
                  range = List::class(r)
                  symbolicInvocations += transform[MethodId.Invoke[1], t]
                }
              }
            }
          }
        static<_, (Any?) -> Any>(Iterable<*>::mapNotNull) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function1::class(t, r)) { transform ->
                given(Iterable::class(t), transform) {
                  range = List::class(r)
                  symbolicInvocations += transform[MethodId.Invoke[1], t]
                }
              }
            }
          }
        static<_, (Int, Any?) -> Any>(Iterable<*>::mapIndexed) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function2::class(Type.Int, t, r)) { transform ->
                given(Iterable::class(t), transform) {
                  range = List::class(r)
                  symbolicInvocations += transform[MethodId.Invoke[2], Type.Int, t]
                }
              }
            }
          }
        (static(Iterable<*>::filterNot) + static(Iterable<*>::takeWhile) + static(Iterable<*>::dropWhile)) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(Iterable::class(t), predicate) {
                range = List::class(t)
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }
        (static<_, (Any?) -> Boolean>(Iterable<*>::first) +
          static<_, (Any?) -> Boolean>(Iterable<*>::firstOrNull) +
          static(Iterable<*>::find)) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(Iterable::class(t), predicate) {
                range = t
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }
        static<_, (Any?) -> Boolean>(Iterable<*>::count) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(Iterable::class(t), predicate) {
                range = Type.Int
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }
        static(Iterable<*>::partition) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(Iterable::class(t), predicate) {
                range = Pair::class(List::class(t), List::class(t))
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }
        static<_, (Any?) -> Any>(Iterable<*>::groupBy) assumedAs
          forAll { t ->
            forAll { k ->
              forAll(Function1::class(t, k)) { keySelector ->
                given(Iterable::class(t), keySelector) {
                  range = Map::class(k, List::class(t))
                  symbolicInvocations += keySelector[MethodId.Invoke[1], t]
                }
              }
            }
          }
        static<_, (Any?) -> Any>(Iterable<*>::associateBy) assumedAs
          forAll { t ->
            forAll { k ->
              forAll(Function1::class(t, k)) { keySelector ->
                given(Iterable::class(t), keySelector) {
                  range = Map::class(k, t)
                  symbolicInvocations += keySelector[MethodId.Invoke[1], t]
                }
              }
            }
          }
        static<_, (Any?) -> Any>(Iterable<*>::associateWith) assumedAs
          forAll { t ->
            forAll { v ->
              forAll(Function1::class(t, v)) { valueSelector ->
                given(Iterable::class(t), valueSelector) {
                  range = Map::class(t, v)
                  symbolicInvocations += valueSelector[MethodId.Invoke[1], t]
                }
              }
            }
          }
        (static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::sortedBy) +
          static<_, (Any) -> Comparable<Any>>(Iterable<Nothing>::sortedByDescending)) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function1::class(t, r)) { selector ->
                given(Iterable::class(t), selector) {
                  range = List::class(t)
                  symbolicInvocations += selector[MethodId.Invoke[1], t]
                  symbolicInvocations += r[Comparable<*>::compareTo, r]
                }
              }
            }
          }
        static(Iterable<*>::sortedWith) assumedAs
          forAll { t ->
            forAll(Comparator::class(t)) { comparator ->
              given(Iterable::class(t), comparator) {
                range = List::class(t)
                symbolicInvocations += comparator[Comparator<*>::compare, t, t]
              }
            }
          }
      }

      // List
      run {
        (static(List<*>::reduceRight) + static(List<*>::reduceRightOrNull)) assumedAs
          forAll { s ->
            forAll(s) { t ->
              forAll(Function2::class(t, s, s)) { operation ->
                given(List::class(t), operation) {
                  range = s
                  symbolicInvocations += operation[MethodId.Invoke[2], t, s]
                }
              }
            }
          }
        (static(List<*>::reduceRightIndexed) + static(List<*>::reduceRightIndexedOrNull)) assumedAs
          forAll { s ->
            forAll(s) { t ->
              forAll(Function3::class(Type.Int, t, s, s)) { operation ->
                given(Iterable::class(t), operation) {
                  range = s
                  symbolicInvocations += operation[MethodId.Invoke[3], Type.Int, t, s]
                }
              }
            }
          }
      }

      // Map
      run {
        virtual(Map<*, *>::forEach) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(BiConsumer::class(k, v)) { action ->
                given(Map::class(k, v), action) { symbolicInvocations += action[BiConsumer<*, *>::accept, k, v] }
              }
            }
          }
        static(Map<*, *>::ktForEach) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function1::class(Map.Entry::class(k, v), Type.Unit)) { action ->
                given(Map::class(k, v), action) { symbolicInvocations += action[MethodId.Invoke[1], Map.Entry::class(k, v)] }
              }
            }
          }
        static<Map<*, *>, (Map.Entry<*, *>) -> Any>(Map<*, *>::map) assumedAs
          forAll { k ->
            forAll { v ->
              forAll { r ->
                forAll(Function1::class(Map.Entry::class(k, v), r)) { transform ->
                  given(Map::class(k, v), transform) {
                    range = List::class(r)
                    symbolicInvocations += transform[MethodId.Invoke[1], Map.Entry::class(k, v)]
                  }
                }
              }
            }
          }
        static<Map<*, *>, (Map.Entry<*, *>) -> Any>(Map<*, *>::mapValues) assumedAs
          forAll { k ->
            forAll { v ->
              forAll { r ->
                forAll(Function1::class(Map.Entry::class(k, v), r)) { transform ->
                  given(Map::class(k, v), transform) {
                    range = Map::class(k, r)
                    symbolicInvocations += transform[MethodId.Invoke[1], Map.Entry::class(k, v)]
                  }
                }
              }
            }
          }
        static<Map<*, *>, (Map.Entry<*, *>) -> Any>(Map<*, *>::mapKeys) assumedAs
          forAll { k ->
            forAll { v ->
              forAll { r ->
                forAll(Function1::class(Map.Entry::class(k, v), r)) { transform ->
                  given(Map::class(k, v), transform) {
                    range = Map::class(r, v)
                    symbolicInvocations += transform[MethodId.Invoke[1], Map.Entry::class(k, v)]
                  }
                }
              }
            }
          }
        static<Map<*, *>, (Map.Entry<*, *>) -> Boolean>(Map<*, *>::filter) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function1::class(Map.Entry::class(k, v), Type.Boolean)) { predicate ->
                given(Map::class(k, v), predicate) {
                  range = Map::class(k, v)
                  symbolicInvocations += predicate[MethodId.Invoke[1], Map.Entry::class(k, v)]
                }
              }
            }
          }
        static<Map<Any, Any>, Any, () -> Any>(Map<Any, Any>::getOrElse) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function0::class(v)) { defaultValue ->
                given(Map::class(k, v), k, defaultValue) {
                  range = v
                  symbolicInvocations += defaultValue[MethodId.Invoke[0]]
                }
              }
            }
          }
        static<MutableMap<Any, Any>, Any, () -> Any>(MutableMap<Any, Any>::getOrPut) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function0::class(v)) { defaultValue ->
                given(Map::class(k, v), k, defaultValue) {
                  range = v
                  symbolicInvocations += defaultValue[MethodId.Invoke[0]]
                }
              }
            }
          }
      }

      // Array
      run {
        static(Array<*>::ktForEach) assumedAs
          forAll { a ->
            forAll(Function1::class(a, Type.Unit)) { action ->
              given(Array::class(a), action) { symbolicInvocations += action[MethodId.Invoke[1], a] }
            }
          }
        static<_, (Any?) -> Any>(Array<*>::map) assumedAs
          forAll { x ->
            forAll { y ->
              forAll(Function1::class(x, y)) { action ->
                given(Array::class(x), action) {
                  range = List::class(y)
                  symbolicInvocations += action[MethodId.Invoke[1], x]
                }
              }
            }
          }
        static(Array<*>::filter) assumedAs
          forAll { a ->
            forAll(Function1::class(a, Type.Boolean)) { predicate ->
              given(Array::class(a), predicate) {
                range = List::class(a)
                symbolicInvocations += predicate[MethodId.Invoke[1], a]
              }
            }
          }
        static<_, Nothing, _>(Array<*>::fold) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function2::class(r, t, r)) { operation ->
                given(Array::class(t), r, operation) {
                  range = r
                  symbolicInvocations += operation[MethodId.Invoke[2], r, t]
                }
              }
            }
          }
      }

      // Sequence
      // TODO below ain't accurate. Calls to `map`/`filter` only build up `Sequence`, and defer
      //  the actions to iteration time.
      run {
        static(Sequence<*>::forEach) assumedAs
          forAll { a ->
            forAll(Function1::class(a, Type.Unit)) { action ->
              given(Sequence::class(a), action) { symbolicInvocations += action[MethodId.Invoke[1], a] }
            }
          }
        static<_, (Any?) -> Any>(Sequence<*>::map) assumedAs
          forAll { x ->
            forAll { y ->
              forAll(Function1::class(x, y)) { transform ->
                given(Sequence::class(x), transform) {
                  range = Sequence::class(y)
                  symbolicInvocations += transform[MethodId.Invoke[1], x]
                }
              }
            }
          }
        static(Sequence<*>::filter) assumedAs
          forAll { x ->
            forAll(Function1::class(x, Type.Boolean)) { predicate ->
              given(Sequence::class(x), predicate) {
                range = Sequence::class(x)
                symbolicInvocations += predicate[MethodId.Invoke[1], x]
              }
            }
          }
        static<_, Nothing, _>(Sequence<*>::fold) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function2::class(r, t, r)) { operation ->
                given(Sequence::class(t), r, operation) {
                  range = r
                  symbolicInvocations += operation[MethodId.Invoke[2], r, t]
                }
              }
            }
          }
      }

      // Stream
      // TODO(b/418276115)
      run {
        virtual(Stream<*>::forEach) assumedAs
          forAll { a ->
            forAll(Consumer::class(a)) { action ->
              given(Stream::class(a), action) { symbolicInvocations += action[Consumer<*>::accept, a] }
            }
          }
        virtual<JFunction<Any?, *>>(Stream<*>::map) assumedAs
          forAll { x ->
            forAll { y ->
              forAll(JFunction::class(x, y)) { mapper ->
                given(Stream::class(x), mapper) {
                  range = Stream::class(y)
                  symbolicInvocations += mapper[JFunction<*, *>::apply, x]
                }
              }
            }
          }
        virtual(Stream<*>::filter) assumedAs
          forAll { x ->
            forAll(Predicate::class(x)) { predicate ->
              given(Stream::class(x), predicate) {
                range = Stream::class(x)
                symbolicInvocations += predicate[Predicate<*>::test, x]
              }
            }
          }
      }

      // Result
      run {
        static(kotlin.Result<*>::getOrElse) assumedAs
          forAll { R ->
            forAll(Function1::class(Throwable::class(), R)) { onFailure ->
              given(kotlin.Result::class(Type.WildCard), onFailure) {
                range = R
                symbolicInvocations += onFailure[MethodId.Invoke[1], Throwable::class()]
              }
            }
          }
        static<_, (Any) -> Any>(kotlin.Result<Any>::map) assumedAs
          forAll { T ->
            forAll { R ->
              forAll(Function1::class(T, R)) { transform ->
                given(kotlin.Result::class(T), transform) {
                  range = kotlin.Result::class(R)
                  symbolicInvocations += transform[MethodId.Invoke[1], T]
                }
              }
            }
          }
        static<kotlin.Result<Any>, (Any) -> Any, (Throwable) -> Any>(kotlin.Result<Any>::fold) assumedAs
          forAll { T ->
            forAll { R ->
              forAll(Function1::class(T, R)) { onSuccess ->
                forAll(Function1::class(Throwable::class(), R)) { onFailure ->
                  given(kotlin.Result::class(T), onSuccess, onFailure) {
                    range = R
                    symbolicInvocations += onSuccess[MethodId.Invoke[1], T]
                    symbolicInvocations += onFailure[MethodId.Invoke[1], Throwable::class()]
                  }
                }
              }
            }
          }
      }

      // Common Kotlin combinators
      run {
        (static(Any::apply) + static(Any::also)) assumedAs
          forAll { self ->
            forAll(Function1::class(self, Type.Unit)) { block ->
              given(self, block) {
                range = self
                symbolicInvocations += block[MethodId.Invoke[1], self]
              }
            }
          }
        (static<Any, Any.() -> Any>(::with) + static<Any, (Any) -> Any>(Any::let)) assumedAs
          forAll { receiver ->
            forAll { result ->
              forAll(Function1::class(receiver, result)) { block ->
                given(receiver, block) {
                  range = result
                  symbolicInvocations += block[MethodId.Invoke[1], receiver]
                }
              }
            }
          }

        fun lazyRange(range: Type<FX>, initializer: Type.Sym<FX>): Type<FX> =
          // The delegate implementation returned by `lazy`
          Type.Lambda(
            params = listOf(Type.Any, Type.KPropertySome),
            body = Result(range, Effect(bottom, persistentSetOf(initializer[MethodId.Invoke[0]]))),
            intf = ClassId.of<Lazy<*>>(),
          )
        static<() -> Any>(::lazy) assumedAs
          forAll { T -> forAll(Function0::class(T)) { initializer -> given(initializer) { range = lazyRange(T, initializer) } } }
        static<LazyThreadSafetyMode, () -> Any>(::lazy) assumedAs
          forAll { T ->
            forAll(Function0::class(T)) { initializer ->
              given(LazyThreadSafetyMode::class(), initializer) { range = lazyRange(T, initializer) }
            }
          }
        static<Any?, () -> Any>(::lazy) assumedAs
          forAll { T ->
            forAll(Function0::class(T)) { initializer ->
              given(java.lang.Object::class(), initializer) { range = lazyRange(T, initializer) }
            }
          }

        static(::repeat) assumedAs
          forAll(Function1::class(Type.Int, Type.Unit)) { action ->
            given(Type.Int, action) {
              range = Type.Unit
              symbolicInvocations += action[MethodId.Invoke[1], Type.Int]
            }
          }

        static<() -> Any>(::run) assumedAs
          forAll { R ->
            forAll(Function0::class(R)) { block ->
              given(block) {
                range = R
                symbolicInvocations += block[MethodId.Invoke[0]]
              }
            }
          }
        static<Any, Any.() -> Any>(Any::run) assumedAs
          forAll { T ->
            forAll { R ->
              forAll(Function1::class(T, R)) { block ->
                given(T, block) {
                  range = R
                  symbolicInvocations += block[MethodId.Invoke[1], T]
                }
              }
            }
          }

        (static<Any, (Any) -> Boolean>(Any::takeIf) + static<Any, (Any) -> Boolean>(Any::takeUnless)) assumedAs
          forAll { t ->
            forAll(Function1::class(t, Type.Boolean)) { predicate ->
              given(t, predicate) {
                range = t
                symbolicInvocations += predicate[MethodId.Invoke[1], t]
              }
            }
          }

        static<() -> Any>(::runCatching) assumedAs
          forAll { r ->
            forAll(Function0::class(r)) { block ->
              given(block) {
                range = kotlin.Result::class(r)
                symbolicInvocations += block[MethodId.Invoke[0]]
              }
            }
          }
        static<Any, Any.() -> Any>(Any::runCatching) assumedAs
          forAll { t ->
            forAll { r ->
              forAll(Function1::class(t, r)) { block ->
                given(t, block) {
                  range = kotlin.Result::class(r)
                  symbolicInvocations += block[MethodId.Invoke[1], t]
                }
              }
            }
          }

        static<Closeable, (Closeable) -> Any>(Closeable::use) assumedAs
          forAll(Closeable::class()) { t ->
            forAll { r ->
              forAll(Function1::class(t, r)) { block ->
                given(t, block) {
                  range = r
                  symbolicInvocations += block[MethodId.Invoke[1], t]
                  symbolicInvocations += t[Closeable::close]
                }
              }
            }
          }

        // The lazy messages below are invoked at most once, synchronously; joining their effect unconditionally is the usual
        // over-approximation.
        (static<Boolean, () -> Any>(::require) + static<Boolean, () -> Any>(::check)) assumedAs
          forAll(Function0::class(Type.Any)) { lazyMessage ->
            given(Type.Boolean, lazyMessage) { symbolicInvocations += lazyMessage[MethodId.Invoke[0]] }
          }
        (static<Any?, () -> Any>(::requireNotNull) + static<Any?, () -> Any>(::checkNotNull)) assumedAs
          forAll { t ->
            forAll(Function0::class(Type.Any)) { lazyMessage ->
              given(t, lazyMessage) {
                range = t
                symbolicInvocations += lazyMessage[MethodId.Invoke[0]]
              }
            }
          }

        static<StringBuilder.() -> Unit>(::buildString) assumedAs
          forAll(Function1::class(StringBuilder::class(), Type.Unit)) { builderAction ->
            given(builderAction) {
              range = Type.String
              symbolicInvocations += builderAction[MethodId.Invoke[1], StringBuilder::class()]
            }
          }
        static<Int, StringBuilder.() -> Unit>(::buildString) assumedAs
          forAll(Function1::class(StringBuilder::class(), Type.Unit)) { builderAction ->
            given(Type.Int, builderAction) {
              range = Type.String
              symbolicInvocations += builderAction[MethodId.Invoke[1], StringBuilder::class()]
            }
          }
        static<MutableList<Any>.() -> Unit>(::buildList) assumedAs
          forAll { e ->
            forAll(Function1::class(List::class(e), Type.Unit)) { builderAction ->
              given(builderAction) {
                range = List::class(e)
                symbolicInvocations += builderAction[MethodId.Invoke[1], List::class(e)]
              }
            }
          }
        static<Int, MutableList<Any>.() -> Unit>(::buildList) assumedAs
          forAll { e ->
            forAll(Function1::class(List::class(e), Type.Unit)) { builderAction ->
              given(Type.Int, builderAction) {
                range = List::class(e)
                symbolicInvocations += builderAction[MethodId.Invoke[1], List::class(e)]
              }
            }
          }
        static<MutableSet<Any>.() -> Unit>(::buildSet) assumedAs
          forAll { e ->
            forAll(Function1::class(Set::class(e), Type.Unit)) { builderAction ->
              given(builderAction) {
                range = Set::class(e)
                symbolicInvocations += builderAction[MethodId.Invoke[1], Set::class(e)]
              }
            }
          }
        static<Int, MutableSet<Any>.() -> Unit>(::buildSet) assumedAs
          forAll { e ->
            forAll(Function1::class(Set::class(e), Type.Unit)) { builderAction ->
              given(Type.Int, builderAction) {
                range = Set::class(e)
                symbolicInvocations += builderAction[MethodId.Invoke[1], Set::class(e)]
              }
            }
          }
        static<MutableMap<Any, Any>.() -> Unit>(::buildMap) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function1::class(Map::class(k, v), Type.Unit)) { builderAction ->
                given(builderAction) {
                  range = Map::class(k, v)
                  symbolicInvocations += builderAction[MethodId.Invoke[1], Map::class(k, v)]
                }
              }
            }
          }
        static<Int, MutableMap<Any, Any>.() -> Unit>(::buildMap) assumedAs
          forAll { k ->
            forAll { v ->
              forAll(Function1::class(Map::class(k, v), Type.Unit)) { builderAction ->
                given(Type.Int, builderAction) {
                  range = Map::class(k, v)
                  symbolicInvocations += builderAction[MethodId.Invoke[1], Map::class(k, v)]
                }
              }
            }
          }
      }
    }
  }
}

private fun <FX : Any> debugEntry(program: Module<FX>, k: Point<FX>, v: Ans<FX>) {
  when (k) {
    is Type.MethodRef ->
      when (program[k]?.status) {
        is MethodBody.Status.ForChecking,
        is MethodBody.Status.ForInference -> println("  - $k : (…) -> $v")
        null,
        is MethodBody.Status.StaticInitializer,
        is MethodBody.Status.Abstract -> {}
      }
    is Point.Instantiation -> println("  - $k : $v")
  }
}

private fun <FX : Any> resultList(module: Module<FX>, results: Map<Type.MethodRef, Result<Type<FX>, EffectResult.Eval<FX>>>) =
  module.classes
    .map { (classId, classBody) ->
      val classSummary: PersistentMap<MethodId, ResultTemplate<FX>> =
        classBody.methods.asSequence().fold(persistentMapOf()) { m, (methodId, methodBody) ->
          val methodSummary = results[Type.MethodRef(classId, methodId)] ?: return@fold m
          val effect =
            when (val effectResult = methodSummary.effect) {
              is EffectResult.Checking ->
                when (val status = methodBody.status) {
                  is MethodBody.Status.ForChecking -> Effect(status.upperBound.annotated, persistentSetOf(), effectResult.result)
                  is MethodBody.Status.ForInference -> throw IllegalStateException()
                  is MethodBody.Status.Abstract,
                  is MethodBody.Status.StaticInitializer -> return@fold m
                }
              is EffectResult.Inference -> effectResult.result
              is EffectResult.Inapplicable -> return@fold m
            }
          val subst = methodSummary.effect.subst!!
          m.put(methodId, ResultTemplate(methodBody.initEnvironment.types, methodBody.domains, methodSummary.value, effect, subst))
        }
      classId to classSummary
    }
    .unzip()
