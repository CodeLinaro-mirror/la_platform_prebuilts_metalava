/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.lint.checks.fx.analysis

import com.android.tools.lint.checks.fx.analysis.EffectResult.Checking
import com.android.tools.lint.checks.fx.analysis.EffectResult.Inapplicable
import com.android.tools.lint.checks.fx.analysis.EffectResult.Inference
import com.android.tools.lint.checks.fx.analysis.EffectResult.Instantiation
import com.android.tools.lint.checks.fx.result.ClassId
import com.android.tools.lint.checks.fx.result.Constraint
import com.android.tools.lint.checks.fx.result.ConstraintFailure
import com.android.tools.lint.checks.fx.result.Effect
import com.android.tools.lint.checks.fx.result.EffectAnnotation
import com.android.tools.lint.checks.fx.result.Env
import com.android.tools.lint.checks.fx.result.Env.Companion.withVar
import com.android.tools.lint.checks.fx.result.Env.Companion.withVarDelegate
import com.android.tools.lint.checks.fx.result.Env.Companion.withVars
import com.android.tools.lint.checks.fx.result.Error
import com.android.tools.lint.checks.fx.result.ErrorSite
import com.android.tools.lint.checks.fx.result.Instantiable
import com.android.tools.lint.checks.fx.result.KtTypeReferenceAdapter
import com.android.tools.lint.checks.fx.result.MethodBody
import com.android.tools.lint.checks.fx.result.MethodId
import com.android.tools.lint.checks.fx.result.Point
import com.android.tools.lint.checks.fx.result.PsiClassAdapter
import com.android.tools.lint.checks.fx.result.PsiTypeAdapter
import com.android.tools.lint.checks.fx.result.Result
import com.android.tools.lint.checks.fx.result.ResultTable
import com.android.tools.lint.checks.fx.result.ResultTemplate
import com.android.tools.lint.checks.fx.result.Scope
import com.android.tools.lint.checks.fx.result.Subst
import com.android.tools.lint.checks.fx.result.Type
import com.android.tools.lint.checks.fx.result.TypeBounds
import com.android.tools.lint.checks.fx.result.at
import com.android.tools.lint.checks.fx.result.emptySubst
import com.android.tools.lint.checks.fx.result.errorSetLattice
import com.android.tools.lint.checks.fx.result.isExtension
import com.android.tools.lint.checks.fx.result.isFinal
import com.android.tools.lint.checks.fx.result.isStatic
import com.android.tools.lint.checks.fx.result.renderAbbrev
import com.android.tools.lint.checks.fx.result.showSubst
import com.android.tools.lint.checks.fx.result.translate
import com.android.tools.lint.checks.fx.utils.DependentMonotone
import com.android.tools.lint.checks.fx.utils.EffectfulComputation
import com.android.tools.lint.checks.fx.utils.Lattice
import com.android.tools.lint.checks.fx.utils.UnboundedSet
import com.android.tools.lint.checks.fx.utils.flatMapToPersistentSet
import com.android.tools.lint.checks.fx.utils.foldM
import com.android.tools.lint.checks.fx.utils.forM
import com.android.tools.lint.checks.fx.utils.joinedOver
import com.android.tools.lint.checks.fx.utils.lastM
import com.android.tools.lint.checks.fx.utils.mapM
import com.android.tools.lint.checks.fx.utils.possibilityLattice
import com.android.tools.lint.checks.fx.utils.pure
import com.android.tools.lint.checks.fx.utils.unionedWith
import com.android.tools.lint.checks.isEffectivelyFinal
import com.android.tools.lint.client.api.LintClient
import com.android.tools.lint.detector.api.UastLintUtils.Companion.tryResolveUDeclaration
import com.android.tools.lint.detector.api.asCall
import com.android.tools.lint.detector.api.isImmutable
import com.android.tools.lint.detector.api.nameFromSource
import com.intellij.openapi.progress.ProgressManager
import com.intellij.psi.LambdaUtil
import com.intellij.psi.PsiClass
import com.intellij.psi.PsiClassType
import com.intellij.psi.PsiEllipsisType
import com.intellij.psi.PsiField
import com.intellij.psi.PsiIntersectionType
import com.intellij.psi.PsiLambdaParameterType
import com.intellij.psi.PsiLocalVariable
import com.intellij.psi.PsiMethod
import com.intellij.psi.PsiNamedElement
import com.intellij.psi.PsiParameter
import com.intellij.psi.PsiType
import com.intellij.psi.PsiVariable
import java.util.IdentityHashMap
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.PersistentSet
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentMapOf
import kotlinx.collections.immutable.persistentSetOf
import kotlinx.collections.immutable.plus
import org.jetbrains.kotlin.asJava.elements.KtLightMethod
import org.jetbrains.kotlin.asJava.elements.isAccessor
import org.jetbrains.kotlin.psi.KtCallExpression
import org.jetbrains.kotlin.psi.KtNamedFunction
import org.jetbrains.kotlin.psi.KtObjectDeclaration
import org.jetbrains.kotlin.psi.KtParameter
import org.jetbrains.kotlin.psi.KtProperty
import org.jetbrains.kotlin.psi.psiUtil.isExtensionDeclaration
import org.jetbrains.uast.UAnnotation
import org.jetbrains.uast.UArrayAccessExpression
import org.jetbrains.uast.UBinaryExpressionWithType
import org.jetbrains.uast.UBlockExpression
import org.jetbrains.uast.UBreakExpression
import org.jetbrains.uast.UCallExpression
import org.jetbrains.uast.UCallableReferenceExpression
import org.jetbrains.uast.UClass
import org.jetbrains.uast.UContinueExpression
import org.jetbrains.uast.UDeclarationsExpression
import org.jetbrains.uast.UDoWhileExpression
import org.jetbrains.uast.UElement
import org.jetbrains.uast.UExpression
import org.jetbrains.uast.UExpressionList
import org.jetbrains.uast.UForEachExpression
import org.jetbrains.uast.UForExpression
import org.jetbrains.uast.UIfExpression
import org.jetbrains.uast.UJumpExpression
import org.jetbrains.uast.ULabeledExpression
import org.jetbrains.uast.ULambdaExpression
import org.jetbrains.uast.ULiteralExpression
import org.jetbrains.uast.ULocalVariable
import org.jetbrains.uast.UMethod
import org.jetbrains.uast.UMultiResolvable
import org.jetbrains.uast.UObjectLiteralExpression
import org.jetbrains.uast.UParameter
import org.jetbrains.uast.UParenthesizedExpression
import org.jetbrains.uast.UPolyadicExpression
import org.jetbrains.uast.UQualifiedReferenceExpression
import org.jetbrains.uast.UReferenceExpression
import org.jetbrains.uast.UReturnExpression
import org.jetbrains.uast.USimpleNameReferenceExpression
import org.jetbrains.uast.USuperExpression
import org.jetbrains.uast.USwitchClauseExpressionWithBody
import org.jetbrains.uast.USwitchExpression
import org.jetbrains.uast.UThisExpression
import org.jetbrains.uast.UThrowExpression
import org.jetbrains.uast.UTryExpression
import org.jetbrains.uast.UUnaryExpression
import org.jetbrains.uast.UVariable
import org.jetbrains.uast.UWhileExpression
import org.jetbrains.uast.UYieldExpression
import org.jetbrains.uast.UastBinaryExpressionWithTypeKind
import org.jetbrains.uast.UastBinaryOperator
import org.jetbrains.uast.UastEmptyExpression
import org.jetbrains.uast.UastPostfixOperator
import org.jetbrains.uast.UastPrefixOperator
import org.jetbrains.uast.UastSpecialExpressionKind
import org.jetbrains.uast.getContainingUClass
import org.jetbrains.uast.getParameterForArgument
import org.jetbrains.uast.java.isJava
import org.jetbrains.uast.resolveToUElement
import org.jetbrains.uast.textRange
import org.jetbrains.uast.toUElement
import org.jetbrains.uast.tryResolve
import org.jetbrains.uast.util.isConstructorCall

/**
 * An [Analysis] of a [module] is a [Monotone] on summaries, as in "given a hypothetical bootstrapping summary of the [module], what else
 * must be true before the summary is sound?". The summary of interest is the [Analysis]'s least fix point. In addition, [assumptions] has
 * the assumed summaries of bindings that occur free in [module] (i.e. they are not defined in [module], but [module] may use those).
 *
 * The analysis is parameterized by a [concreteEffect] lattice, and assumes that effects are to be joined regardless of whether they are
 * combined sequentially or from different branches. Some examples of useful [concreteEffect] in practice are "thread requirements" (e.g.
 * for detecting conflicting thread requirements), "constructor calls" (e.g. for detecting subclass initialization from superclass), "all
 * function calls" (e.g. for reconstructing a modular, polymorphic call graph).
 */
internal open class Analysis<FX : Any>(
  private val module: Module<FX>,
  private val concreteEffect: Lattice<FX>,
  private val assumptions: ResultTable<FX> = ResultTable.of(persistentMapOf()),
  private val externalAnnotation: (Type.MethodRef) -> FX? = { null },
  private val inheritedMethodRefs: (Type.MethodRef) -> List<Type.MethodRef> = { listOf() },
  private val log: (() -> String) -> Unit = { /* ignore */ },
) : DependentMonotone<Point<FX>, Ans<FX>> {

  /**
   * Default effect for constructs we don't understand.
   *
   * Analyses on safety properties that need to be a sound over-approximation resort to `⊤`, while ones that aim to be helpful bug-finders
   * without overwhelming users with technically correct but practically pessimistic and tedious errors resort to `⊥`. Note that the latter
   * means both false positives and negatives are possible. This is also the default, because Lint tends to be more of a useful bug-finder
   * than a rigorous verifier.
   */
  protected open val <T> Lattice<T>.unsure: T
    get() = bottom

  protected open val <T> Lattice<T>.unsureResult: Result<Type<FX>, T>
    get() = emptyResult

  private val constraintLattice = Constraint.domain(concreteEffect)

  private val effectLattice =
    Lattice.product(
      ::Effect,
      Effect<FX>::concrete,
      Effect<FX>::invocations,
      Effect<FX>::constraint,
      concreteEffect,
      possibilityLattice(),
      constraintLattice,
    )

  private val typeLattice = Type.latticeOf(effectLattice)
  private val substLattice = Lattice.pointWise<Type.Sym.Name, _>(typeLattice)

  private val fxInstantiationLattice =
    Lattice.product(
      ::Instantiation,
      Instantiation<FX>::result,
      Instantiation<FX>::errors,
      Instantiation<FX>::subst,
      effectLattice,
      possibilityLattice(),
      substLattice,
    )

  private val fxInferenceLattice =
    Lattice.product(
      ::Inference,
      Inference<FX>::result,
      Inference<FX>::errors,
      Inference<FX>::subst,
      effectLattice,
      errorSetLattice(),
      substLattice,
    )

  private val fxCheckingLattice =
    Lattice.product(
      ::Checking,
      Checking<FX>::result,
      Checking<FX>::errors,
      Checking<FX>::subst,
      constraintLattice,
      errorSetLattice(),
      substLattice,
    )

  private val instantiationLattice = Result.domain(typeLattice, fxInstantiationLattice)
  private val inferenceLattice = Result.domain(typeLattice, fxInferenceLattice)
  private val checkingLattice = Result.domain(typeLattice, fxCheckingLattice)
  private val inapplicableLattice = Result.domain(typeLattice, Inapplicable)

  private val unboundedInferenceMode = // reused common value
    Mode.Inference(listOf(), concreteEffect, fxInferenceLattice, constraintLattice)

  private fun inferenceMode(ann: EffectAnnotation.Implicit<FX>) =
    when {
      ann.nearestBaseAnnotations.isEmpty() -> unboundedInferenceMode
      else -> Mode.Inference(ann.nearestBaseAnnotations, concreteEffect, fxInferenceLattice, constraintLattice)
    }

  private fun checkingMode(ann: EffectAnnotation.Explicit<FX>) =
    Mode.Checking(ann.annotated, concreteEffect, fxCheckingLattice, constraintLattice)

  // Make sure this is in sync with `invoke` below
  override fun latticeAt(point: Point<FX>): Lattice<Ans<FX>> {
    return when (point) {
      is Type.MethodRef -> {
        val method = module[point] ?: return checkingLattice as Lattice<Ans<FX>>
        return when (method.status) {
          is MethodBody.Status.Abstract -> inapplicableLattice as Lattice<Ans<FX>>
          is MethodBody.Status.BasicConstructor -> inferenceLattice as Lattice<Ans<FX>>
          is MethodBody.Status.ForChecking -> checkingLattice as Lattice<Ans<FX>>
          is MethodBody.Status.ForInference -> inferenceLattice as Lattice<Ans<FX>>
        }
      }
      is Point.Instantiation -> instantiationLattice as Lattice<Ans<FX>>
    }
  }

  /**
   * We're encoding multiple mutually recursive functions into one [invoke]:
   * - inference: [Type.MethodRef] -> [Type] × [EffectResult.Inference]
   *     * Given unannotated method, infer polymorphic type+effect from its definition
   * - checking: [Type.MethodRef] -> [Type] × [EffectResult.Checking]
   *     * Given annotated method, ensure its definition behaves accordingly
   * - instantiation: [Point.Instantiation] -> [Type] × [EffectResult.Instantiation]
   *     * Given a method and arguments, instantiation the method's summary for context-sensitive type+effect
   */
  override fun invoke(rec: (Point<FX>) -> Ans<FX>, point: Point<FX>): Ans<FX> =
    when (point) {
      is Type.MethodRef -> {
        val method = module[point] ?: return Result(Type.None, fxCheckingLattice.unsure)

        fun <R : EffectResult.Eval<FX>> Mode<FX, R>.eval(body: UExpression): Result<Type<FX>, R> =
          eval(rec, method.initEnvironment, body, persistentListOf(ReturnRecord(body.uastParent!!)))

        fun <R : EffectResult.Eval<FX>> Mode<FX, R>.fieldInitializerEffects(): R =
          forM(::eval, (method.source as? UMethod)?.fieldInitializers().orEmpty())

        when (val status = method.status) {
          is MethodBody.Status.Abstract -> Result(method.returnTypeAnnotation, Inapplicable)
          is MethodBody.Status.BasicConstructor ->
            with(unboundedInferenceMode) { inferenceLattice.catchError { Result(method.returnTypeAnnotation, fieldInitializerEffects()) } }
          is MethodBody.Status.ForChecking ->
            with(checkingMode(status.upperBound)) {
              checkingLattice.catchError {
                when (val body = status.body) {
                  null -> Result(method.returnTypeAnnotation, fieldInitializerEffects())
                  else -> {
                    val (t, fx) = eval(body)
                    Result(t, merge(body, fieldInitializerEffects(), fx))
                  }
                }
              }
            }
          is MethodBody.Status.ForInference -> {
            // Guards first: inference blames the first conflicting base, and the guards' call-anchored message should win
            val guards = assumedObjectLiteralGuards(method)
            val base = if (guards.isEmpty()) status.base else EffectAnnotation.Implicit(guards + status.base.nearestBaseAnnotations)
            with(inferenceMode(base)) {
              inferenceLattice.catchError {
                val (t, fx) = eval(status.body)
                Result(t, merge(status.body, fieldInitializerEffects(), fx))
              }
            }
          }
        }
      }
      is Point.Instantiation -> instantiationLattice.catchError { point.subst.instType(rec, point.type) }
    }

  /** Run action with errors suppressed in production, to avoid bringing down all of Lint */
  private fun <T> Lattice<T>.catchError(run: () -> T): T =
    try {
      run()
    } catch (e: Throwable) {
      if (LintClient.isUnitTest) {
        throw e
      } else {
        log { "${e.javaClass.simpleName}: ${e.message}" }
        unsure
      }
    }

  /**
   * Mode-polymorphic analysis of [body] (i.e. either checking or inference)
   *
   * Assuming an oracle [rec] that knows existing summaries and their instantiations, [eval] is implemented as a structural recursion on the
   * expression.
   *
   * Most complexities of this function are from manipulating UAST, which will eventually be cleaned up.
   */
  private fun <R : EffectResult.Eval<FX>> Mode<FX, R>.eval(
    rec: (Point<FX>) -> Ans<FX>,
    initEnv: Env<FX>,
    body: UExpression,
    returns: PersistentList<ReturnRecord<FX>>,
  ): Result<Type<FX>, R> {
    val typeParams = initEnv.boundParamNames
    var env = initEnv

    val target = returns.last()

    fun targetName() =
      when (val target = target.target) {
        is UMethod -> target.name
        else -> target.toString()
      }

    fun translate(t: PsiType) = PsiTypeAdapter.translate(typeParams, t)
    fun translate(c: UClass) = PsiClassAdapter.translate(typeParams, c.javaPsi)

    fun getType(e: UExpression): Type<Nothing> =
      when (val t = e.getExpressionType()) {
        null -> Type.None.also { log { "WARNING: Can't get type of ${e.renderAbbrev()}" } }
        else -> translate(t)
      }

    /**
     * When there is an expression/feature we don't know, we return the type from [UExpression.getExpressionType], and assume [unsure]
     * effect.
     */
    fun giveUp(e: UExpression, msg: () -> String): Result<Type<FX>, R> {
      log { "WARNING: ${msg()}" }
      return Result(getType(e), unsure)
    }

    fun UThisExpression.type(): Type<FX> {
      val resolved = tryResolve()
      val cl = resolved.toUElement() as? UClass
      return when {
        // opt: if the class is final, no need to make result parametric
        cl != null && cl.isFinal -> translate(cl)
        isJava(lang) -> {
          val cl = getContainingUClass()!!
          val t = translate(cl) as Type.Application
          when {
            cl.isFinal -> t
            else -> label?.let(env::receiver) ?: env.receiver(t.constructor) ?: t
          }
        }
        else ->
          (resolved as? PsiNamedElement)?.name?.let(env::varAt)
            ?: label?.let(env::receiver)
            ?: env.receiver(ClassId.of(getContainingUClass()!!.javaPsi))
            ?: getType(this).also { log { "WARNING: Don't know what `this` is in `${targetName()}`" } }
      }
    }

    fun <E : UExpression> E.asName(name: (E) -> String): Result<Type<FX>, R> {
      val x = name(this)
      val t = env.varAt(x)
      val fx =
        when (val delegate = env.varDelegateAt(x)) {
          null -> fxInstantiationLattice.bottom
          else ->
            emptySubst
              .invokeWildGuess(rec, delegate, "getValue", listOf(Type.Any, Type.KPropertySome)) { instantiationLattice.bottom }
              .effect
        }
      if (t != null) return Result(t, onInvocationEffect(this, fx))
      return giveUp(this) { "Don't know what `$x` means in `${target.target.renderAbbrev()}`" }
    }

    val cache = IdentityHashMap<UExpression, Result<Type<FX>, R>>()

    fun loop(e: UExpression): Result<Type<FX>, R> {

      /** Analyze local sub-expression that might be shared and reusable */
      fun loopCached(e: UExpression) = cache.getOrPut(e) { loop(e) }

      fun UExpression.staticContext(): Scope =
        Scope.Generated(textRange?.startOffset ?: /* slow case for synthetic UAST */ asSourceString().hashCode())

      /**
       * Given [argsSuppliedAnalyzed] as the preliminary analysis result of [args], where user-supplied arguments are analyzed, but
       * [OpaqueConstant]s are left as-is, analyze all [OpaqueConstant.Default]s and revise [argsSuppliedAnalyzed].
       *
       * @param recvs analyzed receivers
       * @param args syntactic user-supplied arguments as well as analysis-inserted [OpaqueConstant]
       * @param argsSuppliedAnalyzed analyzed arguments, parallel to [args], where analysis-inserted [OpaqueConstant]s are the conservative
       *   upper bounds from the parameters' types
       * @return A [Result] like [argsSuppliedAnalyzed], but types from [OpaqueConstant.Default]s refined, and effects joined with those
       *   from instantiating defaults
       */
      fun instDefaults(
        recvs: List<Result<Type<FX>, R>>,
        args: List<UExpression>,
        argsSuppliedAnalyzed: Result<List<Type<FX>>, R>,
      ): Result<List<Type<FX>>, R> {
        // common fast path
        if (args.none { it is OpaqueConstant.Default }) return argsSuppliedAnalyzed

        // Effects are order-insensitive, so it's ok here to compute default arguments "out of order"
        // after user-supplied arguments.
        val (suppliedTypes, suppliedFx) = argsSuppliedAnalyzed
        val types = suppliedTypes.toMutableList()
        var fx = suppliedFx
        var subst = recvs.fold(fx.subst) { subst, recv -> substLattice.joinOf(subst, recv.effect.subst) }!!
        val recvTypes = recvs.map { it.value }
        for ((i, arg) in args.withIndex()) {
          val default = (arg as? OpaqueConstant.Default)?.compute ?: continue
          val (defaultT, defaultFxInst) = subst.apply(rec, default, recvTypes + types)
          types[i] = defaultT
          val defaultFx = onInvocationEffect(e, defaultFxInst)
          subst = substLattice.joinOf(subst, defaultFx.subst)!!
          fx = fx join defaultFx
        }
        return Result(types, fx)
      }

      fun callMethod(
        receiver: UExpression?,
        method: PsiMethod,
        args: List<UExpression>,
        extReceiver: UExpression? = receiver,
      ): Result<Type<FX>, R> {
        fun implicitThis() = e.getContainingUClass()?.javaPsi?.let { PsiClassAdapter.translate(typeParams, it) }!!

        val virRecvAns: Result<Type<FX>, R>? =
          when {
            method.isStatic() -> null
            method.isConstructor -> null
            receiver != null -> loopCached(receiver) // TODO nope. See below
            else -> pure(env.receiver(ClassId.of(method.containingClass!!)) ?: implicitThis())
          }

        val extRecvAns: Result<Type<FX>, R>? =
          when {
            !method.isExtension() -> null
            extReceiver != null -> loopCached(extReceiver) // TODO nope. See above
            else -> pure(env.innermostExtensionReceiver() ?: implicitThis())
          }

        val (restTypes, restFx) = instDefaults(listOfNotNull(virRecvAns, extRecvAns), args, mapM(::loopCached, args))

        return when {
          // virtual extension
          // TODO this isn't general. Will run into problems with multiple implcit `this`s.
          virRecvAns != null && extRecvAns != null -> {
            val (virRecvType, virRecvFx) = virRecvAns
            val (extRecvType, extRecvFx) = extRecvAns
            val subst = with(substLattice) { virRecvFx.subst join extRecvFx.subst join restFx.subst }!!
            val (appType, appFx) =
              when {
                method.isFinal() -> subst.apply(rec, Type.MethodRef(method), listOf(virRecvType, extRecvType) + restTypes)
                else ->
                  invokeVirtual(
                    rec,
                    virRecvType to virRecvFx.subst!!,
                    MethodId(method),
                    (listOf(extRecvType) + restTypes) to (substLattice.joinOf(extRecvFx.subst, restFx.subst)!!),
                    Type.Sym.Param("virt*", e.staticContext()),
                    method.containingClass?.let { Type.MethodRef(method) },
                  )
              }
            Result(appType, virRecvFx join extRecvFx join restFx join onInvocationEffect(e, appFx))
          }
          // plain virtual
          virRecvAns != null -> {
            val (virRecvType, virRecvFx) = virRecvAns
            val subst = with(substLattice) { virRecvFx.subst join restFx.subst }!!
            val (appType, appFx) =
              when {
                method.isFinal() -> subst.apply(rec, Type.MethodRef(method), listOf(virRecvType) + restTypes)
                else ->
                  invokeVirtual(
                    rec,
                    virRecvType to virRecvFx.subst!!,
                    MethodId(method),
                    restTypes to restFx.subst!!,
                    Type.Sym.Param("virt", e.staticContext()),
                    method.containingClass?.let { Type.MethodRef(method) },
                  )
              }
            Result(appType, virRecvFx join restFx join onInvocationEffect(e, appFx))
          }
          // static extension
          extRecvAns != null -> {
            val (extRecvType, extRecvFx) = extRecvAns
            val subst = with(substLattice) { extRecvFx.subst join restFx.subst }!!
            val (appType, appFx) = subst.apply(rec, Type.MethodRef(method), listOf(extRecvType) + restTypes)
            Result(appType, extRecvFx join restFx join onInvocationEffect(e, appFx))
          }
          // plain static
          else -> {
            val (appType, appFx) = restFx.subst!!.apply(rec, Type.MethodRef(method), restTypes)
            Result(appType, restFx join onInvocationEffect(e, appFx))
          }
        }
      }

      fun callLambda(receiver: UExpression?, method: ULambdaExpression, args: List<UExpression>): Result<Type<FX>, R> {

        val methodRef =
          localFunctionRef(method)
            ?: method.nameFromSource?.let { env.funAt(it) { it.method.isCompatible(args) } }
            ?: return unsureResult.also { log { "Warning: Don't know what `${method.nameFromSource}` is in `${targetName()}`" } }

        fun KtNamedFunction.implicitThis(): Result<Type<FX>, R> {
          val t = KtTypeReferenceAdapter.translate(typeParams, typeReference) as Type.Application
          return pure(env.receiver(t.constructor)!!)
        }

        val receiver =
          when (val fn = method.sourcePsi) {
            is KtNamedFunction ->
              when {
                !fn.isExtensionDeclaration() -> null
                receiver != null -> {
                  val res = loop(receiver)
                  when (res.value) {
                    methodRef -> fn.implicitThis()
                    else -> res
                  }
                }
                else -> fn.implicitThis()
              }
            else -> null
          }

        val (argTypes, argsFx) = instDefaults(listOfNotNull(receiver), args, mapM(::loop, args))

        return when {
          receiver == null -> {
            val (appType, appFx) = argsFx.subst!!.apply(rec, methodRef, argTypes)
            Result(appType, argsFx join onInvocationEffect(e, appFx))
          }
          else -> {
            val (recvType, recvFx) = receiver
            val subst = substLattice.joinOf(recvFx.subst, argsFx.subst)!!
            val (appType, appFx) = subst.apply(rec, methodRef, listOf(recvType) + argTypes)
            Result(appType, recvFx join argsFx join onInvocationEffect(e, appFx))
          }
        }
      }

      fun call(call: UCallExpression): Result<Type<FX>, R> {
        val method = call.resolveToUElement()
        val samLambda = if (method == null) call.samConvertedLambda() else null
        return when {
          // Kotlin's `Intf { … }` is the lambda, as far as effects go
          samLambda != null -> loop(samLambda)
          // constructor call, with constructor definition missing or explicitly "default"
          call.isConstructorCall() && (method?.javaPsi as? PsiMethod)?.isDefaultConstructor != false -> pure(getType(call))
          method is UMethod -> {
            val psiMethod = method.javaPsi
            val extReceiver = if (psiMethod.isExtension() && isJava(call.lang)) call.valueArguments.firstOrNull() else call.callReceiver()
            val args = completeArguments(typeParams, call, method, Type.MethodRef(psiMethod), UMethod::uastParameters)
            callMethod(call.callReceiver(), psiMethod, args, extReceiver)
          }
          method is ULambdaExpression -> {
            val args = completeArguments(typeParams, call, method, localFunctionRef(method), ULambdaExpression::valueParameters)
            callLambda(call.callReceiver(), method, args)
          }
          else -> {
            fun fail() =
              giveUp(e) {
                "Handle ${e::class.java.simpleName} ${e.renderAbbrev()} with receiver `${call.receiver?.renderAbbrev()}`, resolved method `$method`"
              }

            val recv = call.receiver ?: call.callReceiver() ?: return fail()
            when (val recvDecl = recv.tryResolveUDeclaration()) {
              is UVariable -> {
                val rhs = recvDecl.uastInitializer as? ULambdaExpression ?: return fail()
                callLambda(call.callReceiver(), rhs, completeArguments(typeParams, call, rhs, null, ULambdaExpression::valueParameters))
              }
              // TODO shot in the dark below
              else -> {
                val methodName = call.methodName ?: call.methodIdentifier?.name
                val (recvType, recvFx) = loop(recv)
                val (restTypes, restFx) = mapM(::loop, call.valueArguments)
                when {
                  // Applying extension method whose code we don't have?
                  recvType is Type.Application -> {
                    val (t, _) = giveUp(e) { "Applying extension method whose code we don't have at ${e.uastParent?.renderAbbrev()}" }
                    Result(t, recvFx join restFx)
                  }
                  else -> {
                    fun onNotFound(exc: Module.MethodLookupException? = null) =
                      Result(getType(e), fxInstantiationLattice.unsure).also {
                        log {
                          when (exc) {
                            null,
                            is Module.MethodLookupException.NotFound ->
                              "WARNING: Don't know what method `$methodName` is in `${e.uastParent?.renderAbbrev()}` in `${targetName()}`"

                            is Module.MethodLookupException.Ambiguous -> "ERROR: ${exc.candidates.size} methods found for name ${exc.name}"
                          }
                        }
                      }

                    val subst = substLattice.joinOf(recvFx.subst, restFx.subst)!!

                    val (appType, appFx) =
                      when (methodName) {
                        null -> onNotFound()
                        else -> subst.invokeWildGuess(rec, recvType, methodName, restTypes, ::onNotFound)
                      }

                    Result(appType, recvFx join restFx join onInvocationEffect(e, appFx))
                  }
                }
              }
            }
          }
        }
      }

      ProgressManager.checkCanceled()
      return when (e) {
        is OpaqueConstant -> pure(e.type)
        is ULiteralExpression -> pure(Type.ofLiteral(e.value))
        is UThisExpression -> pure(e.type())
        is USuperExpression -> pure(getType(e))

        // TODO: is this just the Java's `yield` in `switch`?
        is UYieldExpression -> e.expression?.let(::loop) ?: unsureResult
        is USimpleNameReferenceExpression ->
          when (val target = e.resolve()) {
            is KtLightMethod ->
              when {
                target.isAccessor(getter = true) -> callMethod(null, target, listOf())
                else -> e.asName(USimpleNameReferenceExpression::identifier)
              }
            else -> e.asName(USimpleNameReferenceExpression::identifier)
          }
        is UQualifiedReferenceExpression -> {
          val target = e.resolve()
          when {
            target is PsiField -> Result(module[target] ?: translate(target.type), loop(e.receiver).effect)
            target is KtLightMethod && target.isAccessor(getter = true) -> callMethod(e.receiver, target, listOf())
            e.selector is UCallExpression -> loop(e.selector)
            // HACK `getValue` of `Lazy`
            target is PsiMethod && target.name == "getValue" && e.receiver is USimpleNameReferenceExpression ->
              when (val t = env.varAt((e.receiver as USimpleNameReferenceExpression).identifier)) {
                is Type.Lambda -> Result(getType(e.receiver), onInvocationEffect(e, Instantiation(t.body.effect)))
                else -> giveUp(e) { "Handle ${e.renderAbbrev()} of `${e::class.java.simpleName}`" }
              }
            // Kotlin property access to a Java getter (`resources.configuration`): apply the getter as a call,
            // mirroring the `KtLightMethod` accessor branch above
            target is PsiMethod && !target.isStatic() && target.parameterList.isEmpty -> callMethod(e.receiver, target, listOf())
            else -> giveUp(e) { "Handle ${e.renderAbbrev()} of `${e::class.java.simpleName}`" }
          }
        }
        is UCallableReferenceExpression -> {
          fun fail() = unsureResult.also { log { "ERROR: Don't know how to parse method reference ${e.renderAbbrev()}" } }
          when (val method = e.resolve()) {
            is PsiMethod -> {
              val ref = Type.MethodRef(method)
              val (refType, refFx) =
                when {
                  method.isConstructor -> pure(ref)
                  (e.qualifierExpression as? UReferenceExpression)?.resolve() is PsiClass &&
                    method.containingClass.toUElement()?.sourcePsi !is KtObjectDeclaration -> pure(ref)
                  !method.isStatic() || method.isExtension() -> {
                    fun fromExplicit() =
                      e.qualifierExpression?.let { recvExpr ->
                        val (recvType, recvFx) = loop(recvExpr)
                        Result(Type.SpecializedMethodRef(recvType, ref), recvFx)
                      }

                    fun fromImplicit(): Result<Type.SpecializedMethodRef<FX>, R>? {
                      val t = e.qualifierType?.let(::translate) as? Type.Application ?: return null
                      val recvType = env.receiver(t.constructor) ?: return null
                      return pure(Type.SpecializedMethodRef(recvType, ref))
                    }

                    fun default() = pure(Type.SpecializedMethodRef(Type.None, ref)) // TODO

                    fromExplicit() ?: fromImplicit() ?: default()
                  }

                  // regular static
                  else -> pure(ref)
                }
              val errorsAgainstFunIntf: PersistentSet<Error<FX>> = run {
                val funIntf = resolvePossiblyAnnotatedSuperClass(e) ?: return@run persistentSetOf()
                val intfMethodStatus = module.getSAMStatus(funIntf)
                val implStatus = module[ref] ?: return@run persistentSetOf()
                guardImplAgainstStatus(rec, e, intfMethodStatus, ref, implStatus)
              }
              Result(refType, refFx + errorsAgainstFunIntf)
            }
            is PsiVariable -> env.funAt(method.name!!)?.let(::pure) ?: fail()
            else -> fail()
          }
        }
        is UReferenceExpression -> e.asName { it.resolvedName ?: throw UnresolvedNameException(e) }
        is UBlockExpression -> lastM(::loop, e.expressions) ?: unitResult
        is UExpressionList ->
          when (val r = lastM(::loop, e.expressions)) {
            null ->
              when (e.kind) {
                UastSpecialExpressionKind.VARARGS -> pure(Type.EmptyArray)
                else -> unitResult
              }
            else -> {
              val (t, fx) = r
              when (e.kind) {
                UastSpecialExpressionKind.VARARGS -> Result(Type.Ellipsis(t), fx)
                else -> r
              }
            }
          }
        is RestArg -> {
          val (t, fx) = lastM(::loop, e.elems) ?: return pure(Type.EmptyArray)
          Result(Type.Ellipsis(t), fx)
        }
        is OverloadBody -> callMethod(null, e.canonical, e.args)
        is UParenthesizedExpression -> loop(e.expression)
        is ULabeledExpression -> loop(e.expression)
        is UBreakExpression,
        is UContinueExpression,
        is UastEmptyExpression -> emptyResult
        is UReturnExpression -> {
          // Compute the returned value
          val (t, fx) =
            when (val returnExpr = e.returnExpression) {
              null -> unitResult
              else -> loop(returnExpr)
            }
          // Accumulate the returned value at the target
          when (val jumpTarget = e.jumpTarget?.unwrapLabels()) {
            null -> target.accumulate(t)
            else -> returns.find { it.target == jumpTarget }?.accumulate(t) ?: throw UnresolvedReturnTargetException(e, returns)
          }
          // `return` clause, as an expression, computes no value
          Result(Type.None, fx)
        }
        is ULambdaExpression -> {
          // TODO best effort resolving to right super-interface
          val site = argumentSiteOf(e)
          val funIntf = resolvePossiblyAnnotatedSuperClass(e, site)
          val samBases =
            when (val status = funIntf?.let(module::getSAMStatus)) {
              is MethodBody.Status.ForChecking -> listOf(status.upperBound)
              null,
              is MethodBody.Status.ForInference,
              is MethodBody.Status.Abstract -> emptyList()
              is MethodBody.Status.BasicConstructor -> throw IllegalStateException()
            }
          // The SAM interface's own annotation is an obligation on the lambda itself, which no callee summary shadows, so the assumed
          // callee's bounds add to it rather than replace it.
          val mode = inferenceMode(EffectAnnotation.Implicit(assumedMethodGuards(site) + samBases))
          val lambdaParams: List<Pair<String, Type<FX>>> =
            e.parameters.map {
              val param = it.javaPsi as PsiParameter
              val paramType =
                when (val t = param.type) {
                  // TODO
                  is PsiLambdaParameterType,
                  is PsiIntersectionType -> typeLattice.top
                  else -> translate(t)
                }
              param.name to paramType
            }
          val (t, fx) = mode.eval(rec, env.withVars<FX>(lambdaParams), e.body, returns.add(ReturnRecord(e)))
          val r = Type.Lambda(lambdaParams.map { (_, t) -> t }, Result(t, fx.result), funIntf)
          val name = Type.Sym.Param("lam", e.staticContext())
          val subst = fx.subst!!.put(name, r)
          Result(name, bottom.binding(substLattice, subst) + fx.errors)
        }
        is UDeclarationsExpression ->
          lastM(
            step@{ dec ->
              when (dec) {
                is ULocalVariable -> {
                  val decPsi = dec.javaPsi as PsiLocalVariable
                  val rhs = dec.uastInitializer?.let(::loop)
                  val delegeteExpr = (dec.sourcePsi as? KtProperty)?.delegateExpression?.toUElement() as? UExpression
                  val delegate = if (delegeteExpr != null) loop(delegeteExpr) else null
                  val rhsLam =
                    when (val v = rhs?.value) {
                      is Type.Lambda -> v
                      is Type.Sym.Name -> rhs.effect.subst?.get(v) as? Type.Lambda
                      else -> null
                    }
                  val rhsType =
                    // For immutable local bindings, we bypass even the user-declared type to
                    // use the inferred more precise type.
                    if (rhsLam != null && (dec.isImmutable() || decPsi.isEffectivelyFinal())) rhsLam else translate(decPsi.type)
                  // We update the local environment imperatively instead of accumulating it
                  // functionally, because later declarations need to see updates by earlier
                  // declarations.
                  env = env.withVar(decPsi.name, rhsType)
                  if (delegate != null) env = env.withVarDelegate(decPsi.name, delegate.value)
                  when {
                    rhs != null && delegate != null -> rhs.copy(effect = joinOf(rhs.effect, delegate.effect))
                    rhs != null -> rhs
                    delegate != null -> Result(Type.Unit, delegate.effect)
                    else -> emptyResult
                  }
                }
                is UVariable -> unitResult // already added to environment during indexing
                else -> {
                  log { "TODO: Handle ${dec::class.java.simpleName}: ${dec.asSourceString()}" }
                  unitResult
                }
              }
            },
            e.declarations,
          ) ?: unitResult
        is UUnaryExpression -> {
          fun default() = Result(getType(e), loop(e.operand).effect)
          when (e.operator) {
            UastPrefixOperator.INC,
            UastPrefixOperator.DEC,
            UastPostfixOperator.INC,
            UastPostfixOperator.DEC ->
              when (e) {
                is UMultiResolvable -> {
                  val operand = e.operand
                  val fx =
                    e.multiResolve().joinedOver { res ->
                      val method = res.element as? PsiMethod ?: return@joinedOver bottom
                      val (receiver, indices) = operand.lhsReceiverAndIndices() ?: return@joinedOver bottom
                      when {
                        // TODO
                        method.name.startsWith("get") -> callMethod(receiver, method, indices).effect
                        // TODO
                        method.name.startsWith("set") -> callMethod(receiver, method, indices + operand).effect
                        // TODO assuming inc/dec operator
                        method.parameterList.parametersCount == 0 -> callMethod(operand, method, listOf()).effect
                        else -> throw IllegalStateException("Got method `${method.name}` during ${e.renderAbbrev()}")
                      }
                    }
                  Result(e.getExpressionType()?.let(::translate) ?: Type.Int, fx)
                }
                else -> default()
              }
            else -> default()
          }
        }
        is UPolyadicExpression -> {
          fun defaultUnit() = Result(Type.Unit, forM(::loop, e.operands))
          when (e.operator) {
            // Special cases
            UastBinaryOperator.ASSIGN -> {
              val (lhs, rhs) = e.operands
              val target = lhs.tryResolve()
              when {
                target is KtLightMethod && target.name.startsWith("set") -> {
                  val (receiver, indices) = lhs.lhsReceiverAndIndices() ?: return defaultUnit()
                  callMethod(receiver, target, indices + rhs)
                }
                else -> defaultUnit()
              }
            }
            UastBinaryOperator.PLUS_ASSIGN,
            UastBinaryOperator.MINUS_ASSIGN,
            UastBinaryOperator.MULTIPLY_ASSIGN,
            UastBinaryOperator.DIVIDE_ASSIGN,
            UastBinaryOperator.REMAINDER_ASSIGN,
            UastBinaryOperator.AND_ASSIGN,
            UastBinaryOperator.OR_ASSIGN,
            UastBinaryOperator.XOR_ASSIGN,
            UastBinaryOperator.SHIFT_LEFT_ASSIGN,
            UastBinaryOperator.SHIFT_RIGHT_ASSIGN,
            UastBinaryOperator.UNSIGNED_SHIFT_RIGHT_ASSIGN -> {
              val (lhs, rhs) = e.operands
              when (e) {
                is UMultiResolvable -> {
                  val (receiver, indices) = lhs.lhsReceiverAndIndices() ?: return defaultUnit()
                  val fx =
                    e.multiResolve().joinedOver { res ->
                      val method = res.element as? PsiMethod ?: return@joinedOver bottom
                      when {
                        // TODO
                        method.name.startsWith("get") -> callMethod(receiver, method, indices).effect
                        // TODO
                        method.name.startsWith("set") -> callMethod(receiver, method, indices + rhs).effect
                        // TODO assuming the arith op
                        method.parameterList.parametersCount == 2 -> callMethod(lhs, method, listOf(rhs)).effect
                        method.parameterList.parametersCount == 1 -> callMethod(lhs, method, listOf(rhs)).effect
                        else -> throw IllegalStateException("Got method `${method.name}` during ${e.renderAbbrev()}")
                      }
                    }
                  Result(Type.Unit, fx)
                }
                else -> defaultUnit()
              }
            }
            // Call-by-value standard operators
            else -> {
              val fx = forM(::loop, e.operands)
              val t =
                when (e.operator) {
                  is UastBinaryOperator.LogicalOperator,
                  is UastBinaryOperator.ComparisonOperator,
                  is UastBinaryOperator.BitwiseOperator -> Type.Boolean
                  else -> getType(e)
                }
              Result(t, fx)
            }
          }
        }
        is UBinaryExpressionWithType ->
          when (val op = e.operationKind) {
            is UastBinaryExpressionWithTypeKind.InstanceCheck -> Result(Type.Boolean, loop(e.operand).effect)
            is UastBinaryExpressionWithTypeKind.TypeCast -> Result(translate(e.type), loop(e.operand).effect)
            else -> giveUp(e) { "Handle ${e.renderAbbrev()} with operation $op" }
          }
        is UIfExpression -> {
          val (_, condFx) = loop(e.condition)
          val (t, branchesFx) = joinM(::loop, listOfNotNull(e.thenExpression, e.elseExpression))
          Result(t, merge(e.condition, condFx, branchesFx))
        }
        is USwitchExpression -> {
          val condition = e.expression
          val (_, conditionFx) = condition?.let(::loop) ?: emptyResult
          val (t, bodyFx) = joinM(::loop, e.body.expressions)
          Result(t, if (condition != null) merge(condition, conditionFx, bodyFx) else conditionFx join bodyFx)
        }
        is USwitchClauseExpressionWithBody -> {
          val condFx = forM(::loop, e.caseValues + listOfNotNull(e.guard))
          when (val body = lastM(::loop, e.body.expressions)) {
            null -> Result(Type.Unit, condFx)
            else -> Result(body.value, condFx join body.effect)
          }
        }
        is UWhileExpression -> Result(Type.Unit, forM(::loop, listOf(e.condition, e.body)))
        is UDoWhileExpression -> Result(Type.Unit, forM(::loop, listOf(e.condition, e.body)))
        is UForExpression -> Result(Type.Unit, forM(::loop, listOfNotNull(e.declaration, e.condition, e.update, e.body)))
        is UForEachExpression -> {
          val (t1, fx1) = loop(e.iteratedValue)
          val bodyEnv =
            when (val x = e.parameter?.javaPsi as? PsiParameter) {
              null -> env
              else ->
                when {
                  t1 is Type.Application && t1.args.firstOrNull() != null -> env.withVar(x.name, t1.args.first())
                  t1 is Type.Ellipsis -> env.withVar(x.name, t1.element)
                  else -> env // TODO
                }
            }
          val (_, fx2) = eval(rec, bodyEnv, e.body, returns)
          Result(Type.Unit, fx1 join fx2)
        }
        is UObjectLiteralExpression -> {
          val typeArgs = typeParams.values.toList()
          val typeRef = ClassId.of(e.declaration.javaPsi)
          val type = Type.Application(typeRef, typeArgs)
          val errorAgainstFunIntf: PersistentSet<Error<FX>> = run {
            val funIntf = resolvePossiblyAnnotatedSuperClass(e) ?: return@run persistentSetOf()
            guardImplAgainstIntf(rec, e, funIntf, typeRef)
          }
          Result(type, bottom + errorAgainstFunIntf)
        }
        is UThrowExpression -> Result(Type.None, loop(e.thrownExpression).effect)
        is UTryExpression -> {
          val (tryType, tryFx) = loop(e.tryClause)
          val (catchTypes, catchFx) = mapM({ loop(it.body) }, e.catchClauses)
          val finalFx = e.finallyClause?.let(::loop)?.effect ?: bottom
          val t = with(typeLattice) { tryType join catchTypes.joinedOver { it } }
          Result(t, tryFx join catchFx join finalFx)
        }
        is UArrayAccessExpression ->
          when (val call = e.asCall()) {
            null -> {
              val recFx = loop(e.receiver).effect
              val indFx = forM(::loop, e.indices)
              Result(getType(e), recFx join indFx)
            }
            else -> call(call)
          }
        is UCallExpression -> call(e)
        else -> giveUp(e) { "Handle ${e::class.java.simpleName}: `${e.asSourceString()}`" }
      }
    }

    return when (body) {
      is UBlockExpression -> {
        val fx = forM(::loop, body.expressions)
        val lastStm = body.expressions.lastOrNull()
        val res =
          when {
            (body.uastParent as? UMethod)?.isConstructor == true -> translate((body.uastParent as UMethod).getContainingUClass()!!)
            body.expressions.any { it is UReturnExpression } -> target.returns
            // TODO: extract `Nothing` type. Anything else is `Unit`.
            target.returns == Type.None && (lastStm == null || lastStm !is UThrowExpression) -> Type.Unit
            else -> target.returns
          }
        gc(Result(res, fx))
      }
      else -> gc(loop(body))
    }
  }

  private class ReturnRecord<FX> private constructor(val target: UElement, var returns: Type<FX>) {
    constructor(destination: UElement) : this((destination as? UJumpExpression)?.jumpTarget ?: destination, Type.None)

    override fun toString() = "${target.renderAbbrev()} ↦ $returns"
  }

  /** Run [step] on each of [targets] for the joined type and effect [R] */
  private fun <X : ErrorSite, R : EffectResult.Eval<FX>> Mode<FX, R>.joinM(step: (X) -> Result<Type<FX>, R>, targets: List<X>) =
    foldM(typeLattice.bottom, typeLattice::joinOf, step, targets)

  private fun ReturnRecord<FX>.accumulate(t: Type<FX>) {
    returns = typeLattice.joinOf(returns, t)
  }

  private val placeholderInstantiation: InstAns<FX> = Result(typeLattice.top, /* TODO(b/390196415) */ fxInstantiationLattice.unsure)

  /**
   * Assuming an oracle [rec] that knows about existing summaries and their instantiations, either instantiate given statically known
   * receiver, or return a symbolic invocation.
   */
  private fun invokeVirtual(
    rec: (Point<FX>) -> Ans<FX>,
    receiver: Pair<Type<FX>, Subst<FX>>,
    method: MethodId,
    args: Pair<List<Type<FX>>, Subst<FX>>,
    name: Type.Sym.Name?,
    // Avoid silently dropping the call when the analysis knows nothing about the receiver.
    staticTarget: Type.MethodRef? = null,
  ): InstAns<FX> {
    val (receiver, rSubst) = receiver
    if ((receiver == Type.None || receiver == Type.WildCard) && staticTarget != null && assumedSummary(staticTarget) != null) {
      val (argTypes, aSubst) = args
      return substLattice.joinOf(rSubst, aSubst)!!.apply(rec, staticTarget, listOf(receiver) + argTypes)
    }
    fun go(receiver: Type<FX>): InstAns<FX> =
      when (receiver) {
        is Type.Sym -> applyType(rec, receiver to rSubst, method, args, name)
        is Type.Union -> receiver.cases.joinedOver(instantiationLattice, ::go)
        else -> applyType(rec, receiver to rSubst, method, args, name)
      }
    return go(receiver)
  }

  // TODO(b/417750068)
  private fun Subst<FX>.invokeWildGuess(
    rec: (Point<FX>) -> Ans<FX>,
    receiver: Type<FX>,
    methodName: String,
    args: List<Type<FX>>,
    notFound: (Module.MethodLookupException) -> InstAns<FX>,
  ): InstAns<FX> =
    when (receiver) {
      // TODO pass class type arguments too
      is Type.Application ->
        try {
          apply(rec, module.findMethodByName(methodName, receiver.constructor, args), listOf(receiver) + args)
        } catch (e: Module.MethodLookupException) {
          notFound(e)
        }
      is Type.Lambda -> apply(rec, receiver, listOf(receiver) + args)
      is Type.MethodRef -> apply(rec, receiver, args)
      is Type.SpecializedMethodRef -> apply(rec, receiver.ref, listOf(receiver.receiver) + args)
      is Type.Union -> receiver.cases.joinedOver(instantiationLattice) { invokeWildGuess(rec, it, methodName, args, notFound) }
      is Type.Sym,
      is Type.WildCard -> notFound(Module.MethodLookupException.NotFound(methodName))
      is Type.Ellipsis -> throw IllegalArgumentException("Unexpected invocation $receiver.$methodName($args)")
    }

  /** The most specific declaration of [ref], itself or inherited, with a summary or assumption; [ref] itself if there's none */
  private fun knownMethodRef(ref: Type.MethodRef): Type.MethodRef {
    fun isKnown(ref: Type.MethodRef): Boolean = assumptions[ref] != null || module[ref] != null
    return if (isKnown(ref)) ref else inheritedMethodRefs(ref).firstOrNull(::isKnown) ?: ref
  }

  /** Use this method instead of looking up [assumptions] directly to also account for assumptions from super methods */
  private fun assumedSummary(ref: Type.MethodRef): ResultTemplate<FX>? = assumptions[knownMethodRef(ref)]

  /** Instantiate [method]'s summaries at [args] */
  private fun Subst<FX>.apply(rec: (Point<FX>) -> Ans<FX>, method: Instantiable<FX>, args: List<Type<FX>>): InstAns<FX> =
    when (method) {
      is Type.MethodRef -> {
        val method = knownMethodRef(method)
        when (val assumption = assumptions[method]) {
          null ->
            when (val methodDefn = module[method]) {
              // The method isn't indexed (e.g. defined in a file outside the analysis scope, or spurious).
              // If it's explicitly annotated, honor the annotation.
              null ->
                when (val fx = externalAnnotation(method)) {
                  null -> instantiationLattice.bottom
                  else -> Result(typeLattice.unsure, Instantiation(Effect(fx)))
                }
              else -> {
                val (t, methodEffectResult) = rec[method]
                val methodFx: Effect<FX> =
                  when (methodEffectResult) {
                    is Checking<FX> ->
                      Effect(
                        concrete = (methodDefn.status as MethodBody.Status.ForChecking).upperBound.annotated,
                        constraint = methodEffectResult.result,
                      )
                    is Inference<FX> -> methodEffectResult.result
                    is Inapplicable -> effectLattice.bottom
                  // throw IllegalStateException("Applying abstract method $method")
                  }
                val methodSubst = methodEffectResult.subst!!
                substLattice.joinOf(this, methodSubst)!!.apply(rec, methodDefn.initEnvironment.types, methodDefn.domains, t, methodFx, args)
              }
            }
          else ->
            substLattice
              .joinOf(this, assumption.subst)!!
              .apply(rec, assumption.typeBounds, assumption.domains, assumption.range, assumption.effect, args)
        }
      }
      is Type.Lambda -> {
        val (xs, body, intf) = method // TODO make sure applying the right message
        val (t, fx) = body
        // If the functional interface is something like `suspend () -> _`, `args` may have the
        // explicit one for the kontinuation
        // The first argument is the `lambda` itself, which we don't need
        val truncatedArgs = args.subList(1, 1 + xs.size)
        apply(rec, persistentMapOf(), xs, t, fx, truncatedArgs)
      }
    }

  /** Instantiate polymorphic [methodType] and [methodFx] at [args] */
  private fun Subst<FX>.apply(
    rec: (Point<FX>) -> Ans<FX>,
    typeBounds: TypeBounds<FX>,
    methodParams: List<Type<FX>>,
    methodType: Type<FX>,
    methodFx: Effect<FX>,
    args: List<Type<FX>>,
  ): InstAns<FX> {
    val env = substLattice.joinOf(this, Env.bindParams(typeLattice, typeBounds, methodParams, args))!!
    val (instType, fx0) = rec[env, methodType]
    val instFx = env.instEffect(rec, methodFx)
    return Result(instType, instFx.copy(subst = substLattice.joinOf(instFx.subst, fx0.subst)))
  }

  /** Interpret type [t] under [this] environment */
  private fun Subst<FX>.instType(rec: (Point<FX>) -> Ans<FX>, t: Type<FX>): InstAns<FX> =
    when (t) {
      is Type.Sym.Name -> {
        val resolved = this[t]
        when {
          resolved == null -> fxInstantiationLattice.pure(t)
          resolved is Type.Sym.Name || resolved.isConstant() -> rec[this, resolved]
          else -> {
            val (_, fx) = rec[this, resolved]
            Result(t, fx.copy(subst = substLattice.joinOf(fx.subst!!.gc(*fx.result.terms()), gc(t))))
          }
        }
      }
      is Type.Sym.Invoke -> {
        val (recv, recvFx) = instType(rec, t.receiver)
        val (args, argsFx) = instTypes(rec, t.args)
        val (ans, fx) = applyType(rec, recv to recvFx.subst!!, t.method, args to argsFx.subst!!, null)
        Result(
          ans,
          Instantiation(
            with(effectLattice) { recvFx.result join argsFx.result join fx.result },
            with(possibilityLattice<ConstraintFailure<FX>>()) { recvFx.errors join argsFx.errors join fx.errors },
            fx.subst,
          ),
        )
      }
      is Type.Union -> t.cases.joinedOver(instantiationLattice) { instType(rec, it) }
      is Type.Application -> {
        val (ts, fx) = instTypes(rec, t.args)
        Result(t.copy(args = ts), fx)
      }
      is Type.Ellipsis -> {
        val (t, fx) = instType(rec, t.element)
        Result(Type.Ellipsis(t), fx)
      }
      is Type.Lambda -> {
        val (bodyT, bodyFx) = t.body
        val (instBodyT, instBodyTFx) = instType(rec, bodyT)
        val instBodyFx = instEffect(rec, bodyFx)
        Result(
          t.copy(body = Result(instBodyT, instBodyFx.result)),
          Instantiation(effectLattice.bottom, subst = with(substLattice) { instBodyTFx.subst join instBodyFx.subst }),
        )
      }
      is Type.MethodRef -> fxInstantiationLattice.pure(t)
      is Type.SpecializedMethodRef -> {
        val (t1, fx1) = instType(rec, t.receiver)
        Result(t.copy(receiver = t1), fx1)
      }
      is Type.WildCard -> fxInstantiationLattice.unsureResult
    }

  /** Interpret list of types [ts] under [this] environment */
  private fun Subst<FX>.instTypes(rec: (Point<FX>) -> Ans<FX>, ts: List<Type<FX>>): Result<List<Type<FX>>, Instantiation<FX>> {
    var fx = fxInstantiationLattice.bottom
    val ts1 = ts.map { t ->
      val (t1, fx1) = instType(rec, t)
      fx = fxInstantiationLattice.joinOf(fx, fx1)
      t1
    }
    return Result(ts1, fx)
  }

  /** Interpret effect [fx] under [this] environment */
  private fun Subst<FX>.instEffect(rec: (Point<FX>) -> Ans<FX>, fx: Effect<FX>): Instantiation<FX> {
    val (bound, syms, constraints) = fx
    val (instConstraint, constraintFails) = instConstraint(rec, constraints)
    return with(fxInstantiationLattice) {
      Instantiation(Effect(bound, constraint = instConstraint), constraintFails, subst = gc(*instConstraint.terms())) join
        (syms?.joinedOver {
          val fx = rec[this@instEffect, it].effect
          fx.copy(subst = fx.subst!!.gc(*fx.result.terms()))
        } ?: top)
    }
  }

  /** Interpret invocation of [method] on [receiver] and [args] */
  private fun applyType(
    rec: (Point<FX>) -> Ans<FX>,
    receiver: Pair<Type<FX>, Subst<FX>>,
    method: MethodId,
    args: Pair<List<Type<FX>>, Subst<FX>>,
    name: Type.Sym.Name?,
  ): InstAns<FX> =
    when (val r = receiver.first) {
      is Type.Sym -> {
        val invk = Type.Sym.Invoke(r, method, args.first)
        val havocked = havocTypeApp(rec, receiver, method, args)
        when {
          isOpen(receiver.first, receiver.second) -> {
            val sym =
              when (name) {
                null -> Result(invk, Instantiation(Effect(concreteEffect.bottom, persistentSetOf(invk))))
                else ->
                  Result(name, Instantiation(Effect(concreteEffect.bottom, persistentSetOf(name)), subst = persistentMapOf(name to invk)))
              }
            instantiationLattice.joinOf(sym, havocked)
          }
          else -> havocked
        }
      }
      is Type.Union -> r.cases.joinedOver(instantiationLattice) { applyType(rec, it to receiver.second, method, args, name) }
      else -> havocTypeApp(rec, receiver, method, args)
    }

  /** Explore all concrete resulting type and effects from invoking [method] on [receiver] and [args] */
  private fun havocTypeApp(
    rec: (Point<FX>) -> Ans<FX>,
    receiver: Pair<Type<FX>, Subst<FX>>,
    method: MethodId,
    args: Pair<List<Type<FX>>, Subst<FX>>,
  ): InstAns<FX> {
    val seen = hashSetOf<Pair<Type.Sym<FX>, Subst<FX>>>()
    val (args, aSubst) = args
    fun go(receiver: Type<FX>, receiverSubst: Subst<FX>): InstAns<FX> =
      when (receiver) {
        is Type.Sym.Name ->
          when (val resolved = receiverSubst[receiver]) {
            null -> instantiationLattice.bottom
            else -> if (seen.add(receiver to receiverSubst)) go(resolved, receiverSubst.gc(resolved)) else instantiationLattice.bottom
          }
        is Type.Sym.Invoke ->
          if (seen.add(receiver to receiverSubst)) {
            val (receiver1, fx1) = rec[receiverSubst, receiver]
            go(receiver1, fx1.subst!!.gc(receiver1))
          } else instantiationLattice.bottom
        is Type.Union -> receiver.cases.joinedOver(instantiationLattice) { go(it, receiverSubst.gc(it)) }
        is Type.Application ->
          (substLattice.joinOf(receiverSubst, aSubst))!!.apply(rec, Type.MethodRef(receiver.constructor, method), listOf(receiver) + args)
        is Type.Lambda ->
          if (receiver.params.size == args.size)
            (substLattice.joinOf(receiverSubst, aSubst))!!.apply(rec, receiver, listOf(receiver) + args)
          else instantiationLattice.bottom
        is Type.MethodRef -> aSubst.apply(rec, receiver, args)
        is Type.SpecializedMethodRef ->
          (substLattice.joinOf(receiverSubst, aSubst))!!.apply(rec, receiver.ref, listOf(receiver.receiver) + args)
        is Type.WildCard -> placeholderInstantiation
        is Type.Ellipsis -> instantiationLattice.bottom
      }
    return go(receiver.first, receiver.second.gc(receiver.first))
  }

  /** Check whether the [type] expression has free variable (i.e. not explained by [subst]) */
  private fun <FX> isOpen(type: Type<FX>, subst: Subst<FX>): Boolean {
    val seen = hashSetOf<Type.Sym.Name>()
    fun check(t: Type<FX>): Boolean =
      when (t) {
        is Type.Sym.Name ->
          if (seen.add(t)) {
            when (val resolved = subst[t]) {
              null -> true
              else -> check(resolved)
            }
          } else false
        is Type.Sym.Invoke -> check(t.receiver)
        is Type.Union -> t.cases.any(::check)
        else -> false
      }
    return check(type)
  }

  /** Instantiate symbolic effects in the constraint, possibly discovering violations */
  private fun Subst<FX>.instConstraint(
    rec: (Point<FX>) -> Ans<FX>,
    constraint: Constraint<FX>,
  ): Pair<Constraint<FX>, PersistentSet<ConstraintFailure<FX>>> =
    with(constraintLattice) {
      val (concrete, symbolic) = constraint
      var newFails = persistentSetOf<ConstraintFailure<FX>>()
      val concreteInst: Constraint<FX> =
        concrete?.asSequence()?.joinedOver { (l, fx) ->
          val (instL, _ /* TODO ok? */) = rec[this@instConstraint, l].effect
          val (lBound, lSyms, lConstraints) = instL
          if (!concreteEffect.precede(lBound, fx)) {
            val invk =
              when (l) {
                is Type.Sym.Name ->
                  when (val resolved = this@instConstraint[l]) {
                    is Type.Sym -> resolved
                    else -> l
                  }
                else -> l
              }
            newFails += ConstraintFailure(invk, fx, lBound)
          }
          val fromSyms = Constraint(Constraint.concrete(fx, lSyms), persistentMapOf())
          fromSyms join lConstraints
        } ?: return top to newFails
      val symbolicInst: Constraint<FX> = bottom /* TODO */
      return (concreteInst join symbolicInst) to newFails
    }

  private operator fun ((Point<FX>) -> Ans<FX>).get(method: Type.MethodRef) = this(method) as SummAns<FX>

  private operator fun ((Point<FX>) -> Ans<FX>).get(subst: Subst<FX>, type: Type<FX>): InstAns<FX> =
    when {
      subst.isEmpty() -> fxInstantiationLattice.pure(type)
      type is Type.Union -> type.cases.joinedOver(instantiationLattice) { case -> this[subst, case] }
      else -> {
        val subst1 = subst.gc(type)
        when {
          subst1.isEmpty() -> fxInstantiationLattice.pure(type)
          else -> this(Point.Instantiation(subst1, type)) as InstAns<FX>
        }
      }
    }

  /** [e]'s enclosing call, with the callee and the parameter [e] is passed as resolved once, for the resolution-hungry helpers to share */
  private fun argumentSiteOf(e: UExpression): ArgumentSite? {
    val call = e.uastParent as? UCallExpression ?: return null
    return if (call.samConvertedLambda() == e) argumentSiteOf(call) else ArgumentSite(call, e)
  }

  /** The lambda in Kotlin's `Intf { ... }`, which UAST presents as an unresolvable constructor call of the interface */
  private fun UCallExpression.samConvertedLambda(): ULambdaExpression? {
    if (!isConstructorCall() || resolve() != null) return null
    val lambda = valueArguments.singleOrNull() as? ULambdaExpression ?: return null
    return lambda.takeIf { (classReference?.resolve() as? PsiClass)?.isInterface == true }
  }

  private class ArgumentSite(val call: UCallExpression, arg: UExpression) {
    val callee: PsiMethod? = call.resolve()
    val param: PsiParameter? = call.getParameterForArgument(arg)

    /** The callee as the module and assumption tables key it, or null when it can't be keyed (no containing class) */
    val calleeRef: Type.MethodRef?
      get() = callee?.takeIf { it.containingClass != null }?.let(Type<*>::MethodRef)

    /** Position of the argument in the callee's assumption domain, which leads with the receiver for virtual callees */
    val domainIndex: Int?
      get() {
        val ref = calleeRef ?: return null
        val index = callee!!.parameterList.getParameterIndex(param ?: return null)
        return if (index < 0) null else index + if (ref.method.isVirtual) 1 else 0
      }

    /** The single abstract method a lambda passed here implements, per the parameter's declared type */
    val samMethod: MethodId?
      get() = param?.type?.let(LambdaUtil::getFunctionalInterfaceMethod)?.let { MethodId(it) }
  }

  private fun resolvePossiblyAnnotatedSuperClass(e: UExpression, site: ArgumentSite? = argumentSiteOf(e)): ClassId? {
    fun typeOf(t: PsiType?) = (t as? PsiClassType)?.let(ClassId::of)
    fun default() =
      when {
        e is ULambdaExpression -> typeOf(e.functionalInterfaceType)
        else ->
          when (val parent = e.uastParent) {
            is UCallExpression -> typeOf(site?.param?.type)
            is ULocalVariable -> if (e.isDelegateOf(parent)) null else typeOf((parent.javaPsi as PsiVariable).type)
            else -> null
          }
      }

    if (site == null) return default()
    val param = site.param ?: return default()
    val calleeRef = site.calleeRef ?: return typeOf(param.type)
    val calleeHeader = module[calleeRef] ?: return typeOf(param.type)
    val paramBound =
      with(calleeHeader.initEnvironment) { types[boundParamNames[param.name] ?: return typeOf(param.type)] } ?: return typeOf(param.type)
    return when {
      paramBound.size == 1 -> {
        val bound = paramBound.first() as? Type.Application ?: return typeOf(param.type)
        bound.constructor as? ClassId.Guarded ?: typeOf(param.type)
      }
      else -> typeOf(param.type)
    }
  }

  // Keyed on the overriding method's own descriptor, which also covers literals over abstract classes, where there's no SAM method to find
  private fun assumedObjectLiteralGuards(method: MethodBody<FX>): List<EffectAnnotation.Explicit<FX>> {
    val uMethod = method.source as? UMethod ?: return listOf()
    val literal = uMethod.getContainingUClass()?.uastParent as? UObjectLiteralExpression ?: return listOf()
    val site = argumentSiteOf(literal) ?: return listOf()
    return assumedMethodGuards(site, MethodId(uMethod.javaPsi))
  }

  private fun assumedMethodGuards(site: ArgumentSite?, samMethod: MethodId? = site?.samMethod): List<EffectAnnotation.Explicit<FX>> {
    val calleeRef = site?.calleeRef ?: return listOf()
    val assumption = assumedSummary(calleeRef) ?: return listOf()
    val domainIndex = site.domainIndex ?: return listOf()
    val domain = assumption.domains.getOrNull(domainIndex) as? Type.Sym ?: return listOf()
    val bounds = assumption.effect.constraint.concreteUpperbounds ?: return listOf()
    // Constraint keys may be generated symbols standing for the actual invocations, via the template's substitution. A single step
    // suffices for the templates built and loaded today; a longer `Name → Name` chain would only degrade to the whole-call report.
    fun resolve(sym: Type.Sym<FX>): Type.Sym<FX> =
      when (sym) {
        is Type.Sym.Name -> (assumption.subst[sym] as? Type.Sym) ?: sym
        else -> sym
      }
    return bounds.mapNotNull { (invocation, bound) ->
      val resolved = resolve(invocation)
      // A null `samMethod` (undeterminable SAM) degrades to matching on the receiver alone — all today's assumptions warrant
      when {
        resolved is Type.Sym.Invoke && resolve(resolved.receiver) == domain && (samMethod == null || resolved.method == samMethod) ->
          EffectAnnotation.Explicit(bound, site.call)
        else -> null
      }
    }
  }

  /** Given [method] and user-supplied arguments in [call], fill in default arguments from [method] */
  private fun <M : UElement> completeArguments(
    typeParams: Map<String, Type.Sym.Param>,
    call: UCallExpression,
    method: M,
    methodRef: Type.MethodRef?,
    params: M.() -> List<UParameter>,
  ): List<UExpression> {
    val allParams = method.params()
    val firstParam = allParams.firstOrNull()
    return when {
      // Discard the extension receiver: it is not among the value arguments. `getArgumentForParameter` indexes the
      // physical parameter list, receiver included, so lookups for the remaining parameters must shift past it
      // (except in the `ArrayAccessAsCallExpression` encoding, which has no receiver parameter).
      firstParam != null && (firstParam.nameFromSource?.startsWith("$") != false) -> {
        val offset = if (call.isArrayAccess()) /* TODO hack against ArrayAccessAsCall */ 0 else 1
        val paramsSansReceiver = allParams.subList(1, allParams.size)
        completeArguments(typeParams, call, methodRef, paramsSansReceiver, offset)
      }
      else -> completeArguments(typeParams, call, methodRef, method.params())
    }
  }

  private fun completeArguments(
    typeParams: Map<String, Type.Sym.Param>,
    call: UCallExpression,
    methodRef: Type.MethodRef?,
    params: List<UParameter>,
    argOffset: Int = 0,
  ) =
    when {
      // Common case: don't resort to `getArgumentForParameter` args already match!
      params.size == call.valueArguments.size && params.none { it.isVararg() } && !call.hasComplexArgList() -> call.valueArguments
      else ->
        params.mapIndexed { i, param ->
          val paramPsi = param.javaPsi as PsiParameter
          val paramName = paramPsi.name
          val arg =
            call.getArgumentForParameter(i + argOffset)
              ?: run {
                val type = PsiTypeAdapter.translate(typeParams, paramPsi.type)
                val default =
                  if (param.uastInitializer == null) null else methodRef?.let { it.copy(method = it.method.defaultArgumentOf(paramName)) }
                if (default == null) {
                  log { "WARNING: Can't retrieve default argument for $paramName, supplying $type" }
                  OpaqueConstant.Pure(type)
                } else OpaqueConstant.Default(type, default)
              }
          // TODO (b/406877361)
          when {
            paramPsi.type !is PsiEllipsisType -> arg
            arg is UExpressionList || arg is OpaqueConstant -> arg
            i >= call.valueArguments.size -> OpaqueConstant.Pure(Type.EmptyArray)
            else -> {
              // TODO hack against `ArrayAccessAsCallExpression`
              val max = call.valueArgumentCount - (if (call.isArrayAccess()) 1 else 0)
              RestArg(call.valueArguments.subList(i, max))
            }
          }
        }
    }

  private fun UCallExpression.hasComplexArgList(): Boolean =
    (sourcePsi as? KtCallExpression)?.valueArguments?.any { it.children.size > 1 } == true

  private fun UParameter.isVararg(): Boolean =
    (sourcePsi as? KtParameter)?.isVarArg == true || (javaPsi as? PsiParameter)?.isVarArgs == true

  private fun UCallExpression.isArrayAccess() = javaClass.canonicalName == "com.android.tools.lint.detector.api.ArrayAccessAsCallExpression"

  private fun <R : EffectResult.Eval<FX>> Mode<FX, R>.guardImplAgainstIntf(
    rec: (Point<FX>) -> Ans<FX>,
    arg: UExpression,
    intfId: ClassId,
    implId: ClassId,
  ): PersistentSet<Error<FX>> {
    if (intfId == implId) return persistentSetOf()
    val intfs = module[intfId] ?: return persistentSetOf()
    val impls = module[implId] ?: return persistentSetOf()
    return intfs.entries.flatMapToPersistentSet { (methodIntf, methodIntfHeader) ->
      val methodImplHeader = impls[methodIntf] ?: return@flatMapToPersistentSet persistentSetOf()
      guardImplAgainstStatus(rec, arg, methodIntfHeader.status, Type.MethodRef(implId, methodIntf), methodImplHeader)
    }
  }

  private fun <R : EffectResult.Eval<FX>> Mode<FX, R>.guardImplAgainstStatus(
    rec: (Point<FX>) -> Ans<FX>,
    arg: UExpression,
    intfMethodStatus: MethodBody.Status<FX>,
    implMethodRef: Type.MethodRef,
    methodImplHeader: MethodBody<FX>,
  ): PersistentSet<Error<FX>> {
    var result = persistentSetOf<Error<FX>>()

    when (intfMethodStatus) {
      is MethodBody.Status.ForChecking -> {
        val baseAnn = intfMethodStatus.upperBound
        val annValue = baseAnn.annotated
        when (val assumption = assumptions[implMethodRef]) {
          null ->
            when (val implFx = rec[implMethodRef].effect) {
              is Inference -> {
                val (concrete, /* TODO ignored, unsound */ _, _) = implFx.result
                if (!concreteEffects.precede(concrete, annValue)) {
                  result += Error.ConflictingInference(arg, concrete, baseAnn)
                }
              }
              is Checking -> {
                val implCheckedFx = (methodImplHeader.status as MethodBody.Status.ForChecking).upperBound.annotated
                if (!concreteEffects.precede(implCheckedFx, annValue)) {
                  result += Error.ConflictingInference(arg, implCheckedFx, baseAnn)
                }
              }
              is Inapplicable -> throw IllegalStateException()
            }
          else -> {
            val (concrete, /* TODO ignored, unsound*/ _, _) = assumption.effect
            if (!concreteEffects.precede(concrete, annValue)) {
              result += Error.ConflictingInference(arg, concrete, baseAnn)
            }
          }
        }
      }
      is MethodBody.Status.ForInference,
      is MethodBody.Status.Abstract -> {}
      is MethodBody.Status.BasicConstructor -> throw IllegalStateException()
    }

    return result
  }

  private sealed class Mode<FX, R : EffectResult.Eval<FX>>(
    val concreteEffects: Lattice<FX>,
    val effects: Lattice<R>,
    val constraintLattice: Lattice<Constraint<FX>>,
  ) : Lattice<R> by effects, EffectfulComputation<R> {

    class Inference<FX>(
      val bases: List<EffectAnnotation.Explicit<FX>>,
      concreteEffects: Lattice<FX>,
      effects: Lattice<EffectResult.Inference<FX>>,
      constraintLattice: Lattice<Constraint<FX>>,
    ) : Mode<FX, EffectResult.Inference<FX>>(concreteEffects, effects, constraintLattice) {
      private val upperBound = bases.fold(concreteEffects.top) { acc, base -> concreteEffects.meetOf(acc, base.annotated) }

      override fun onInvocationEffect(source: UExpression, fxInst: Instantiation<FX>): EffectResult.Inference<FX> {
        val (fx, failures, subst) = fxInst

        // Accumulate errors
        var errors = persistentSetOf<Error<FX>>()
        when (fx.concrete) {
          concreteEffects.top -> errors += Error.CallingTop(source)
          else ->
            for (base in bases) {
              if (!concreteEffects.precede(fx.concrete, base.annotated)) {
                errors += Error.ConflictingInference(source, fx.concrete, base)
                break
              }
            }
        }
        errors += failures.at(source)

        // Accumulate constraints
        val constraintsFromBase =
          bases.joinedOver(constraintLattice) { (baseAnn, _) ->
            Constraint(Constraint.concrete(baseAnn, fx.invocations), persistentMapOf())
          }

        return Inference(
          fx.copy(
            concrete = concreteEffects.meetOf(upperBound, fx.concrete),
            constraint = constraintLattice.joinOf(fx.constraint, constraintsFromBase),
          ),
          errors,
          subst,
        )
      }

      override fun merge(
        context: ErrorSite,
        left: EffectResult.Inference<FX>,
        right: EffectResult.Inference<FX>,
      ): EffectResult.Inference<FX> {
        val joined = left join right
        return with(concreteEffects) {
          when {
            left.errors == errorSetLattice<FX>().bottom &&
              right.errors == errorSetLattice<FX>().bottom &&
              left.result.concrete != top &&
              right.result.concrete != top &&
              joined.result.concrete == top ->
              joined.copy(errors = persistentSetOf(Error.IntroducingTop(context, left.result.concrete, right.result.concrete)))
            else -> joined
          }
        }
      }

      override fun gc(result: Result<Type<FX>, EffectResult.Inference<FX>>) =
        result.copy(effect = result.effect.copy(subst = result.effect.subst!!.gc(result.value, *result.effect.result.terms())))
    }

    class Checking<FX>(
      val annotation: FX,
      concreteEffects: Lattice<FX>,
      effects: Lattice<EffectResult.Checking<FX>>,
      constraintLattice: Lattice<Constraint<FX>>,
    ) : Mode<FX, EffectResult.Checking<FX>>(concreteEffects, effects, constraintLattice) {
      override fun onInvocationEffect(source: UExpression, fxInst: Instantiation<FX>) =
        with(concreteEffects) {
          val (fx, failures, subst) = fxInst
          var errors = persistentSetOf<Error<FX>>()
          if (!(fx.concrete precedes annotation)) errors += Error.ExceedingAnnotation(annotation, fx.concrete, source)
          errors += failures.at(source)
          val generatedConstraints = Constraint.concrete(annotation, fx.invocations)
          Checking(constraintLattice.joinOf(fx.constraint, Constraint(generatedConstraints, persistentMapOf())), errors, subst)
        }

      override fun gc(result: Result<Type<FX>, EffectResult.Checking<FX>>) =
        result.copy(effect = result.effect.copy(subst = result.effect.subst!!.gc(result.value, *result.effect.result.terms())))
    }

    abstract fun onInvocationEffect(source: UExpression, fxInst: Instantiation<FX>): R

    abstract fun gc(result: Result<Type<FX>, R>): Result<Type<FX>, R>
  }

  private class UnresolvedNameException(val element: UElement) : Exception()

  private class UnresolvedReturnTargetException(val statement: UElement, val targets: List<ReturnRecord<*>>) : Exception()
}

/** Whether [this] expression is the delegate of [variable] (as in `val x by delegate`) */
private fun UExpression.isDelegateOf(variable: UVariable): Boolean =
  (variable.sourcePsi as? KtProperty)?.delegateExpression.let { it != null && it == sourcePsi }

/** Strip labels off `lbl@ (lbl2@ e)`, giving the expression `e` that the label(s) name */
private tailrec fun UElement.unwrapLabels(): UElement = if (this is ULabeledExpression) expression.unwrapLabels() else this

private val <T> Lattice<T>.emptyResult: Result<Type<Nothing>, T>
  get() = pure(Type.None)

private val <T> Lattice<T>.unitResult: Result<Type<Nothing>, T>
  get() = pure(Type.Unit)

/**
 * The "effect" information returned is a little different depending on whether we're inferring, checking, or instantiating.
 * - [Inference] represents inferred [Effect] as well as [errors] during the process.
 * - [Checking] represents implied [Constraint] during checking, without inferring anything, as well as errors during the process.
 * - [Instantiation] represents internally instantiated [Effect]. Instantiation is agnostic of call sites, so results can be shared. In
 *   particular, the [ConstraintFailure] doesn't have any call site attached to it yet, compared to [Error.FailingConstraint].
 */
sealed class EffectResult<out FX> {
  abstract val errors: UnboundedSet<*>
  abstract val result: Any?
  abstract val subst: Subst<FX>?

  sealed class Eval<out FX> : EffectResult<FX>() {
    abstract override val errors: UnboundedSet<Error<FX>>
  }

  data class Inference<out FX>(
    override val result: Effect<FX>,
    override val errors: UnboundedSet<Error<FX>>,
    override val subst: Subst<FX>? = persistentMapOf(),
  ) : Eval<FX>()

  // TODO: Also generate constraints on higher-order arguments
  data class Checking<out FX>(
    override val result: Constraint<FX>,
    override val errors: UnboundedSet<Error<FX>>,
    override val subst: Subst<FX>? = persistentMapOf(),
  ) : Eval<FX>()

  data object Inapplicable : Eval<Nothing>(), Lattice<Inapplicable> {
    override val errors = persistentSetOf<Nothing>()
    override val result = null
    override val subst: Subst<Nothing>
      get() = persistentMapOf()

    override val bottom
      get() = this

    override val top
      get() = this

    override fun joinOf(first: Inapplicable, second: Inapplicable) = this

    override fun meetOf(first: Inapplicable, second: Inapplicable) = this

    override fun precede(first: Inapplicable, second: Inapplicable) = true
  }

  data class Instantiation<out FX>(
    override val result: Effect<FX>,
    override val errors: UnboundedSet<ConstraintFailure<FX>> = persistentSetOf(),
    override val subst: Subst<FX>? = persistentMapOf(),
  ) : EffectResult<FX>()

  final override fun toString() =
    when (this) {
      is Inapplicable -> "\uD83D\uDD35"
      else -> "$result ${errors.format()} [${subst?.let(::showSubst) ?: ""}]"
    }
}

private operator fun <FX, R : EffectResult.Eval<FX>> R.plus(moreErrors: UnboundedSet<Error<FX>>): R =
  when (this) {
    is Inference<*> -> copy(errors = errors unionedWith moreErrors) as R
    is Checking<*> -> copy(errors = errors unionedWith moreErrors) as R
    else -> throw IllegalStateException("Unexpected: ${this::class.java.simpleName}")
  }

private fun <FX, R : EffectResult.Eval<FX>> R.binding(substLattice: Lattice<Subst<FX>?>, subst: Subst<FX>): R =
  when (this) {
    is Inference<*> -> copy(subst = substLattice.joinOf(this.subst!!, subst)) as R
    is Checking<*> -> copy(subst = substLattice.joinOf(this.subst!!, subst)) as R
    else -> throw IllegalStateException("Unexpected: ${this::class.java.simpleName}")
  }

private typealias InstAns<FX> = Result<Type<FX>, Instantiation<FX>>

private typealias SummAns<FX> = Result<Type<FX>, EffectResult.Eval<FX>>

typealias Ans<FX> = Result<Type<FX>, EffectResult<FX>>

private fun <R> UnboundedSet<R>.format() =
  when {
    this == null -> "✗"
    this.isEmpty() -> "✓"
    else -> "(errors: ${joinToString()})"
  }

private sealed class OpaqueConstant : UExpression {
  abstract val type: Type<Nothing>

  override val uastParent = null
  override val psi = null

  override fun asLogString() = "⦉$type⦊"

  override fun asRenderString() = asLogString()

  override fun asSourceString() = asLogString()

  override fun toString() = asLogString()

  override val uAnnotations
    get() = listOf<UAnnotation>()

  data class Pure(override val type: Type<Nothing>) : OpaqueConstant()

  data class Default(override val type: Type<Nothing>, val compute: Type.MethodRef) : OpaqueConstant()
}

/**
 * The body of a generated JVM overload that calls to the [canonical] method, passing the overload's own parameters, whose types [env]
 * binds, and leaving the rest to their defaults
 */
internal class OverloadBody(override val uastParent: UMethod, val canonical: PsiMethod, env: Env<Nothing>) : UExpression {
  val args: List<UExpression> = run {
    val suppliedParams = uastParent.javaPsi.parameters.asSequence().mapNotNull { it.name }.toSet()
    val canonicalRef = Type.MethodRef(canonical)
    canonical.parameterList.parameters.drop(if (canonical.isExtension()) 1 else 0).map { param ->
      when (param.name) {
        in suppliedParams -> OpaqueConstant.Pure(env.vars[param.name]!!)
        else ->
          OpaqueConstant.Default(
            PsiTypeAdapter.translate(env.boundParamNames, param.type),
            canonicalRef.copy(method = canonicalRef.method.defaultArgumentOf(param.name)),
          )
      }
    }
  }

  override val psi = null

  override fun asLogString() = "↪ ${canonical.name}(${args.joinToString(transform = UExpression::asLogString)})"

  override fun asRenderString() = asLogString()

  override fun asSourceString() = asLogString()

  override fun toString() = asLogString()

  override val uAnnotations
    get() = listOf<UAnnotation>()
}

// TODO (b/406877361)
private data class RestArg(val elems: List<UExpression>) : UExpression {
  override val uastParent = null
  override val psi = null

  override fun asLogString() = joinString(UExpression::asLogString)

  override fun asRenderString() = joinString(UExpression::asRenderString)

  override fun asSourceString() = joinString(UExpression::asSourceString)

  override val uAnnotations = listOf<Nothing>()

  private fun joinString(onElem: (UExpression) -> String) = "[|${elems.joinToString(transform = onElem)}|]"
}

private fun UExpression.lhsReceiverAndIndices(): Pair<UExpression?, List<UExpression>>? =
  when (this) {
    is UQualifiedReferenceExpression -> receiver to listOf()
    is UArrayAccessExpression -> receiver to indices
    is USimpleNameReferenceExpression -> null to listOf()
    else -> null
  }

// TODO(b/405135846)
private fun UCallExpression.callReceiver(): UExpression? =
  receiver
    ?: when (val src = sourcePsi) {
      is KtCallExpression -> (src.calleeExpression.toUElement() as? UExpression)?.takeIf { it.getExpressionType() != null }
      else -> null
    }

private fun MethodId.isCompatible(args: List<UExpression>): Boolean =
  // TODO must check the types too!!
  paramTags.size == args.size

/** @return If [this] has no type variable and not growing */
private fun Type<*>.isConstant(): Boolean =
  when (this) {
    is Type.Application -> args.all(Type<*>::isConstant)
    is Type.Ellipsis -> element.isConstant()
    is Type.SpecializedMethodRef -> receiver.isConstant()
    is Type.Union -> cases.all(Type<*>::isConstant)
    is Type.MethodRef,
    is Type.WildCard -> true
    is Type.Lambda,
    is Type.Sym -> false
  }

private fun <FX> Constraint<FX>.terms(): Array<Type.Sym<FX>> = concreteUpperbounds?.keys?.toTypedArray() ?: emptyArray()

private fun <FX> Effect<FX>.terms(): Array<Type.Sym<FX>> = (invocations?.toTypedArray() ?: emptyArray()) + constraint.terms()

/**
 * @return A substitution like [this], but only covering free variables from [roots].
 *
 * This avoids (1) redundant representations of the type, and (2) needless overapproximation of the same variable due to lingering unrelated
 * substitutions.
 */
private fun <FX> Subst<FX>.gc(vararg roots: Type<FX>): Subst<FX> {
  if (isEmpty()) return emptySubst
  val seen = hashSetOf<Type.Sym.Name>()
  // We remove dead variables from the original substitution instead of rebuilding from live ones,
  // to maximize reuse of the original data structure
  val dead = builder()

  val queue = roots.toMutableList()

  fun visit(t: Type<FX>) {
    if (dead.isEmpty()) return
    when (t) {
      is Type.Sym.Name ->
        if (seen.add(t)) {
          val t1 = get(t) ?: return
          dead.remove(t)
          queue.add(t1)
        }
      is Type.Sym.Invoke -> {
        visit(t.receiver)
        t.args.forEach(::visit)
      }
      is Type.Application -> t.args.forEach(::visit)
      is Type.Ellipsis -> visit(t.element)
      is Type.Lambda -> { // all lambdas are monomorphic and do not introduce type variables
        visit(t.body.value)
        t.body.effect.invocations?.forEach(::visit)
      }
      is Type.SpecializedMethodRef -> visit(t.receiver)
      is Type.Union -> t.cases.forEach(::visit)
      is Type.MethodRef,
      is Type.WildCard -> {}
    }
  }

  while (queue.isNotEmpty()) {
    visit(queue.removeLast())
    if (dead.isEmpty()) return this
  }

  if (dead.size == size) return emptySubst

  val accFromThis = builder()
  for ((x, _) in dead) accFromThis.remove(x)
  return accFromThis.build()
}
