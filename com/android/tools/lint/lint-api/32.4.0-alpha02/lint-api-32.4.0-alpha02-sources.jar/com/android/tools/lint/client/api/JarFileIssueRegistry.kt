/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.tools.lint.client.api

import com.android.SdkConstants
import com.android.SdkConstants.DOT_CLASS
import com.android.SdkConstants.VALUE_FALSE
import com.android.SdkConstants.VALUE_TRUE
import com.android.tools.lint.detector.api.CURRENT_API
import com.android.tools.lint.detector.api.Issue
import com.android.tools.lint.detector.api.Project
import com.android.tools.lint.detector.api.Severity
import com.android.tools.lint.detector.api.describeApi
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.lang.ref.SoftReference
import java.net.URLClassLoader
import java.util.Locale
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.jar.Attributes
import java.util.jar.JarFile
import java.util.regex.Pattern

/**
 * An [IssueRegistry] for a custom lint rule jar file. The rule jar should provide a manifest entry with the key `Lint-Registry` and the
 * value of the fully qualified name of an implementation of [IssueRegistry] (with a default constructor).
 *
 * NOTE: The custom issue registry should not extend this file; it should be a plain IssueRegistry! This file is used internally to wrap the
 * given issue registry.
 */
class JarFileIssueRegistry
private constructor(
  client: LintClient,
  /** The jar file the rules were loaded from. */
  val jarFile: File,
  /** The custom lint check's issue registry that this [JarFileIssueRegistry] wraps. */
  registry: IssueRegistry,
  /** Vendor for this lint registry. */
  override val vendor: Vendor,
) : IssueRegistry() {

  override fun cacheable(): Boolean = LintClient.isStudio

  override val issues: List<Issue> = registry.issues.toList()
  private val timestamp: Long = jarFile.lastModified()

  override val isUpToDate: Boolean
    get() = timestamp == jarFile.lastModified()

  init {
    val loader = registry.javaClass.classLoader
    if (loader is URLClassLoader) {
      loadAndCloseURLClassLoader(client, jarFile, loader)
    }
  }

  override val api: Int = registry.api
  override val minApi: Int = registry.minApi
  override val maxApi: Int = registry.maxApi

  override val deletedIssues: List<String> = registry.deletedIssues

  companion object Factory {
    /**
     * Pattern for matching lint jar paths in Gradle's cache, like
     * ../../../../../.gradle/caches/transforms-3/4f61605fce02e0e38b0af6e34f10c4a6/transformed/lifecycle-runtime-ktx-2.2.0/jars/lint.jar and
     * on Windows,
     * C:\users\example\.gradle\caches\transforms-3\4f61605fce02e0e38b0af6e34f10c4a6\transformed\annotation-experimental-1.0.0\jars\lint.jar.
     */
    private val ARTIFACT_PATTERN =
      Pattern.compile(
        ".*[/\\\\].gradle[/\\\\]caches[/\\\\]transforms-[0-9]+[/\\\\][0-9a-f]+[/\\\\]transformed[/\\\\](.+)[/\\\\]jars[/\\\\]lint\\.jar$"
      )

    /** Service key for automatic discovery of lint rules. */
    private const val SERVICE_KEY = "META-INF/services/com.android.tools.lint.client.api.IssueRegistry"

    /**
     * Manifest constant for declaring an issue provider.
     *
     * Example: Lint-Registry-v2: foo.bar.CustomIssueRegistry.
     */
    private const val MF_LINT_REGISTRY = "Lint-Registry-v2"

    /** Older key: these are for older custom rules. */
    private const val MF_LINT_REGISTRY_OLD = "Lint-Registry"

    /**
     * Manifest constant for revision number, increasing with updates.
     *
     * Example: Lint-Revision: 3
     */
    private const val MF_LINT_REVISION = "Lint-Revision"

    /** Cache of custom lint check issue registries. */
    private val cache = ConcurrentHashMap<File, SoftReference<JarFileIssueRegistry>>()

    /**
     * Mapping files with verification failures to their last modified timestamps. Only failures with isolated [LintDriver] and false
     * skipVerification are cached.
     */
    private val failureCache = ConcurrentHashMap<File, Long>()

    /** Known issue id's we've ignored because the implemented was incompatible */
    private val rejectedIssueIds = CopyOnWriteArraySet<String>()

    /**
     * Loads custom rules from the given list of jar files and returns a list of [JarFileIssueRegistry] instances.
     *
     * It will also deduplicate issue registries, since in Gradle projects with local lint.jar's it's possible for the same lint.jar to be
     * handed back multiple times with different paths through various separate dependencies.
     */
    fun get(
      client: LintClient,
      jarFiles: Collection<File>,
      currentProject: Project? = null,
      driver: LintDriver? = null,
      skipVerification: Boolean = false,
    ): List<JarFileIssueRegistry> {
      val registryMap = findRegistries(client, jarFiles)
      if (registryMap.isEmpty()) {
        return emptyList()
      }

      val capacity = jarFiles.size + 1
      val registries = ArrayList<JarFileIssueRegistry>(capacity)

      for ((registryClass, jarFiles) in registryMap) {
        val registry = get(client, registryClass, jarFiles, currentProject, driver, skipVerification) ?: continue
        registries.add(registry)
      }

      return registries
    }

    /**
     * Returns a [JarFileIssueRegistry] for the given issue registry class name and jar files, with caching. Only the first verified item in
     * [jarFiles] are processed to create the [JarFileIssueRegistry].
     */
    private fun get(
      client: LintClient,
      registryClassName: String,
      jarFiles: List<File>,
      currentProject: Project?,
      driver: LintDriver?,
      skipVerification: Boolean,
    ): JarFileIssueRegistry? {
      val useFailureCache = !skipVerification && driver?.isIsolated() == true && LintClient.isStudio

      for (jarFile in jarFiles) {
        val reference = cache[jarFile]
        if (reference != null) {
          val registry = reference.get()
          if (registry != null && registry.isUpToDate) {
            return registry
          }
        }
        if (useFailureCache && failureCache[jarFile]?.equals(jarFile.lastModified()) == true) {
          if (logJarProblems()) {
            client.log(Severity.WARNING, null, "Skipping loading of $jarFile, as it previously failed to be loaded.")
          }
          continue
        }
        try {
          // Ensure that the scope-to-detector map doesn't return stale results
          reset()

          val userRegistry = loadIssueRegistry(client, jarFile, registryClassName, currentProject, driver, skipVerification, true)
          if (userRegistry != null) {
            val vendor = getVendor(client, userRegistry, jarFile)
            val jarIssueRegistry = JarFileIssueRegistry(client, jarFile, userRegistry, vendor)
            for (issue in userRegistry.issues) {
              issue.registry = jarIssueRegistry
              if (issue.defaultSeverity === Severity.IGNORE && logJarProblems()) {
                client.log(
                  Severity.ERROR,
                  null,
                  "Issue ${issue.id} has defaultSeverity=IGNORE; that's " + "not valid. Use enabledByDefault=false instead.",
                )
              }
            }
            cache[jarFile] = SoftReference(jarIssueRegistry)
            return jarIssueRegistry
          }
        } catch (e: Throwable) {
          if (logJarProblems()) {
            client.log(e, "Could not load custom lint check jar file %1\$s", jarFile)
          }
        }
        if (useFailureCache) {
          failureCache[jarFile] = jarFile.lastModified()
        }
      }
      return null
    }

    /** Clear out any cached jar files. */
    fun clearCache() {
      cache.clear()
    }

    /** Combine one or more issue registries into a single one. */
    fun join(vararg registries: IssueRegistry): IssueRegistry {
      return if (registries.size == 1) {
        registries[0]
      } else {
        CompositeIssueRegistry(registries.toList())
      }
    }

    /** Verifies that the given issue jar [jarFile] is compatible. */
    private fun verify(client: LintClient, jarFile: File): LintJarVerifier {
      val skip =
        (System.getProperty("android.lint.skip.bytecode.verifier") ?: System.getenv("ANDROID_LINT_SKIP_BYTECODE_VERIFIER")) == VALUE_TRUE
      val verifier = LintJarVerifier(client, jarFile, skip)
      verifier.getVerificationThrowable()?.let {
        if (logJarProblems()) {
          client.log(it, "Error verifying bytecode in $jarFile")
        }
      }
      return verifier
    }

    private fun reportErrors(driver: LintDriver?): Boolean {
      return driver?.mode != LintDriver.DriverMode.ANALYSIS_ONLY
    }

    /**
     * Given a jar file, create a class loader for it and instantiate the named issue registry.
     *
     * TODO: Add a custom class loader architecture here such that custom rules can have dependent jars without needing to jar-jar them!
     */
    private fun loadIssueRegistry(
      client: LintClient,
      jarFile: File,
      className: String,
      currentProject: Project?,
      driver: LintDriver?,
      skipVerification: Boolean,
      attemptMigration: Boolean,
    ): IssueRegistry? {
      // Make a class loader for this jar
      return try {
        val loader = client.createUrlClassLoader(listOf(jarFile), JarFileIssueRegistry::class.java.classLoader)
        val registryClass = Class.forName(className, true, loader)
        val registry = registryClass.getDeclaredConstructor().newInstance() as IssueRegistry

        val issues =
          try {
            registry.issues
          } catch (e: Throwable) {
            if (reportErrors(driver)) {
              val stacktrace = StringBuilder()
              LintDriver.appendStackTraceSummary(e, stacktrace)
              val message =
                "Lint found one or more custom checks that could not " +
                  "be loaded. The most likely reason for this is that it is using an " +
                  "older, incompatible or unsupported API in lint. Make sure these " +
                  "lint checks are updated to the new APIs. The issue registry class " +
                  "is $className. The class loading issue is ${e.message}: $stacktrace"

              LintClient.report(
                client = client,
                issue = OBSOLETE_LINT_CHECK,
                message = message,
                file = jarFile,
                project = currentProject,
                driver = driver,
              )
            }
            return null
          }

        if (skipVerification) {
          return registry
        }

        try {
          if (registry.maxApi < CURRENT_API) {
            // IssueRegistry intended for older versions of lint
            return null
          }

          val apiField = registryClass.getDeclaredMethod("getApi")
          val api = apiField.invoke(registry) as Int
          if (api < CURRENT_API) {
            // Don't warn if the registry is older if binary verification doesn't
            // yield any problems. This is helpful because lint releases often (3+ times
            // a year) and for libraries bundled with AAR files this means that by the
            // time the library is stable lint will start warning about the lint check
            // needing to be updated -- and in 99.9% of cases the lint check is only
            // doing simple things which is unaffected by lint changes.
            val verifier = verify(client, jarFile)
            if (!verifier.isCompatible()) {
              if (verifier.needsApiMigration() && attemptMigration) {
                val newJar = LintJarApiMigration.getMigratedJar(client, jarFile, className)
                return loadIssueRegistry(
                  client,
                  newJar,
                  className,
                  currentProject,
                  driver,
                  skipVerification = false,
                  attemptMigration = false,
                )
              }
              if (reportErrors(driver)) {
                val message = generateVerifierMessage(api, className, issues, verifier)
                LintClient.report(
                  client = client,
                  issue = OBSOLETE_LINT_CHECK,
                  message = message,
                  file = jarFile,
                  project = currentProject,
                  driver = driver,
                )
              }
              recordRejectedIssues(issues)
              return null
            }
            // Not returning here: try to run the checks
          } else {
            try {
              val minApi = registry.minApi
              if (minApi > CURRENT_API) {
                if (reportErrors(driver)) {
                  val message =
                    "Lint found an issue registry (`$className`) which " +
                      "requires a newer API level. That means that the custom " +
                      "lint checks are intended for a newer lint version; please " +
                      "upgrade."
                  LintClient.report(
                    client = client,
                    issue = OBSOLETE_LINT_CHECK,
                    message = message,
                    file = jarFile,
                    project = currentProject,
                    driver = driver,
                  )
                }
                recordRejectedIssues(issues)
                return null
              } else {
                val verifier = verify(client, jarFile)
                if (!verifier.isCompatible()) {
                  if (verifier.needsApiMigration() && attemptMigration) {
                    val newJar = LintJarApiMigration.getMigratedJar(client, jarFile, className)
                    return loadIssueRegistry(
                      client,
                      newJar,
                      className,
                      currentProject,
                      driver,
                      skipVerification = false,
                      attemptMigration = false,
                    )
                  }
                  if (reportErrors(driver)) {
                    val message = generateVerifierMessage(api, className, issues, verifier)
                    LintClient.report(
                      client = client,
                      issue = OBSOLETE_LINT_CHECK,
                      message = message,
                      file = jarFile,
                      project = currentProject,
                      driver = driver,
                    )
                  }
                  recordRejectedIssues(issues)
                  return null
                }
              }
            } catch (e: Throwable) {
              if (logJarProblems()) {
                client.log(e, null)
              }
            }
          }
        } catch (e: Throwable) {
          // (Catching attempts to use reflection to call `getApi`)
          // Some older AndroidX libraries still in use don't have this defined, but we've
          // checked that they do work.
          if (className.startsWith("androidx.") || className.startsWith("android.")) {
            return registry
          }

          if (reportErrors(driver)) {
            var message =
              "Lint found an issue registry (`$className`)\n" +
                "which did not specify the Lint API version it was compiled with.\n" +
                "\n" +
                "**This means that the lint checks are likely not compatible.**\n" +
                "\n" +
                "If you are the author of this lint check, make your lint\n" +
                "`IssueRegistry` class contain\n" +
                "\u00a0\u00a0override val api: Int = com.android.tools.lint.detector.api.CURRENT_API\n" +
                "or from Java,\n" +
                "\u00a0\u00a0@Override public int getApi() { return com.android.tools.lint.detector.api.ApiKt.CURRENT_API; }"

            val issueIds = issues.map { it.id }.sorted()
            if (issueIds.any()) {
              message +=
                ("\n" +
                    "\n" +
                    "If you are just using lint checks from a third party library\n" +
                    "you have no control over, you can disable these lint checks (if\n" +
                    "they misbehave) like this:\n" +
                    "\n" +
                    "    android {\n" +
                    "        lintOptions {\n" +
                    "            disable ${
                                    issueIds.joinToString(
                                        separator = ",\n                    "
                                    ) { "\"$it\"" }
                                    }\n" +
                    "        }\n" +
                    "    }\n")
                  .replace(
                    // Force indentation
                    "    ",
                    "\u00a0\u00a0\u00a0\u00a0",
                  )
            }

            LintClient.report(
              client = client,
              issue = OBSOLETE_LINT_CHECK,
              message = message,
              file = jarFile,
              project = currentProject,
              driver = driver,
            )
          }
          // Not returning here: try to run the checks
        }

        registry
      } catch (e: Throwable) {
        // Lint was asked to load an issue registry class, and that class isn't there in the
        // jar file. See b/143231996 for examples. This is a google3 specific problem where
        // the issue registry *does* contain a registration entry for the registry,
        // but it's not always there in the jar files.
        if (e is ClassNotFoundException && e.message == className) {
          if (logJarProblems()) {
            val stacktrace = StringBuilder()
            LintDriver.appendStackTraceSummary(e, stacktrace)
            client.log(e, "Could not load custom lint check jar file %1\$s: %2\$s", jarFile, stacktrace)
          }
        } else if (reportErrors(driver)) {
          val stacktrace = StringBuilder()
          LintDriver.appendStackTraceSummary(e, stacktrace)
          val message =
            "Could not load custom lint check jar file. " +
              "The issue registry class is $className. The initialization problem is ${e.message?.let { ("$it: ") } ?: ""}$stacktrace"

          LintClient.report(
            client = client,
            issue = LINT_ERROR,
            message = message,
            file = jarFile,
            project = currentProject,
            driver = driver,
          )
        }
        null
      }
    }

    /** Is the given [issueId] the id of an issue which was rejected as incompatible */
    fun isRejectedIssueId(issueId: String): Boolean {
      return rejectedIssueIds.contains(issueId)
    }

    private fun recordRejectedIssues(issues: List<Issue>) {
      rejectedIssueIds.addAll(issues.map { it.id })
    }

    private fun getVendor(client: LintClient, registry: IssueRegistry, jarFile: File): Vendor {
      return registry.vendor
        ?: run {
          val registryClass = registry.javaClass.name

          // Try to guess a vendor from the path and catch some common cases
          // until the various libraries are updated
          val matcher = ARTIFACT_PATTERN.matcher(jarFile.path)
          val identifier =
            if (matcher.matches()) {
              matcher.group(1)
            } else {
              registryClass
                .removeSuffix("IssueRegistry")
                .removeSuffix("Registry")
                .removeSuffix(".My") // MyIssueRegistry common from sample
                .removeSuffix(".")
                .lowercase(Locale.US)
            }

          val inferredVendor: Vendor? =
            if (registryClass.startsWith("androidx.") || registryClass.startsWith("android.")) {
              Vendor(
                vendorName = "Android Open Source Project ($identifier)",
                feedbackUrl = "https://issuetracker.google.com/issues/new?component=192731",
                identifier = identifier,
              )
            } else if (registryClass.startsWith("com.google.")) {
              Vendor(vendorName = "Google ($identifier)", identifier = identifier)
            } else {
              null
            }

          if (inferredVendor != null) {
            inferredVendor
          } else {
            if (logJarProblems()) {
              client.log(Severity.WARNING, null, "$registryClass in $jarFile does not specify a vendor; see IssueRegistry#vendor")
            }

            Vendor(identifier = identifier)
          }
        }
    }

    /**
     * Returns a map from issue registry qualified name to the corresponding jar files that contains it. The sorting order for Jar files
     * prioritizes those with higher revision numbers first, followed by Jar files that have no revision number, and lastly, legacy Jar
     * files.
     */
    fun findRegistries(client: LintClient, jarFiles: Collection<File>): Map<String, List<File>> {
      val registryClassToJarFile = HashMap<String, TreeMap<Int, File>>()
      for (jarFile in jarFiles) {
        try {
          JarFile(jarFile).use { file ->
            val manifest = file.manifest
            // Default revision number for Jars that do not have one.
            var revision = -1
            if (manifest != null) {
              val attrs = manifest.mainAttributes
              revision = attrs[Attributes.Name(MF_LINT_REVISION)]?.toString()?.toIntOrNull() ?: -1

              var attribute: Any? = attrs[Attributes.Name(MF_LINT_REGISTRY)]
              if (attribute == null) {
                attribute = attrs[Attributes.Name(MF_LINT_REGISTRY_OLD)]
                if (attribute != null) {
                  // Default revision number for Legacy Jars.
                  revision = -2
                }
              }
              if (attribute is String) {
                val className = attribute
                registryClassToJarFile.getOrPut(className) { TreeMap() }[revision] = jarFile
                return@use
              }
            }

            // Load service keys. We're reading it manually instead of using
            // ServiceLoader because we don't want to put these jars into
            // the class loaders yet (since there can be many duplicates
            // when a library is available through multiple dependencies)
            val services = file.getJarEntry(SERVICE_KEY)
            if (services != null) {
              file.getInputStream(services).use {
                val reader = InputStreamReader(it, Charsets.UTF_8)
                reader.useLines { lines ->
                  for (line in lines) {
                    val comment = line.indexOf("#")
                    val className =
                      if (comment >= 0) {
                        line.substring(0, comment).trim()
                      } else {
                        line.trim()
                      }
                    if (className.isNotEmpty()) {
                      registryClassToJarFile.getOrPut(className) { TreeMap() }[revision] = jarFile
                    }
                  }
                }
              }
            } else if (logJarProblems() && jarFile.name == "lint.jar") {
              client.log(
                Severity.ERROR,
                null,
                "Custom lint rule jar %1\$s does not contain a valid " +
                  "registry manifest key (%2\$s).\n" +
                  "Either the custom jar is invalid, or it uses an outdated " +
                  "API not supported this lint client",
                jarFile.path,
                MF_LINT_REGISTRY,
              )
            }
          }
        } catch (e: IOException) {
          if (logJarProblems()) {
            client.log(e, "Could not load custom lint check jar file %1\$s", jarFile)
          }
        }
      }

      return registryClassToJarFile.mapValues { entry ->
        // Files are sorted in the TreeSet of entry.value by their revision numbers.
        // Returns a list of files where higher revision numbers come first.
        entry.value.values.reversed()
      }
    }

    private fun generateVerifierMessage(api: Int, className: String, issues: List<Issue>, verifier: LintJarVerifier): String {
      val sb = StringBuilder()
      when {
        api > CURRENT_API -> sb.append("Requires newer lint; ")
        api < CURRENT_API -> sb.append("Library lint checks out of date;\n") // inconsistent newline, but preserve existing baselines
        else -> sb.append("Library lint checks reference invalid APIs; ")
      }
      sb.append("these checks **will be skipped**!\n\n")

      sb.append("Lint found an issue registry (`$className`)\n")
      when {
        api > CURRENT_API ->
          sb.append(
            """
            which was compiled against a newer version of lint
            than this one. This is usually fine, but not in this
            case; some basic verification shows that the lint
            check jar references (for example) the following API
            which is not valid in the version of lint which is running:
            """
              .trimIndent()
          )
        api < CURRENT_API ->
          sb.append(
            """
            which was compiled against an older version of lint
            than this one. This is usually fine, but not in this
            case; some basic verification shows that the lint
            check jar references (for example) the following API
            which is no longer valid in this version of lint:
            """
              .trimIndent()
          )
        else ->
          sb.append(
            """
            which contains some references to invalid API:
            """
              .trimIndent()
          )
      }

      val reference = verifier.describeFirstIncompatibleReference()
      val referenceClassFile = verifier.getReferenceClassFile()
      sb.append(
        """

                $reference
                (Referenced from $referenceClassFile)

                Therefore, this lint check library is **not** included
                in analysis. This affects the following lint checks:

                """
          .trimIndent()
      )

      sb.append(issues.map(Issue::id).joinToString(if (issues.size > 5) "\n" else ",") { "`$it`" })
      sb.append("\n\n")

      when {
        reference == "org.jetbrains.uast.kotlin.KotlinUClass#getKtClass(): org.jetbrains.kotlin.psi.KtClassOrObject" &&
          className == "androidx.fragment.lint.FragmentIssueRegistry" &&
          LintClient.isGradle -> {
          sb.append(
            """
            **This is a known bug which is already fixed in
            `androidx.fragment:fragment:1.5.1` and later**; update
            to that version. If you are not directly depending
            on this library but picking it up via a transitive
            dependency, explicitly add
            `implementation 'androidx.fragment:fragment:1.5.1'`
            (or later) to your build.gradle dependency block.
            """
              .trimIndent()
          )
        }
        api > CURRENT_API -> {
          sb.append(
            """
            To use this lint check, upgrade to a more recent version
            of lint.
            """
              .trimIndent()
          )
        }
        api < CURRENT_API -> {
          sb.append(
            """
            Recompile the checks against the latest version, or if
            this is a check bundled with a third-party library, see
            if there is a more recent version available.
            """
              .trimIndent()
          )
        }
        else -> {
          // api == CURRENT_API
          sb.append(
            """
            To use this lint check, upgrade to a more recent version
            of the library.
            """
              .trimIndent()
          )
        }
      }

      if (api != CURRENT_API) {
        sb.append(
          """


                    Version of Lint API this lint check is using is $api.
                    The Lint API version currently running is $CURRENT_API (${describeApi(CURRENT_API)}).
                    """
            .trimIndent()
        )
      }

      return sb.toString()
    }

    /**
     * Work around http://bugs.java.com/bugdatabase/view_bug.do?bug_id=5041014 : URLClassLoader, on Windows, locks the .jar file forever. As
     * of Java 7, there's a workaround: you can call close() when you're "done" with the file. We'll do that here. However, the whole point
     * of the [JarFileIssueRegistry] is that when lint is run over and over again as the user is editing in the IDE and we're background
     * checking the code, we don't want to keep loading the custom view classes over and over again: we want to cache them. Therefore, just
     * closing the URLClassLoader right away isn't great either. However, it turns out it's safe to close the URLClassLoader once you've
     * loaded the classes you need, since the URLClassLoader will continue to serve those classes even after its close() methods has been
     * called.
     *
     * Therefore, if we can call close() on this URLClassLoader, we'll proactively load all class files we find in the .jar file, then close
     * it.
     *
     * @param client the client to report errors to
     * @param file the .jar file
     * @param loader the URLClassLoader we should close
     */
    private fun loadAndCloseURLClassLoader(client: LintClient, file: File, loader: URLClassLoader) {
      if (SdkConstants.CURRENT_PLATFORM != SdkConstants.PLATFORM_WINDOWS) {
        // We don't need to close the class loader on other platforms than Windows
        return
      }

      // Before closing the jar file, proactively load all classes:
      try {
        JarFile(file).use { jar ->
          val enumeration = jar.entries()
          while (enumeration.hasMoreElements()) {
            val entry = enumeration.nextElement()
            val path = entry.name
            // Load non-inner-classes
            if (path.endsWith(DOT_CLASS) && path.indexOf('$') == -1) {
              // Strip .class suffix and change .jar file path (/)
              // to class name (.'s).
              val name = path.substring(0, path.length - DOT_CLASS.length).replace('/', '.')
              try {
                val cls = Class.forName(name, true, loader)
                // Actually, initialize them too to make sure basic classes
                // needed by the detector are available
                if (!(cls.isAnnotation || cls.isEnum || cls.isInterface)) {
                  try {
                    val defaultConstructor = cls.getConstructor()
                    defaultConstructor.isAccessible = true
                    defaultConstructor.newInstance()
                  } catch (ignore: NoSuchMethodException) {}
                }
              } catch (e: Throwable) {
                if (logJarProblems()) {
                  client.log(Severity.ERROR, e, "Failed to prefetch $name from $file")
                }
              }
            }
          }
        }
      } catch (ignore: Throwable) {} finally {
        // Finally close the URL class loader
        try {
          loader.close()
        } catch (ignore: Throwable) {
          // Couldn't close. This is unlikely.
        }
      }
    }

    /**
     * If set to false, don't log various problems related to loading custom jar files. This includes unexpected conditions like a lint jar
     * file not containing an issue registry, or I/O errors reading the file. It does *not* include exceptions thrown by the IssueRegistry
     * being initialized; these are reported as actual [IssueRegistry.LINT_ERROR] problems.
     */
    private fun logJarProblems(): Boolean = System.getProperty("android.lint.log-jar-problems") != VALUE_FALSE
  }
}
