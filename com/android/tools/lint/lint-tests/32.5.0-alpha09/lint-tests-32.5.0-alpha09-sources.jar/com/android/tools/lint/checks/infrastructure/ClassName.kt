/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.tools.lint.checks.infrastructure

import com.android.SdkConstants.DOT_JAVA

@Deprecated("Use upstream version", replaceWith = ReplaceWith("com.android.tools.lint.ClassName(source, extension)"))
class ClassName(source: String, extension: String = DOT_JAVA) : com.android.tools.lint.ClassName(source, extension)

@Deprecated("Use upstream version", replaceWith = ReplaceWith("com.android.tools.lint.stripComments(source, extension, stripLineComments)"))
fun stripComments(source: String, extension: String, stripLineComments: Boolean = true): String =
  com.android.tools.lint.stripComments(source, extension, stripLineComments)
