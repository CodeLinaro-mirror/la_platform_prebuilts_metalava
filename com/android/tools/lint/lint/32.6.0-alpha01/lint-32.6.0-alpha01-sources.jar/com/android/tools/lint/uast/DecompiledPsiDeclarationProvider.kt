/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.lint.uast

import com.android.tools.lint.uast.PsiDeclarationAndKtSymbolEqualityChecker.representsTheSameDeclaration
import com.intellij.openapi.project.Project
import com.intellij.psi.PsiElement
import com.intellij.psi.PsiField
import com.intellij.psi.PsiMethod
import com.intellij.psi.search.GlobalSearchScope
import org.jetbrains.kotlin.analysis.api.KaExperimentalApi
import org.jetbrains.kotlin.analysis.api.KaSession
import org.jetbrains.kotlin.analysis.api.symbols.*
import org.jetbrains.kotlin.psi.KtElement
import org.jetbrains.kotlin.psi.KtExpression
import org.jetbrains.uast.kotlin.internal.FirKotlinUastLibraryPsiProviderService
import org.jetbrains.uast.kotlin.readWriteAccess

internal object DecompiledPsiDeclarationProvider : FirKotlinUastLibraryPsiProviderService {
  override fun KaSession.provide(symbol: KaSymbol, context: KtElement?): PsiElement? {
    val project = symbol.containingModule.project
    return when (symbol) {
      is KaConstructorSymbol -> providePsiForConstructor(symbol, project)
      is KaFunctionSymbol -> providePsiForFunction(symbol, project)
      is KaEnumEntrySymbol -> providePsiForEnumEntry(symbol, project)
      is KaVariableSymbol -> providePsiForProperty(symbol, context, project)
      is KaClassLikeSymbol -> providePsiForClass(symbol, project)
      else -> null
    }
  }

  private fun KaSession.providePsiForConstructor(constructorSymbol: KaConstructorSymbol, project: Project): PsiElement? {
    val classId = constructorSymbol.containingClassId ?: return null
    val candidates =
      project.createPsiDeclarationProvider(constructorSymbol.scope(project))?.getClassesByClassId(classId)?.firstOrNull()?.constructors
        ?: return null
    return if (candidates.size == 1) candidates.single()
    else {
      candidates.find { psiMethod -> representsTheSameDeclaration(psiMethod, constructorSymbol) }
    }
  }

  @OptIn(KaExperimentalApi::class)
  private fun KaSession.providePsiForFunction(functionLikeSymbol: KaFunctionSymbol, project: Project): PsiElement? {
    val candidates =
      project
        .createPsiDeclarationProvider(functionLikeSymbol.scope(project))
        ?.getFunctions(functionLikeSymbol, functionLikeSymbol.containingJvmClassName)
    return if (candidates?.size == 1) candidates.single()
    else candidates?.find { psiMethod -> representsTheSameDeclaration(psiMethod, functionLikeSymbol) }
  }

  @OptIn(KaExperimentalApi::class)
  private fun KaSession.providePsiForProperty(variableLikeSymbol: KaVariableSymbol, context: KtElement?, project: Project): PsiElement? {
    val candidates =
      project
        .createPsiDeclarationProvider(variableLikeSymbol.scope(project))
        ?.getProperties(variableLikeSymbol, variableLikeSymbol.containingJvmClassName)
    if (candidates?.size == 1) return candidates.single()
    else {
      if (variableLikeSymbol is KaPropertySymbol) {
        val getterSymbol = variableLikeSymbol.getter
        val setterSymbol = variableLikeSymbol.setter
        val readWriteAccess = (context as? KtExpression)?.readWriteAccess()
        val isGetter = getterSymbol != null && readWriteAccess?.isRead == true
        val isSetter = setterSymbol != null && readWriteAccess?.isWrite == true
        candidates
          ?.filterIsInstance<PsiMethod>()
          ?.firstOrNull { psiMethod ->
            (isGetter && representsTheSameDeclaration(psiMethod, getterSymbol)) ||
              (isSetter && representsTheSameDeclaration(psiMethod, setterSymbol))
          }
          ?.let {
            return it
          }
      }
      // Weigh [PsiField]
      candidates
        ?.firstOrNull { psiMember -> psiMember is PsiField }
        ?.let {
          return it
        }
      return candidates?.firstOrNull()
    }
  }

  private fun providePsiForClass(classLikeSymbol: KaClassLikeSymbol, project: Project): PsiElement? {
    return classLikeSymbol.classId?.let {
      project.createPsiDeclarationProvider(classLikeSymbol.scope(project))?.getClassesByClassId(it)?.firstOrNull()
    }
  }

  private fun providePsiForEnumEntry(enumEntrySymbol: KaEnumEntrySymbol, project: Project): PsiElement? {
    val classId = enumEntrySymbol.callableId?.classId ?: return null
    val psiClass =
      project.createPsiDeclarationProvider(enumEntrySymbol.scope(project))?.getClassesByClassId(classId)?.firstOrNull() ?: return null
    return psiClass.fields.find { it.name == enumEntrySymbol.name.asString() }
  }

  private fun KaSymbol.scope(project: Project): GlobalSearchScope {
    // TODO: finding containing module and use a narrower scope?
    return GlobalSearchScope.allScope(project)
  }
}
