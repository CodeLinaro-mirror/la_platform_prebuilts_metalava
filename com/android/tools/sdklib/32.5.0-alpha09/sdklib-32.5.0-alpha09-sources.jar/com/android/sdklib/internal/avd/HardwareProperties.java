/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.sdklib.internal.avd;

import static com.android.sdklib.devices.Device.isAiGlasses;
import static com.android.sdklib.devices.Device.isAiGlassesDisplayless;
import static com.android.sdklib.devices.Device.isAutomotive;
import static com.android.sdklib.devices.Device.isAutomotiveDistantDisplay;
import static com.android.sdklib.devices.Device.isRollable;
import static com.android.sdklib.devices.Device.isXrGlasses;

import com.android.SdkConstants;
import com.android.io.IAbstractFile;
import com.android.io.StreamException;
import com.android.resources.KeyboardState;
import com.android.resources.Navigation;
import com.android.sdklib.devices.ButtonType;
import com.android.sdklib.devices.Camera;
import com.android.sdklib.devices.Device;
import com.android.sdklib.devices.Environment;
import com.android.sdklib.devices.Hardware;
import com.android.sdklib.devices.Hinge;
import com.android.sdklib.devices.PowerType;
import com.android.sdklib.devices.Screen;
import com.android.sdklib.devices.ScreenType;
import com.android.sdklib.devices.Sensor;
import com.android.sdklib.devices.State;
import com.android.sdklib.devices.Storage;
import com.android.sdklib.devices.Touchpad;
import com.android.utils.ILogger;

import com.google.common.hash.HashFunction;
import com.google.common.hash.Hasher;
import com.google.common.hash.Hashing;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HardwareProperties {
    /** AVD/config.ini key for the type of screen */
    public static final String HW_SCREEN = "hw.screen";
    /** AVD/config.ini value for when the type of screen is notouch*/
    public static final String HW_SCREEN_NOTOUCH = "no-touch";
    /** AVD/config.ini key for whether hardware buttons are present. */
    public static final String HW_MAINKEYS = "hw.mainKeys";

    /** AVD/config.ini key indicating whether trackball is present. */
    public static final String HW_TRACKBALL = "hw.trackBall";

    /** AVD/config.ini key indicating whether qwerty keyboard is present. */
    public static final String HW_KEYBOARD = "hw.keyboard";

    /** AVD/config.ini key indicating whether dpad is present. */
    public static final String HW_DPAD = "hw.dPad";

    /** AVD/config.ini key indicating whether gps is present. */
    public static final String HW_GPS = "hw.gps";

    /** AVD/config.ini key indicating whether the device is running on battery. */
    public static final String HW_BATTERY = "hw.battery";

    /** AVD/config.ini key indicating whether an accelerometer is present. */
    public static final String HW_ACCELEROMETER = "hw.accelerometer";

    /** AVD/config.ini key indicating whether a light sensor present. */
    public static final String HW_LIGHT_SENSOR = "hw.sensors.light";

    /** AVD/config.ini key indicating whether a magnetic field sensor (electronic compass) is present. */
    public static final String HW_MAGNETIC_FIELD_SENSOR = "hw.sensors.magnetic_field";

    /** AVD/config.ini key indicating whether a gyroscope is present. */
    public static final String HW_GYROSCOPE = "hw.gyroscope";

    /** AVD/config.ini key indicating whether an orientation sensor is present. */
    public static final String HW_ORIENTATION_SENSOR = "hw.sensors.orientation";

    /** AVD/config.ini key indicating whether an atmospheric pressure sensor (barometer) is present. */
    public static final String HW_PRESSURE_SENSOR = "hw.sensors.pressure";

    /** AVD/config.ini key indicating whether a proximity sensor is present. */
    public static final String HW_PROXIMITY_SENSOR = "hw.sensors.proximity";

    /** AVD/config.ini key indicating whether an ambient temperature sensor is present. */
    public static final String HW_TEMPERATURE_SENSOR = "hw.sensors.temperature";

    /** AVD/config.ini key indicating whether h/w mic is present. */
    public static final String HW_AUDIO_INPUT = "hw.audioInput";

    /** AVD/config.ini key indicating whether sdcard is present. */
    public static final String HW_SDCARD = "hw.sdCard";

    /** AVD/config.ini key for LCD density. */
    public static final String HW_LCD_DENSITY = "hw.lcd.density";

    /** AVD/config.ini key for LCD width. */
    public static final String HW_LCD_WIDTH = "hw.lcd.width";

    /** AVD/config.ini key for LCD height. */
    public static final String HW_LCD_HEIGHT = "hw.lcd.height";

    /** AVD/config.ini key for environment width. */
    public static final String ENVIRONMENT_WIDTH = "environment.width";

    /** AVD/config.ini key for environment height. */
    public static final String ENVIRONMENT_HEIGHT = "environment.height";

    /** AVD/config.ini key for dimming levels. */
    public static final String HW_DIMMING_LEVELS = "hw.dimmingLevels";

    /** AVD/config.ini key for LED indicators. */
    public static final String HW_LED_INDICATORS = "hw.ledIndicators";

    /** AVD/config.ini key for whether touchpad is present. */
    public static final String HW_TOUCHPAD0 = "hw.touchpad0";

    /** AVD/config.ini key for touchpad width. */
    public static final String HW_TOUCHPAD0_WIDTH = "hw.touchpad0.width";

    /** AVD/config.ini key for touchpad height. */
    public static final String HW_TOUCHPAD0_HEIGHT = "hw.touchpad0.height";

    /** AVD/config.ini key for the device having Open/Closed state. */
    public static final String HW_KEYBOARD_LID = "hw.keyboard.lid";

    /** AVD/config.ini key for folded LCD offset and size. */
    public static final String HW_LCD_FOLDED_X_OFFSET = "hw.displayRegion.0.1.xOffset";
    public static final String HW_LCD_FOLDED_Y_OFFSET = "hw.displayRegion.0.1.yOffset";
    public static final String HW_LCD_FOLDED_WIDTH = "hw.displayRegion.0.1.width";
    public static final String HW_LCD_FOLDED_HEIGHT = "hw.displayRegion.0.1.height";
    public static final String HW_LCD_FOLDED_X_OFFSET_2 = "hw.displayRegion.0.2.xOffset";
    public static final String HW_LCD_FOLDED_Y_OFFSET_2 = "hw.displayRegion.0.2.yOffset";
    public static final String HW_LCD_FOLDED_WIDTH_2 = "hw.displayRegion.0.2.width";
    public static final String HW_LCD_FOLDED_HEIGHT_2 = "hw.displayRegion.0.2.height";
    public static final String HW_LCD_FOLDED_X_OFFSET_3 = "hw.displayRegion.0.3.xOffset";
    public static final String HW_LCD_FOLDED_Y_OFFSET_3 = "hw.displayRegion.0.3.yOffset";
    public static final String HW_LCD_FOLDED_WIDTH_3 = "hw.displayRegion.0.3.width";
    public static final String HW_LCD_FOLDED_HEIGHT_3 = "hw.displayRegion.0.3.height";

    /** AVD/config.ini key for initial device orientation. */
    public static final String HW_INITIAL_ORIENTATION = "hw.initialOrientation";

    private static final Pattern PATTERN_PROP = Pattern.compile(
    "^([a-zA-Z0-9._-]+)\\s*=\\s*(.*)\\s*$");

    /** Property name in the generated avd config file; String; e.g. "hw.screen" */
    private static final String HW_PROP_NAME = "name";              //$NON-NLS-1$
    /** Property type, one of {@link HardwarePropertyType} */
    private static final String HW_PROP_TYPE = "type";              //$NON-NLS-1$
    /** Default value of the property. String matching the property type. */
    private static final String HW_PROP_DEFAULT = "default";        //$NON-NLS-1$
    /** User-visible name of the property. String. */
    private static final String HW_PROP_ABSTRACT = "abstract";      //$NON-NLS-1$
    /** User-visible description of the property. String. */
    private static final String HW_PROP_DESC = "description";       //$NON-NLS-1$
    /** Comma-separate values for a property of type "enum" */
    private static final String HW_PROP_ENUM = "enum";              //$NON-NLS-1$

    public static final String BOOLEAN_YES = "yes";
    public static final String BOOLEAN_NO = "no";
    public static final Pattern DISKSIZE_PATTERN = Pattern.compile("\\d+[MK]B"); //$NON-NLS-1$

    /**
     * Returns hardware properties (defined in hardware.ini) as a {@link Map}.
     *
     * @param s The {@link State} from which to derive the hardware properties.
     * @return A {@link Map} of hardware properties.
     */
    @NotNull
    public static Map<String, String> getHardwareProperties(@NotNull State s) {
        Hardware hw = s.getHardware();
        Map<String, String> props = new HashMap<>();
        Screen screen = hw.getScreen();
        if (screen != null) {
            if (screen.getScreenType().equals(ScreenType.NOTOUCH)) {
                props.put(HW_SCREEN, HW_SCREEN_NOTOUCH);
            }
            props.put(
                    HW_LCD_DENSITY,
                    Integer.toString(screen.getPixelDensity().getDpiValue()));
            props.put(HW_LCD_WIDTH, Integer.toString(screen.getXDimension()));
            props.put(HW_LCD_HEIGHT, Integer.toString(screen.getYDimension()));

            if (screen.isFoldable()) {
                props.put(HW_KEYBOARD_LID, getBooleanVal(true));
                props.put(
                        HW_LCD_FOLDED_X_OFFSET,
                        Integer.toString(screen.getFoldedXOffset()));
                props.put(
                        HW_LCD_FOLDED_Y_OFFSET,
                        Integer.toString(screen.getFoldedYOffset()));
                props.put(
                        HW_LCD_FOLDED_HEIGHT,
                        Integer.toString(screen.getFoldedHeight()));
                props.put(
                        HW_LCD_FOLDED_WIDTH,
                        Integer.toString(screen.getFoldedWidth()));
                if (screen.getFoldedWidth2() != 0 && screen.getFoldedHeight2() != 0) {
                    props.put(
                            HW_LCD_FOLDED_X_OFFSET_2,
                            Integer.toString(screen.getFoldedXOffset2()));
                    props.put(
                            HW_LCD_FOLDED_Y_OFFSET_2,
                            Integer.toString(screen.getFoldedYOffset2()));
                    props.put(
                            HW_LCD_FOLDED_WIDTH_2,
                            Integer.toString(screen.getFoldedWidth2()));
                    props.put(
                            HW_LCD_FOLDED_HEIGHT_2,
                            Integer.toString(screen.getFoldedHeight2()));
                }
                if (screen.getFoldedWidth3() != 0 && screen.getFoldedHeight3() != 0) {
                    props.put(
                            HW_LCD_FOLDED_X_OFFSET_3,
                            Integer.toString(screen.getFoldedXOffset3()));
                    props.put(
                            HW_LCD_FOLDED_Y_OFFSET_3,
                            Integer.toString(screen.getFoldedYOffset3()));
                    props.put(
                            HW_LCD_FOLDED_WIDTH_3,
                            Integer.toString(screen.getFoldedWidth3()));
                    props.put(
                            HW_LCD_FOLDED_HEIGHT_3,
                            Integer.toString(screen.getFoldedHeight3()));
                }
            }
        }

        props.put(
                HW_MAINKEYS,
                getBooleanVal(hw.getButtonType().equals(ButtonType.HARD)));
        props.put(
                HW_TRACKBALL,
                getBooleanVal(hw.getNav().equals(Navigation.TRACKBALL)));
        props.put(HW_DPAD, getBooleanVal(hw.getNav().equals(Navigation.DPAD)));

        Set<Sensor> sensors = hw.getSensors();
        props.put(HW_GPS, getBooleanVal(sensors.contains(Sensor.GPS)));
        props.put(
                HW_BATTERY,
                getBooleanVal(hw.getChargeType().equals(PowerType.BATTERY)));
        props.put(
                HW_ACCELEROMETER,
                getBooleanVal(sensors.contains(Sensor.ACCELEROMETER)));
        props.put(
                HW_ORIENTATION_SENSOR,
                getBooleanVal(sensors.contains(Sensor.GYROSCOPE)));
        props.put(
                HW_GYROSCOPE, getBooleanVal(sensors.contains(Sensor.GYROSCOPE)));
        props.put(
                HW_MAGNETIC_FIELD_SENSOR,
                getBooleanVal(sensors.contains(Sensor.COMPASS)));
        props.put(
                HW_PRESSURE_SENSOR,
                getBooleanVal(sensors.contains(Sensor.BAROMETER)));
        props.put(
                HW_LIGHT_SENSOR,
                getBooleanVal(sensors.contains(Sensor.LIGHT_SENSOR)));

        props.put(HW_AUDIO_INPUT, getBooleanVal(hw.hasMic()));
        props.put(HW_SDCARD, getBooleanVal(hw.hasSdCard()));

        Environment environment = hw.getEnvironment();
        if (environment != null) {
            props.put(ENVIRONMENT_HEIGHT, Integer.toString(environment.getHeight()));
            props.put(ENVIRONMENT_WIDTH, Integer.toString(environment.getWidth()));
        }

        Touchpad touchpad = hw.getTouchpad();
        if (touchpad != null) {
            props.put(HW_TOUCHPAD0, getBooleanVal(true));
            props.put(HW_TOUCHPAD0_WIDTH, Integer.toString(touchpad.getWidth()));
            props.put(
                    HW_TOUCHPAD0_HEIGHT, Integer.toString(touchpad.getHeight()));
        }

        props.put(
                HW_PROXIMITY_SENSOR,
                getBooleanVal(sensors.contains(Sensor.PROXIMITY_SENSOR)));

        Hinge hinge = hw.getHinge();

        if (hinge != null) {
            props.put(ConfigKey.HINGE, hinge.getCount() > 0 ? "yes" : "no");
            props.put(ConfigKey.HINGE_COUNT, Integer.toString(hinge.getCount()));
            props.put(ConfigKey.HINGE_TYPE, Integer.toString(hinge.getType()));
            props.put(ConfigKey.HINGE_SUB_TYPE, Integer.toString(hinge.getSubtype()));
            props.put(ConfigKey.HINGE_RANGES, hinge.getRanges());
            props.put(ConfigKey.HINGE_DEFAULTS, Integer.toString(hinge.getDefaults()));
            props.put(ConfigKey.HINGE_AREAS, hinge.getAreas());
            hinge.getFoldAtPosture()
                    .ifPresent(
                            fold -> props.put(ConfigKey.FOLD_AT_POSTURE, Integer.toString(fold)));
            props.put(ConfigKey.POSTURE_LISTS, hinge.getPostureList());
            props.put(
                    ConfigKey.HINGE_ANGLES_POSTURE_DEFINITIONS,
                    hinge.getHingeAnglePostureDefinitions());
        }

        for (Camera camera : hw.getCameras()) {
            if (!camera.isSensorOrientationDefault()) {
                props.put(ConfigKey.cameraSensorOrientation(camera.getLocation()),
                        Integer.toString(camera.getSensorOrientation()));
            }
        }
        return props;
    }

    /**
     * Returns the hardware properties defined in {@link AvdManager#HARDWARE_INI} as a {@link Map}.
     *
     * <p>This is intended to be dumped in the config.ini and already contains the device name,
     * manufacturer and device hash.
     *
     * @param d The {@link Device} from which to derive the hardware properties.
     * @return A {@link Map} of hardware properties.
     */
    @NotNull
    public static Map<String, String> getHardwareProperties(@NotNull Device d) {
        Map<String, String> props = getHardwareProperties(d.getDefaultState());
        for (State s : d.getAllStates()) {
            final Storage ramSize = s.getHardware().getRam();
            if (ramSize.getSize() > 0) {
                props.put(
                        ConfigKey.RAM_SIZE, Long.toString(ramSize.getSizeAsUnit(Storage.Unit.MiB)));
            }
            if (s.getKeyState().equals(KeyboardState.HIDDEN)) {
                props.put("hw.keyboard.lid", getBooleanVal(true));
            }
        }

        // Special-case hacks to support specific device types.

        if (d.getId().equals("13.5in Freeform")) {
            props.put(ConfigKey.DISPLAY_SETTINGS_FILE, "freeform");
        }
        if (isRollable(d.getId())) {
            props.put(ConfigKey.ROLL, "yes");
            props.put(ConfigKey.ROLL_COUNT, "1");
            props.put(ConfigKey.HINGE_TYPE, "3");
            props.put(ConfigKey.ROLL_RANGES, "58.55-100");
            props.put(ConfigKey.ROLL_DEFAULTS, "67.5");
            props.put(ConfigKey.ROLL_RADIUS, "3");
            props.put(ConfigKey.ROLL_DIRECTION, "1");
            props.put(ConfigKey.ROLL_RESIZE_1_AT_POSTURE, "1");
            props.put(ConfigKey.ROLL_RESIZE_2_AT_POSTURE, "2");
            props.put(ConfigKey.POSTURE_LISTS, "1, 2, 3");
            props.put(
                    ConfigKey.ROLL_PERCENTAGES_POSTURE_DEFINITIONS,
                    "58.55-76.45, 76.45-94.35, 94.35-100");
        }
        if (d.getId().equals("resizable")) {
            props.put(
                    ConfigKey.RESIZABLE_CONFIG,
                    "phone-0-1080-2400-420, foldable-1-2208-1840-420, tablet-2-1920-1200-240,"
                    + " desktop-3-1920-1080-160");
        }
        // TODO: Remove hard coded config when the runtime configuration is available (b/337978287,
        // b/337980217)
        if (isAutomotive(d)) {
            props.put(ConfigKey.CLUSTER_WIDTH, "400");
            props.put(ConfigKey.CLUSTER_HEIGHT, "600");
            props.put(ConfigKey.CLUSTER_DENSITY, "120");
            props.put(ConfigKey.CLUSTER_FLAG, "0");
        }
        if (isAutomotiveDistantDisplay(d)) {
            props.put(ConfigKey.DISTANT_DISPLAY_WIDTH, "3000");
            props.put(ConfigKey.DISTANT_DISPLAY_HEIGHT, "600");
            props.put(ConfigKey.DISTANT_DISPLAY_DENSITY, "120");
            props.put(ConfigKey.DISTANT_DISPLAY_FLAG, "0");
        }

        if (isAiGlasses(d)) {
            props.put(ConfigKey.LCD_TRANSPARENT, "yes");
            props.put(HW_LED_INDICATORS, "yes");
            if (isAiGlassesDisplayless(d)) {
                props.put(ConfigKey.DISPLAYLESS, "yes");
            }
        } else if (isXrGlasses(d)) {
            props.put(HW_DIMMING_LEVELS, "0.19921875,0.38671875,0.57421875,0.76171875,0.94921875");
        }

        HashFunction md5 = Hashing.md5();
        Hasher hasher = md5.newHasher();

        ArrayList<String> keys = new ArrayList<>(props.keySet());
        Collections.sort(keys);
        for (String key : keys) {
            if (key != null) {
                hasher.putString(key, StandardCharsets.UTF_8);
                String value = props.get(key);
                hasher.putString(value == null ? "null" : value, StandardCharsets.UTF_8);
            }
        }
        // store the hash method for potential future compatibility
        String hash = "MD5:" + hasher.hash().toString();
        props.put(ConfigKey.DEVICE_HASH_V2, hash);
        props.remove(ConfigKey.DEVICE_HASH_V1);

        props.put(ConfigKey.DEVICE_NAME, d.getId());
        props.put(ConfigKey.DEVICE_MANUFACTURER, d.getManufacturer());

        return props;
    }

    /**
     * Checks whether the hardware props have changed. If the hash is the same, returns null for
     * success. If the hash is not the same or there's not enough information to indicate it's the
     * same (e.g. if in the future we change the digest method), simply return the new hash,
     * indicating it would be best to update it.
     *
     * @param d The device.
     * @param hashV2 The previous saved AvdManager.DEVICE_HASH_V2 property.
     * @return Null if the same, otherwise returns the new and different hash.
     */
    @Nullable
    public static String hasHardwarePropHashChanged(@NotNull Device d, @NotNull String hashV2) {
        Map<String, String> props = getHardwareProperties(d);
        String newHash = props.get(ConfigKey.DEVICE_HASH_V2);

        // Implementation detail: don't just return the hash and let the caller decide whether
        // the hash is the same. That's because the hash contains the digest method so if in
        // the future we decide to change it, we could potentially recompute the hash here
        // using an older digest method here and still determine its validity, whereas the
        // caller cannot determine that.

        if (newHash != null && newHash.equals(hashV2)) {
            return null;
        }
        return newHash;
    }

    /**
     * Takes a boolean and returns the appropriate value for {@link HardwareProperties}
     *
     * @param bool The boolean value to turn into the appropriate {@link HardwareProperties} value.
     * @return {@code HardwareProperties#BOOLEAN_YES} if true, {@code HardwareProperties#BOOLEAN_NO}
     *     otherwise.
     */
    private static String getBooleanVal(boolean bool) {
        if (bool) {
            return BOOLEAN_YES;
        }
        return BOOLEAN_NO;
    }

    /** Represents the type of a hardware property value. */
    public enum HardwarePropertyType {
        INTEGER     ("integer",  false /*isEnum*/),     //$NON-NLS-1$
        BOOLEAN     ("boolean",  false /*isEnum*/),     //$NON-NLS-1$
        DISKSIZE    ("diskSize", false /*isEnum*/),     //$NON-NLS-1$
        STRING      ("string",   false /*isEnum*/),     //$NON-NLS-1$
        INTEGER_ENUM("integer",  true  /*isEnum*/),     //$NON-NLS-1$
        STRING_ENUM ("string",   true  /*isEnum*/);     //$NON-NLS-1$


        private String mName;
        private boolean mIsEnum;

        HardwarePropertyType(String name, boolean isEnum) {
            mName = name;
            mIsEnum = isEnum;
        }

        /** Returns the name of the type (e.g. "string", "boolean", etc.) */
        public String getName() {
            return mName;
        }

        /** Indicates whether this type is an enum (e.g. "enum of strings"). */
        public boolean isEnum() {
            return mIsEnum;
        }

        /** Returns the internal HardwarePropertyType object matching the given type name. */
        public static HardwarePropertyType getEnum(String name, boolean isEnum) {
            for (HardwarePropertyType type : values()) {
                if (type.mName.equals(name) && type.mIsEnum == isEnum) {
                    return type;
                }
            }

            return null;
        }
    }

    public static final class HardwareProperty {
        private String mName;
        private HardwarePropertyType mType;
        /** the string representation of the default value. can be null. */
        private String mDefault;
        /** the choices for an enum. Null if not an enum. */
        private String[] mEnum;
        private String mAbstract;
        private String mDescription;

        public HardwareProperty() {
            // initialize strings to sane defaults, as not all properties will be set from
            // the ini file
            mName = "";
            mDefault = "";
            mAbstract = "";
            mDescription = "";
        }

        /** Returns the hardware config name of the property, e.g. "hw.screen" */
        public String getName() {
            return mName;
        }

        /** Returns the property type, one of {@link HardwarePropertyType} */
        public HardwarePropertyType getType() {
            return mType;
        }

        /**
         * Returns the default value of the property.
         * String matching the property type.
         * Can be null.
         */
        public String getDefault() {
            return mDefault;
        }

        /** Returns the user-visible name of the property. */
        public String getAbstract() {
            return mAbstract;
        }

        /** Returns the user-visible description of the property. */
        public String getDescription() {
            return mDescription;
        }

        /** Returns the possible values for an enum property. Can be null. */
        public String[] getEnum() {
            return mEnum;
        }

        public boolean isValidForUi() {
            // don't display single string type for now.
            return mType != HardwarePropertyType.STRING || mType.isEnum();
        }
    }

    /**
     * Parses the hardware definition file.
     * @param file the property file to parse
     * @param log the ILogger object receiving warning/error from the parsing. Cannot be null.
     * @return the map of (key,value) pairs, or null if the parsing failed.
     */
    public static Map<String, HardwareProperty> parseHardwareDefinitions(IAbstractFile propFile, ILogger log) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(propFile.getContents(), SdkConstants.INI_CHARSET));

            Map<String, HardwareProperty> map = new TreeMap<String, HardwareProperty>();

            String line = null;
            HardwareProperty prop = null;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty() && line.charAt(0) != '#') {
                    Matcher m = PATTERN_PROP.matcher(line);
                    if (m.matches()) {
                        String key = m.group(1);
                        String value = m.group(2);

                        if (HW_PROP_NAME.equals(key)) {
                            prop = new HardwareProperty();
                            prop.mName = value;
                            map.put(prop.mName, prop);
                        }

                        if (prop == null) {
                            log.warning("Error parsing '%1$s': missing '%2$s'",
                                    propFile.getOsLocation(), HW_PROP_NAME);
                            return null;
                        }

                        if (HW_PROP_TYPE.equals(key)) {
                            // Note: we don't know yet whether this type is an enum.
                            // This is indicated by the "enum = value" line that is parsed later.
                            prop.mType = HardwarePropertyType.getEnum(value, false);
                            assert (prop.mType != null);
                        } else if (HW_PROP_DEFAULT.equals(key)) {
                            prop.mDefault = value;
                        } else if (HW_PROP_ABSTRACT.equals(key)) {
                            prop.mAbstract = value;
                        } else if (HW_PROP_DESC.equals(key)) {
                            prop.mDescription = value;
                        } else if (HW_PROP_ENUM.equals(key)) {
                            if (!prop.mType.isEnum()) {
                                // Change the type to an enum, if valid.
                                prop.mType = HardwarePropertyType.getEnum(prop.mType.getName(),
                                                                          true);
                                assert (prop.mType != null);
                            }

                            // Sanitize input: trim spaces, ignore empty entries.
                            String[] v = value.split(",");
                            int n = 0;
                            for (int i = 0; i < v.length; i++) {
                                String s = v[i] = v[i].trim();
                                if (!s.isEmpty()) {
                                    n++;
                                }
                            }
                            prop.mEnum = new String[n];
                            n = 0;
                            for (int i = 0; i < v.length; i++) {
                                String s = v[i];
                                if (!s.isEmpty()) {
                                    prop.mEnum[n++] = s;
                                }
                            }
                        }
                    } else {
                        log.warning("Error parsing '%1$s': \"%2$s\" is not a valid syntax",
                                propFile.getOsLocation(), line);
                        return null;
                    }
                }
            }

            return map;
        } catch (StreamException e) {
            log.warning("Error parsing '%1$s': %2$s.",
                        propFile.getOsLocation(),
                        e.getMessage());
        }  catch (FileNotFoundException e) {
            // this should not happen since we usually test the file existence before
            // calling the method.
            // Return null below.
        } catch (IOException e) {
            log.warning("Error parsing '%1$s': %2$s.", propFile.getOsLocation(),
                        e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    // ignore
                }
            }
        }

        return null;
    }
}
