/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.builder.merge

import java.io.File
import java.io.InputStream
import java.util.function.Predicate
import kotlin.io.inputStream

class FileMapInput
@JvmOverloads
constructor(
  private val name: String,
  private val fileMap: Map<String, File>,
  private val pathPredicate: Predicate<String> = Predicate { true },
) : FileMergerInput {

  val streamMap = mutableMapOf<String, InputStream>()

  private val filteredPaths: Set<String> by lazy { fileMap.keys.filter { pathPredicate.test(it) }.toSet() }

  override fun getAllPaths(): Set<String> = filteredPaths

  override fun getName(): String = name

  override fun open() {}

  override fun close() {
    streamMap.forEach { (_, stream) -> stream.close() }
    streamMap.clear()
  }

  override fun openPath(path: String): InputStream =
    streamMap.computeIfAbsent(path) { (fileMap[path] ?: error("File not found: $path")).inputStream() }
}
