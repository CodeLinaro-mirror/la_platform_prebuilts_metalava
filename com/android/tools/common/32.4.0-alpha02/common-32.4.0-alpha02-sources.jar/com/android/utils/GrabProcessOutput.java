/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.utils;

import com.android.annotations.NonNull;
import com.android.annotations.Nullable;

import com.google.common.io.Closeables;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class GrabProcessOutput {

    public enum Wait {
        /**
         * Doesn't wait for the exec to complete.
         * This still monitors the output but does not wait for the process to finish.
         * In this mode the process return code is unknown and always 0.
         */
        ASYNC,
        /**
         * This waits for the process to finish.
         * In this mode, {@link GrabProcessOutput#grabProcessOutput} returns the
         * error code from the process.
         * <p>
         * In some rare cases and depending on the OS, the process might not have
         * finished dumping data into stdout/stderr.
         * </p>
         * Use this when you don't particularly care for the output but instead
         * care for the return code of the executed process.
         */
        WAIT_FOR_PROCESS,
        /**
         * <p>
         * This waits for the process to finish <em>and</em> for the stdout/stderr
         * threads to complete.
         * In this mode, {@link GrabProcessOutput#grabProcessOutput} returns the
         * error code from the process.
         * </p>
         * Use this one when capturing all the output from the process is important.
         */
        WAIT_FOR_READERS,
    }

    public interface IProcessOutput {
        /**
         * Processes a stdout message line.
         * @param line The stdout message line. Null when the reader reached the end of stdout.
         */
        void out(@Nullable String line);
        /**
         * Processes a stderr message line.
         * @param line The stderr message line. Null when the reader reached the end of stderr.
         */
        void err(@Nullable String line);
    }

    /**
     * Grabs and processes the standard and error output of a given {@link Process} and waits for
     * it to complete based on the specified mode.
     *
     * <p>This method spawns two separate threads to consume the {@code stdout} and {@code stderr}
     * streams of the process to prevent the process from blocking due to full I/O buffers. The
     * output lines are passed to the provided {@link IProcessOutput} handler.
     *
     * <p>The waiting behavior is controlled by the {@code waitMode} parameter. A timeout can also be
     * specified for the process completion.
     *
     * @param process The running process to monitor. Must not be {@code null}.
     * @param waitMode The waiting strategy to use (e.g., asynchronous, wait for readers, etc.).
     * @param output An optional callback handler for processing {@code stdout} and {@code stderr}
     * lines. If {@code null}, the output is consumed but ignored.
     * @param timeout An optional timeout duration. If {@code null}, the method will wait
     * indefinitely for the process to complete.
     * @param timeoutUnit The time unit for the {@code timeout} parameter.
     * @return The exit code of the process. If {@code waitMode} is {@link Wait#ASYNC}, this method
     * returns 0 immediately.
     * @throws InterruptedException if the current thread is interrupted while waiting for the
     * process to complete.
     * @throws TimeoutException if the process does not complete within the specified timeout.
     */
    public static int grabProcessOutput(
            @NonNull final Process process,
            Wait waitMode,
            @Nullable final IProcessOutput output,
            @Nullable Long timeout,
            @Nullable TimeUnit timeoutUnit
    ) throws InterruptedException, TimeoutException {
        // read the lines as they come. if null is returned, it's
        // because the process finished
        Thread threadErr = new Thread("stderr") {
            @Override
            public void run() {
                // create a buffer to read the stderr output
                InputStream is = process.getErrorStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader errReader = new BufferedReader(isr);

                try {
                    while (true) {
                        String line = errReader.readLine();
                        if (output != null) {
                            output.err(line);
                        }
                        if (line == null) {
                            break;
                        }
                    }
                } catch (IOException e) {
                    // do nothing.
                } finally {
                    try {
                        Closeables.close(is, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                    try {
                        Closeables.close(isr, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                    try {
                        Closeables.close(errReader, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                }
            }
        };

        Thread threadOut = new Thread("stdout") {
            @Override
            public void run() {
                InputStream is = process.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader outReader = new BufferedReader(isr);

                try {
                    while (true) {
                        String line = outReader.readLine();
                        if (output != null) {
                            output.out(line);
                        }
                        if (line == null) {
                            break;
                        }
                    }
                } catch (IOException e) {
                    // do nothing.
                } finally {
                    try {
                        Closeables.close(is, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                    try {
                        Closeables.close(isr, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                    try {
                        Closeables.close(outReader, true /* swallowIOException */);
                    } catch (IOException e) {
                        // cannot happen
                    }
                }
            }
        };

        // reset the thread class loader is we do not need to load any script classes.
        threadErr.setContextClassLoader(null);
        threadOut.setContextClassLoader(null);
        threadErr.start();
        threadOut.start();

        if (waitMode == Wait.ASYNC) {
            return 0;
        }

        int exitCode;
        if (timeout == null) {
            // get the return code from the process
            exitCode = process.waitFor();
        } else {
            if (!process.waitFor(timeout, timeoutUnit)) {
                throw new TimeoutException();
            }
            exitCode = process.exitValue();
        }

        // it looks like on windows process#waitFor() can return
        // before the thread have filled the arrays, so we wait for both threads and the
        // process itself.
        if (waitMode == Wait.WAIT_FOR_READERS) {
            try {
                threadErr.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            try {
                threadOut.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        return exitCode;
    }
}
