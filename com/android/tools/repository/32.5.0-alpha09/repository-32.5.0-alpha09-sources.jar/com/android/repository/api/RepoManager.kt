/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.repository.api

import com.android.ProgressManagerAdapter
import com.android.annotations.concurrency.Slow
import com.android.repository.api.ProgressRunner.ProgressRunnable
import com.android.repository.impl.manager.RepoManagerImpl
import com.android.repository.impl.meta.CommonFactory
import com.android.repository.impl.meta.GenericFactory
import com.android.repository.impl.meta.RepositoryPackages
import com.google.common.annotations.VisibleForTesting
import java.nio.file.Path
import java.util.concurrent.TimeUnit
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.w3c.dom.ls.LSResourceResolver

/**
 * Primary interface for interacting with repository packages.
 *
 * To set up a `RepoManager`, the following are required:
 * * The path where the repo is installed locally
 * * The [SchemaModule]s used to parse the package.xml files and remote repositories used by this repo
 * * If your local repo might contain packages created by a previous system, a [FallbackLocalRepoLoader] that can recognize and convert
 *   those packages
 * * [RepositorySourceProvider]s to provide URLs for remotely-available packages.
 * * If some sources might be in a format used by a previous system, a [FallbackRemoteRepoLoader] that can read and convert them.
 *
 * To load the local and remote packages, use [load].
 *
 * TODO: it would be nice if this could be redesigned such that load didn't need to be called explicitly, or there was a better way to know
 *   if packages were or need to be loaded.
 *
 * To use the loaded packages, get a [RepositoryPackages] object from [packages].
 */
abstract class RepoManager {

  /** Gets the currently-registered [SchemaModule]s. This probably shouldn't be used except by code within the RepoManager or unit tests. */
  abstract val schemaModules: Set<SchemaModule<*>>

  /** Gets the path to the local repository root. This probably shouldn't be needed except by the repository manager and unit tests. */
  abstract val localPath: Path?

  @get:VisibleForTesting abstract val sourceProviders: List<RepositorySourceProvider>

  /**
   * Gets the actual [RepositorySource]s from the registered [RepositorySourceProvider]s.
   *
   * Probably should only be needed by a repository UI.
   *
   * @param downloader The [Downloader] to use for downloading source lists, if needed.
   * @param progress A [ProgressIndicator] for source providers to use to show their progress and for logging.
   * @param forceRefresh Individual [RepositorySourceProvider]s may cache their results. If `forceRefresh` is true, specifies that they
   *   should reload rather than returning cached results.
   * @return The [RepositorySource]s obtained from the providers.
   */
  abstract fun getSources(downloader: Downloader?, progress: ProgressIndicator, forceRefresh: Boolean): List<RepositorySource>

  /**
   * Loads the local and remote repositories asynchronously.
   *
   * @param cacheExpirationMs How long must have passed since the last load for us to reload. Specify `0` to reload immediately.
   * @param onLocalComplete When loading, the local repo load happens first, and should be relatively fast. When complete, the
   *   `onLocalComplete` [RepoLoadedListener] is run. Will be called with a [RepositoryPackages] that contains only the local packages.
   * @param onSuccess Callback that is run when the entire load (local and remote) has completed successfully. Called with an
   *   [RepositoryPackages] containing both the local and remote packages.
   * @param onError Callback that is run when there's an error at some point during the load.
   * @param runner The [ProgressRunner] to use for any tasks started during the load, including running the callbacks.
   * @param downloader The [Downloader] to use for downloading remote files, including any remote list of repo sources and the remote
   *   repositories themselves.
   * @param settings The settings to use during the load, including for example proxy settings used when fetching remote files.
   *
   * TODO: throw exception if cancelled
   */
  abstract fun load(
    cacheExpirationMs: Long,
    onLocalComplete: RepoLoadedListener? = null,
    onSuccess: RepoLoadedListener? = null,
    onError: Runnable? = null,
    runner: ProgressRunner,
    downloader: Downloader? = null,
    settings: SettingsController? = null,
  )

  /**
   * Loads the local and remote repositories synchronously.
   *
   * In callbacks, be careful of invoking tasks synchronously on other threads (e.g. the Swing UI thread), since they might also be used by
   * the [ProgressRunner] passed in.
   *
   * @param cacheExpirationMs How long must have passed since the last load for us to reload. Specify `0` to reload immediately.
   * @param onLocalComplete When loading, the local repo load happens first, and should be relatively fast. When complete, the
   *   `onLocalComplete` [RepoLoadedListener] is run. Will be called with a [RepositoryPackages] that contains only the local packages.
   * @param onSuccess Callback that is run when the entire load (local and remote) has completed successfully. Called with an
   *   [RepositoryPackages] containing both the local and remote packages.
   * @param onError Callback that is run when there's an error at some point during the load.
   * @param runner The [ProgressRunner] to use for any tasks started during the load, including running the callbacks.
   * @param downloader The [Downloader] to use for downloading remote files, including any remote list of repo sources and the remote
   *   repositories themselves.
   * @param settings The settings to use during the load, including for example proxy settings used when fetching remote files.
   */
  @Slow
  abstract fun loadSynchronously(
    cacheExpirationMs: Long,
    onLocalComplete: RepoLoadedListener? = null,
    onSuccess: RepoLoadedListener? = null,
    onError: Runnable? = null,
    runner: ProgressRunner,
    downloader: Downloader? = null,
    settings: SettingsController? = null,
  )

  /**
   * Loads the local and remote repositories synchronously.
   *
   * @param cacheExpirationMs How long must have passed since the last load for us to reload. Specify `0` to reload immediately.
   * @param progress The [ProgressIndicator] to use for showing progress and logging.
   * @param downloader The [Downloader] to use for downloading remote files, including any remote list of repo sources and the remote
   *   repositories themselves.
   * @param settings The settings to use during the load, including for example proxy settings used when fetching remote files.
   * @return `true` if the load was successful (including if cached results were returned), false otherwise.
   */
  @Slow
  fun loadSynchronously(
    cacheExpirationMs: Long,
    progress: ProgressIndicator,
    downloader: Downloader? = null,
    settings: SettingsController? = null,
  ) {
    loadSynchronously(
      cacheExpirationMs = cacheExpirationMs,
      runner = DirectProgressRunner(progress),
      downloader = downloader,
      settings = settings,
    )
  }

  abstract suspend fun loadLocalPackages(
    indicator: ProgressIndicator,
    cacheExpiration: Duration = DEFAULT_EXPIRATION_PERIOD,
  ): List<LocalPackage>

  abstract suspend fun loadRemotePackages(
    indicator: ProgressIndicator,
    downloader: Downloader,
    settings: SettingsController?,
    cacheExpiration: Duration = DEFAULT_EXPIRATION_PERIOD,
  ): List<RemotePackage>

  /** Causes cached results to be considered expired. The next time [load] is called, a complete load will be done. */
  abstract fun markInvalid()

  /**
   * Causes the cached results of the local repositories to be considered expired. The next time [load] is called, the load will be done
   * only for the local repositories, the remotes being loaded from the cache if possible.
   */
  abstract fun markLocalCacheInvalid()

  /**
   * Check to see if there have been any changes to the local repo since the last load. This includes scanning the local repo for packages,
   * but does not involve any reading or parsing of package metadata files. If there have been any changes, or if the cache is older than
   * the default timeout, the local packages will be reloaded.
   */
  abstract fun reloadLocalIfNeeded(progress: ProgressIndicator)

  /** Gets the currently-loaded [RepositoryPackages]. */
  abstract val packages: RepositoryPackages

  /**
   * Gets an [LSResourceResolver] that can find the XSDs for all versions of the currently-registered [SchemaModule]s by namespace. Returns
   * null if there is an error.
   */
  abstract fun getResourceResolver(progress: ProgressIndicator): LSResourceResolver?

  /**
   * Registers a listener that will be called whenever the local packages are reloaded and have changed. The [RepositoryPackages] instance
   * passed to the callback will contain only the local packages.
   */
  abstract fun addLocalChangeListener(listener: RepoLoadedListener)

  /** Removes the listener previously added by calling [addLocalChangeListener]. */
  abstract fun removeLocalChangeListener(listener: RepoLoadedListener)

  /**
   * Register a listener that will be called whenever the remote packages are reloaded and have changed. The [RepositoryPackages] instance
   * will contain the remote and local packages.
   */
  abstract fun addRemoteChangeListener(listener: RepoLoadedListener)

  /** Removes the listener previously added by calling [addRemoteChangeListener]. */
  abstract fun removeRemoteChangeListener(listener: RepoLoadedListener)

  /** Record that the given package is in the process of being installed by the given installer. */
  abstract fun installBeginning(repoPackage: RepoPackage, installer: PackageOperation)

  /**
   * Record that the given package is no longer in the process of being installed (that is, install completed either successfully or
   * unsuccessfully).
   */
  abstract fun installEnded(repoPackage: RepoPackage)

  /** Gets the previously-registered installer that is currently installing the given package, or `null` if there is none. */
  abstract fun getInProgressInstallOperation(remotePackage: RepoPackage): PackageOperation?

  /** Callback for when repository load is completed/partially completed. */
  fun interface RepoLoadedListener {

    /**
     * @param packages The packages that have been loaded so far. When this listener is used in the `onLocalComplete` argument to [load]
     *   `packages` will only include local packages.
     */
    fun loaded(packages: RepositoryPackages)
  }

  /** A ProgressRunner that immediately runs tasks on the current thread (analogous to MoreExecutors.directExecutor()). */
  protected class DirectProgressRunner(private val progress: ProgressIndicator) : ProgressRunner {

    // This class is only for use in loadSynchronously; this method is unneeded.
    override fun runAsyncWithProgress(r: ProgressRunnable) = throw UnsupportedOperationException()

    override fun runSyncWithProgress(r: ProgressRunnable) {
      runBlockingCancellable { r.run(progress) }
    }
  }

  companion object {

    /**
     * After loading the repository, this is the amount of time that must pass before we consider it to be stale and need to be reloaded.
     */
    @JvmField val DEFAULT_EXPIRATION_PERIOD_MS: Long = TimeUnit.DAYS.toMillis(1)

    val DEFAULT_EXPIRATION_PERIOD: Duration
      get() = DEFAULT_EXPIRATION_PERIOD_MS.milliseconds

    /** Pattern for name of the xsd file used in [commonModule]. */
    private const val COMMON_XSD_PATTERN = "/xsd/repo-common-%02d.xsd"

    /** Pattern for fully-qualified name of the `ObjectFactory` used in [commonModule]. */
    private const val COMMON_OBJECT_FACTORY_PATTERN = "com.android.repository.impl.generated.v%d.ObjectFactory"

    /** Pattern for name of the xsd file used in [genericModule]. */
    private const val GENERIC_XSD_PATTERN = "/xsd/generic-%02d.xsd"

    /** Pattern for fully-qualified name of the `ObjectFactory` used in [genericModule]. */
    private const val GENERIC_OBJECT_FACTORY_PATTERN = "com.android.repository.impl.generated.generic.v%d.ObjectFactory"

    /** The core [SchemaModule] created by the RepoManager itself. Contains the base definition of repository, package, revision, etc. */
    @JvmStatic val commonModule = SchemaModule<CommonFactory>(COMMON_OBJECT_FACTORY_PATTERN, COMMON_XSD_PATTERN, RepoManager::class.java)

    /** The [SchemaModule] created by the RepoManager that includes the trivial generic `typeDetails` type. */
    @JvmStatic
    val genericModule = SchemaModule<GenericFactory>(GENERIC_OBJECT_FACTORY_PATTERN, GENERIC_XSD_PATTERN, RepoManager::class.java)

    @JvmStatic
    @JvmOverloads
    fun createRepoManager(
      localPath: Path?,
      schemaModules: List<SchemaModule<*>>,
      sourceProviders: List<RepositorySourceProvider>,
      fallbackLocalRepoLoader: FallbackLocalRepoLoader?,
      fallbackRemoteRepoLoader: FallbackRemoteRepoLoader?,
      knownTopLevelPackageDirs: Set<String> = emptySet(),
    ): RepoManager {
      return RepoManagerImpl(
        localPath,
        sourceProviders,
        schemaModules,
        fallbackLocalRepoLoader,
        fallbackRemoteRepoLoader,
        knownTopLevelPackageDirs,
      )
    }
  }
}

/** How often [runBlockingCancellable] checks for cancellation while its block is suspended. */
private val CANCELLATION_CHECK_INTERVAL: Duration = 10.milliseconds

/**
 * Like [runBlocking], but while [block] is suspended, periodically invokes [checkCanceled]. If [checkCanceled] throws, [block] is cancelled
 * and the exception is rethrown. This is like IntelliJ's runBlockingCancellable, but simpler and usable in tools/base.
 *
 * A plain [runBlocking] coroutine is not linked to any environment-specific cancellation mechanism (e.g. the IntelliJ thread-local progress
 * indicator), so a thread parked waiting on a suspended coroutine (for example, a load piggybacking on a load running on another thread)
 * never notices that it has been cancelled. In Studio, this can cause a non-blocking read action to hold the read lock and block a pending
 * write action for the entire duration of an SDK scan (b/424192015).
 *
 * Blocking work performed directly by [block] is not interrupted by this mechanism; it is expected to check for cancellation itself (e.g.
 * by using [com.android.io.CancellableFileIo]).
 */
@VisibleForTesting
internal fun <T> runBlockingCancellable(
  checkCanceled: () -> Unit = ProgressManagerAdapter::checkCanceled,
  checkInterval: Duration = CANCELLATION_CHECK_INTERVAL,
  block: suspend CoroutineScope.() -> T,
): T = runBlocking {
  // Run undispatched so that the common case (which completes without suspending) doesn't need
  // to go through the event loop, and never observes a cancellation check.
  val result = async(start = CoroutineStart.UNDISPATCHED, block = block)
  while (!result.isCompleted) {
    if (withTimeoutOrNull(checkInterval) { result.join() } == null) {
      try {
        checkCanceled()
      } catch (t: Throwable) {
        result.cancel()
        throw t
      }
    }
  }
  result.await()
}
