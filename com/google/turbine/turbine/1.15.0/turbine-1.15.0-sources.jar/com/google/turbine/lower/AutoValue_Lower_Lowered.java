package com.google.turbine.lower;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.turbine.binder.sym.ClassSymbol;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Lower_Lowered extends Lower.Lowered {

  private final ImmutableMap<String, byte[]> bytes;

  private final ImmutableSet<ClassSymbol> symbols;

  AutoValue_Lower_Lowered(
      ImmutableMap<String, byte[]> bytes,
      ImmutableSet<ClassSymbol> symbols) {
    if (bytes == null) {
      throw new NullPointerException("Null bytes");
    }
    this.bytes = bytes;
    if (symbols == null) {
      throw new NullPointerException("Null symbols");
    }
    this.symbols = symbols;
  }

  @Override
  public ImmutableMap<String, byte[]> bytes() {
    return bytes;
  }

  @Override
  public ImmutableSet<ClassSymbol> symbols() {
    return symbols;
  }

  @Override
  public String toString() {
    return "Lowered{"
        + "bytes=" + bytes + ", "
        + "symbols=" + symbols
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Lower.Lowered) {
      Lower.Lowered that = (Lower.Lowered) o;
      return this.bytes.equals(that.bytes())
          && this.symbols.equals(that.symbols());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= bytes.hashCode();
    h$ *= 1000003;
    h$ ^= symbols.hashCode();
    return h$;
  }

}
