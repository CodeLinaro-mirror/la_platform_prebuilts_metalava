package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_TypeParameterTarget extends ClassFile.TypeAnnotationInfo.TypeParameterTarget {

  private final int index;

  AutoValue_ClassFile_TypeAnnotationInfo_TypeParameterTarget(
      int index) {
    this.index = index;
  }

  @Override
  public int index() {
    return index;
  }

  @Override
  public String toString() {
    return "TypeParameterTarget{"
        + "index=" + index
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.TypeParameterTarget) {
      ClassFile.TypeAnnotationInfo.TypeParameterTarget that = (ClassFile.TypeAnnotationInfo.TypeParameterTarget) o;
      return this.index == that.index();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= index;
    return h$;
  }

}
