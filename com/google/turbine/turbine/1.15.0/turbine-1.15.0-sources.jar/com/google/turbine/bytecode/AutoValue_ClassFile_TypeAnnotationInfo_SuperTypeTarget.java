package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_SuperTypeTarget extends ClassFile.TypeAnnotationInfo.SuperTypeTarget {

  private final int index;

  AutoValue_ClassFile_TypeAnnotationInfo_SuperTypeTarget(
      int index) {
    this.index = index;
  }

  @Override
  public int index() {
    return index;
  }

  @Override
  public String toString() {
    return "SuperTypeTarget{"
        + "index=" + index
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.SuperTypeTarget) {
      ClassFile.TypeAnnotationInfo.SuperTypeTarget that = (ClassFile.TypeAnnotationInfo.SuperTypeTarget) o;
      return this.index == that.index();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= index;
    return h$;
  }

}
