/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.tracing

/** Represents an object that can be reused using a [Pool]. This avoids GC churn. */
public abstract class Poolable<T : Poolable<T>>
internal constructor(internal open val owner: Pool<T>) {
    /** Recycles the object, and hands it back to the pool. */
    public abstract fun recycle()
}
