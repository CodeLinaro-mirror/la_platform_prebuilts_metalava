/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.tracing

/**
 * Represents an API surface that is typically only useful for custom implementations of a
 * [AbstractTraceSink] or a [Track].
 *
 * Any use of a delicate declaration has to be carefully reviewed to make sure it is properly used
 * and does not create problems like memory and resource leaks.
 *
 * Carefully read documentation of any declaration marked as [DelicateTracingApi].
 */
@RequiresOptIn(message = "Marks declarations in the Tracing API that are delicate.")
@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION)
public annotation class DelicateTracingApi
