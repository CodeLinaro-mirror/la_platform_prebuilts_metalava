/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.tracing

import androidx.annotation.RestrictTo

// This was originally a part of the Kotlin Stdlib (but now is @Deprecated(HIDDEN) for non JVM
// Platforms)
// By defining this as an expect function we can do the right thing by using the right platform
// primitive going forward. On Darwin we can acquire a lock, and on JavaScript we can simply return
// the result of `block()`.

/** Executes the given function [block] while holding the monitor of the given object [lock]. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public expect fun <R> synchronized(lock: Any, block: () -> R): R
